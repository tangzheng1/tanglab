#include<stdio.h>
#include<math.h>
#include<float.h>
#include<stdlib.h>
#include<time.h>
#include <string.h>
#include "miProfile_utility.h"
#include "utility.h"
#include "Biom.h"
#include "NewickTree.h"
//#include <gsl/gsl_randist.h>
//#include <gsl/gsl_math.h>
//#include <gsl/gsl_eigen.h>
//#include <gsl/gsl_cdf.h>
//#include <gsl/gsl_rng.h>
#define max(a,b) \
   ({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
     _a > _b ? _a : _b; })
 
#define min(a,b) \
   ({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
     _a < _b ? _a : _b; })

// global seed
long gix=4567, giy=6789, giz=8901;
long bix=7335, biy=4623, biz=8097;
int MAX_Dg = 20;
int MAX_ifile_dist = 20;

// skip one line and position the pointer to the beginning of the next line
// return 1 if the end of file was reached , otherwise return 0
int skipLine(FILE *fi){
	int c=0, end=0;
	c = fgetc(fi);
	while(c!='\n' && c!=EOF){
		c = fgetc(fi);
	}
	if(c==EOF){
		end = 1;
	}
	return end;
}


int main(int argc, char *argv[]){

	
	printf("\n");
	printf("@-----------------------------------------------------------------@\n");
	printf("|       miProfile       |       v2.0      |    October 30, 2017   |\n");
	printf("-------------------------------------------------------------------\n");
	printf("|                   For documentation & citation                  |\n");
	printf("|   https://medschool.vanderbilt.edu/tang-lab/software/miProfile  |\n");
	printf("@-----------------------------------------------------------------@\n\n");

	int i=0, j=0, k=0, l=0, d=0, indexD, c=0, lastchar=0, flag=0, ret;
	double tmp, tmp2;

	//----------------------------- default & command reading ------------------------------//
	FILE *fi, *fo;
	char *ifile_otu             = "otu.txt",    
		 *ifile_meta             = "meta_data.txt",   
		 *ifile_tree             = "tree.tre",
		 //*ifile_dist            = "dist.txt",
		 //*ifile_tree_edge       = "tree_edge.txt",   
		 //*ifile_tree_tipLabel   = "tree_tipLabel.txt",  
		 *ifile_info            = "information.txt",
		 //*ifile_covariates      = "covariates.txt",
		 //*ifile_confounders     = "confounders.txt",
		 *ofile_pvalue          = "pvalue.txt",
		 ofile_dist[20],
		 strata_var[20];
		 

	int *which_cova, *which_conf, which_strata,  Duw=0, Dg=0, Dpg=0, Dbc=0, Dj=0, ndist, npval;
	int Dbc_norm=0, Dj_norm=1, Duw_norm=1, *Dg_norm_type, *Dpg_norm_type, *pdist_norm;  // 0: proprotion; 1:rarefied
	int Dbc_out=0, Dj_out=0, Duw_out=0, *Dg_out_type, *Dpg_out_type, *pdist_out_type; 
	char ofile_Dbc[50], ofile_Dj[50], ofile_Duw[50], **ofile_Dg, **ofile_Dpg, *pdist_ofile, *pch;
	int ndist_input;
	char **ifile_dist;
	int strata=0, *str, *str_index, cova=0, conf=0; 
	char **cova_var, **conf_var;
	double *Dg_type, *Dpg_type, **dist;
	//Dg_type[2]={0.5, 1} 

	int otu_ncol=0, otu_nrow=0, tree_nedge=0, tree_ntip=0, meta_nrow=0, meta_ncol=0, depth_LB, depth_MIN;
	char dummy[1024], **otu_subID, **meta_subID;
	double **otu_orig, **meta_orig, *tree_brLen;
	char **otu_label, **tree_tipLabel;  // otu id has to be numeric
	int nbr, *tree_upNode, *tree_downNode, *tree_tipLabel_ID;

	long max_nperm = 1000;
	int n1, p, q;
	double **x, **z, *pvalue, *Fstat;
	int *is_binary, is_biom;

	int n, m, arg_dist=0, output_otutab=0, output_dist=0, m_otuFile=0, m_metaFile=0, m_treeFile=0, m_infoFile=0;
	report* report_otu;

   //******************************************************
   //
   //          BEGIN: read data/arguments 
   //
   //******************************************************
	for (i = 1; i < argc; i++) {

		if (strcmp(argv[i], "-otuFile")==0) { // otu file
			ifile_otu = argv[++i];      m_otuFile=1;   continue;
		}

		if (strcmp(argv[i], "-metaFile")==0) { // metaData file: if no confounder and strata variable argument is used, then all variable in the metaData file will be treated as covariates of interest
			ifile_meta = argv[++i];      m_metaFile=1;   continue;
		}

		//if (strcmp(argv[i], "-distance")==0) { // files containing all distances requested
		//	ifile_dist = argv[++i];   arg_dist = 1;     continue;
		//}

		if (strcmp(argv[i], "-treeFile")==0) { // .tre file
			ifile_tree = argv[++i];     m_treeFile=1;   continue;
		}

		//if (strcmp(argv[i], "-depth")==0) { // remove samples with low depth
		//	depth_LB = atoi(argv[++i]);        continue;
		//}

		//if (strcmp(argv[i], "-treeEdgeFile")==0) { // tree edge file
		//	ifile_tree_edge = argv[++i];        continue;
		//}

		//if (strcmp(argv[i], "-treeTipFile")==0) { // tree tip file
		//	ifile_tree_tipLabel = argv[++i];        continue;
		//}

		if (strcmp(argv[i], "-infoFile")==0) { // information file: specified covariates, confounders, and strata, distance related parameters
			ifile_info = argv[++i];     m_infoFile=1;   continue;
		}

		if (strcmp(argv[i], "-oFile")==0) { // pvalue output file
			ofile_pvalue = argv[++i];        continue;
		}

		//if (strcmp(argv[i], "-strata")==0) { // strata variables
		//	strata_var = argv[++i]; 
		//	strata = 1; 
		//	continue;
		//}

		//if (strcmp(argv[i], "-covariates")==0) { // covariates
		//	ifile_covariates = argv[++i]; 
		//	cova = 1; 
		//	continue;
		//}

		//if (strcmp(argv[i], "-confounders")==0) { // confounders
		//	ifile_confounders = argv[++i]; 
		//	conf = 1; 
		//	continue;
		//}

		//if (strcmp(argv[i], "-resample")==0) { // maximum #resampling
		//	 max_nperm = atoi(argv[++i]);        continue;
		//}

		//if (strcmp(argv[i], "-oFile_dist")==0) { // indicate whether distance will be output
		//	 //ofile_dist = argv[++i]; 
		//	 output_dist = 1;        continue;
		//}

		printf("\nError: Unknown command line option '%s'.\n", argv[i]);
		kill_miProfile();

	}


	if(m_otuFile==0){
		printf("\nError: -otuFile is not specified.\n");
		kill_miProfile();		
	}

	if(m_metaFile==0){
		printf("\nError: -metaFile is not specified.\n");
		kill_miProfile();		
	}

	if(m_infoFile==0){
		printf("\nError: -infoFile is not specified.\n");
		kill_miProfile();		
	}

	
	//get is_biom based on ifile_otu
	pch = strstr(ifile_otu, ".biom");
	if(pch){
		is_biom = 1;
	}else{
		is_biom = 0;
	}

	//************* BEGIN: NROW and NCOL in meta data
	meta_ncol=0; meta_nrow=0;
	if((fi=fopen(ifile_meta, "r"))==NULL) {
		printf("\nError: Cannot open covariate file.\n");
		kill_miProfile();
	}else{   

		c = fgetc(fi);
		while(c != EOF){

			c=fgetc(fi);

			if(c == '\t')
				meta_ncol++;

			if(c =='\n' || (c==EOF && lastchar!='\n')){
				meta_nrow++;
			}
			lastchar = c;
		}

		fclose(fi);			
	}

	meta_ncol /= meta_nrow;
	meta_ncol += 1;
	printf("Meta data input: #variables = %d, #subjects = %d\n", meta_ncol-1, meta_nrow-1);
	
	//************* BEGIN: NROW and NCOL in meta data


	//************* BEGIN: Parsing the information file


	//// how many row and column in the information file
	//info_nrow = 0; 
	//info_ncol = ivector(0, 50);
	//for(i=0; i<50; i++){
	//	info_ncol[i] = 1;		
	//}

	//if((fi=fopen(ifile_info, "r"))==NULL) {
	//	printf("Error: Cannot open information file.\n");
	//}else{   

	//	c = fgetc(fi);
	//	while(c != EOF){

	//		c=fgetc(fi);

	//		if(c == '\t')
	//			info_ncol[info_nrow]++;

	//		if(c =='\n' || (c==EOF && lastchar!='\n')){
	//			info_nrow++;
	//		}
	//		lastchar = c;
	//	}

	//	fclose(fi);			
	//}
	//printf("information file input: #row = %d\n", info_nrow);
	//print_iv(info_ncol, 0, info_nrow-1, "info_ncol");


	// meta data related variables: strata, strata_var, cova, *cova_var, conf, *conf_var
	strata = 0; cova = 0; conf = 0;

	cova_var = calloc(meta_ncol-1,sizeof(char*));
	for(j=0;j<meta_ncol-1;j++){
		cova_var[j] = calloc(4096,sizeof(char));
	}

	conf_var = calloc(meta_ncol-1,sizeof(char*));
	for(j=0;j<meta_ncol-1;j++){
		conf_var[j] = calloc(4096,sizeof(char));
	}

	
	

	// distance related variables: Dbc, Dj, Dg, *Dg_type, Duw, Dpg, *Dpg_type, 
	Duw=0; Dg=0; Dpg=0; Dbc=0; Dj=0;
	Dg_type = dvector(0, MAX_Dg-1); //less than 5 parameters
	Dpg_type = dvector(0, MAX_Dg-1); //less than 5 parameters
	for(j=0; j<MAX_Dg; j++){
		Dg_type[j] = 0.;
		Dpg_type[j] = 0.;
	}

	// distance related variables: Dbc_norm, Dj_norm, Duw_norm, *Dg_norm_type, *Dpg_norm_type
	// default: abundance distance use proportion, presence-absence distance use rarefied. 
	Dbc_norm=0; Dj_norm=1; Duw_norm=1;
	Dg_norm_type = ivector(0, MAX_Dg-1); 
	Dpg_norm_type = ivector(0, MAX_Dg-1); 
	for(j=0; j<MAX_Dg; j++){
		Dg_norm_type[j] = 0;
		Dpg_norm_type[j] = 1;
	}

	// distance related variables: Dbc_out, Dj_out, Duw_out, *Dg_out_type, *Dpg_out_type
	//                             *ofile_Dbc, *ofile_Dj, *ofile_Dg, *ofile_Duw, *ofile_Dpg;
	Dbc_out=0; Dj_out=0; Duw_out=0;
	Dg_out_type = ivector(0, MAX_Dg-1); 
	Dpg_out_type = ivector(0, MAX_Dg-1); 
	for(j=0; j<MAX_Dg; j++){
		Dg_out_type[j] = 0;
		Dpg_out_type[j] = 0;
	}

	ofile_Dg = calloc(MAX_Dg,sizeof(char*));
	for(j=0;j<MAX_Dg;j++){
		ofile_Dg[j] = calloc(4096,sizeof(char));
	}

	ofile_Dpg = calloc(MAX_Dg,sizeof(char*));
	for(j=0;j<MAX_Dg;j++){
		ofile_Dpg[j] = calloc(4096,sizeof(char));
	}

	// distance input variables: ndist_input, **ifile_dist 
	ndist_input = 0;
	ifile_dist = calloc(MAX_ifile_dist,sizeof(char*));
	for(j=0;j<MAX_ifile_dist;j++){
		ifile_dist[j] = calloc(4096,sizeof(char));
	}

	if((fi=fopen(ifile_info, "r"))==NULL) {
		printf("Error: Cannot open the information file '%s'.\n", ifile_info);
		kill_miProfile();
	}else{ 

		flag = 0;

		while(flag==0){
		
			fscanf(fi, "%s", dummy);

			if( strcmp(dummy, "COVA")==0 ){
				
				fscanf(fi, "%s", dummy);	fscanf(fi, "%s", dummy);
				strcpy(cova_var[cova], dummy);
				cova += 1;

			}else if( strcmp(dummy, "CONF")==0 ){

				fscanf(fi, "%s", dummy);	fscanf(fi, "%s", dummy);
				strcpy(conf_var[conf], dummy);
				conf += 1;	

			}else if( strcmp(dummy, "STRATA")==0 ){
				
				fscanf(fi, "%s", dummy);	fscanf(fi, "%s", dummy);
				strcpy(strata_var, dummy);
				strata += 1;	
				

			}else if( strcmp(dummy, "NPERM")==0 ){

				fscanf(fi, "%s", dummy); fscanf(fi, "%d", &max_nperm);

			}else if( strcmp(dummy, "DIST")==0 ){

				fscanf(fi, "%s", dummy);	fscanf(fi, "%s", dummy);

				if(strcmp(dummy, "Bray-Curtis")==0){
					Dbc = 1;
					pdist_norm = &Dbc_norm;
					pdist_out_type = &Dbc_out;
					pdist_ofile = ofile_Dbc;
				}	

				else if(strcmp(dummy, "Jaccard")==0){
					Dj = 1;	
					pdist_norm = &Dj_norm;
					pdist_out_type = &Dj_out;
					pdist_ofile = ofile_Dj;
				}	

				else if(strcmp(dummy, "wUniFrac")==0){
					Dg_type[Dg] = 1; 
					pdist_norm = &(Dg_norm_type[Dg]);
					pdist_out_type = &(Dg_out_type[Dg]);
					pdist_ofile = ofile_Dg[Dg];
					Dg += 1;
					
				}

				//if(strcmp(dummy, "pwUniFrac")==0){
				//	Dpg_type[Dpg] = 1; 
				//	pdist_norm = &(Dpg_norm_type[Dpg]);
				//	pdist_out_type = &(Dpg_out_type[Dpg]);
				//	pdist_ofile = ofile_Dpg[Dpg];
				//	Dpg += 1;
				//}

				else if(strcmp(dummy, "uwUniFrac")==0){
					Duw = 1;	
					pdist_norm = &Duw_norm;
					pdist_out_type = &Duw_out;
					pdist_ofile = ofile_Duw;
				}


				else if(strcmp(dummy, "gUniFrac")==0){
					fscanf(fi, "%lg", &(Dg_type[Dg]));
					pdist_norm = &(Dg_norm_type[Dg]);
					pdist_out_type = &(Dg_out_type[Dg]);
					pdist_ofile = ofile_Dg[Dg];
					Dg += 1;
				}

				else if(strcmp(dummy, "pwUniFrac")==0){
					fscanf(fi, "%lg", &(Dpg_type[Dpg]));
					pdist_norm = &(Dpg_norm_type[Dpg]);
					pdist_out_type = &(Dpg_out_type[Dpg]);
					pdist_ofile = ofile_Dpg[Dpg];
					Dpg += 1;
				}

				else{
					printf("\nWarning: Unknown distance '%s' specified in the information file.\n", dummy);
				}


			}else if( strcmp(dummy, "DIST_NORM")==0 ){

				fscanf(fi, "%s", dummy);	fscanf(fi, "%s", dummy);
				if(strcmp(dummy, "proportion")==0){
					(*pdist_norm) = 0;
				}
				if(strcmp(dummy, "rarefaction")==0){
					(*pdist_norm) = 1;
				}
				

			}else if( strcmp(dummy, "DIST_OFILE")==0 ){

				fscanf(fi, "%s", dummy);	fscanf(fi, "%s", pdist_ofile);
				(*pdist_out_type) = 1;

			}else if( strcmp(dummy, "DIST_IFILE")==0 ){

				fscanf(fi, "%s", dummy);	fscanf(fi, "%s", ifile_dist[ndist_input]);
				ndist_input++;

			}

			flag = skipLine(fi);
		}

		fclose(fi);	


	}

	//printf("#COVA=%d, #CONF=%d\n", cova, conf);
	if(cova>0){
		printf("covariates of interest: ");
		for(d=0; d<cova; d++){
			printf("%s\t", cova_var[d]);
		}
		printf("\n");	
	}
	if(conf>0){
		printf("confounders: ");
		for(d=0; d<conf; d++){
			printf("%s\t", conf_var[d]);
		}
		printf("\n");	
	}
	if(strata>0){
		printf("strata: ");
		printf("%s\t", strata_var);
		printf("\n");	
	}


	//printf("#Dbc = %d, #Dj = %d, #Duw = %d\n", Dbc, Dj, Duw);
	//printf("#Dg = %d, #Dpg = %d\n", Dg, Dpg);	
	//print_dv(Dg_type, 0, Dg-1, "Dg_type");
	//print_dv(Dpg_type, 0, Dpg-1, "Dpg_type");
	//printf("\n\n");

	//printf("Dbc_norm = %d, Dj_norm = %d, Duw_norm = %d\n", Dbc_norm, Dj_norm,Duw_norm);
	//print_iv(Dg_norm_type, 0, Dg-1, "Dg_norm_type");
	//print_iv(Dpg_norm_type, 0, Dpg-1, "Dpg_norm_type");
	//printf("\n\n");
	//

	//printf("ofile_Dbc=%s, ofile_Dj=%s, ofile_Duw=%s\n", ofile_Dbc, ofile_Dj, ofile_Duw);
	//printf("ofile_Dg\n");
	//for(d=0; d<Dg; d++){
	//	printf("%s\t", ofile_Dg[d]);
	//}
	//printf("\n");
	//printf("ofile_Dpg\n");
	//for(d=0; d<Dpg; d++){
	//	printf("%s\t", ofile_Dpg[d]);
	//}
	//printf("\n\n");

	//printf("ifile_dist\n");
	//for(d=0; d<ndist_input; d++){
	//	printf("%s\t", ifile_dist[d]);
	//}
	//printf("\n\n");

	ndist = Dg + Dpg + Duw + Dbc + Dj; 
	if( (ndist + ndist_input) > 1){
		npval = ndist + ndist_input + 1;
	}else{
		npval = 1;
	}

	pvalue = dvector(0, npval-1);
	Fstat = dvector(0, npval-1);
	
	//************* END: Parsing the information file

	////************* BEGIN: Data/arguments for distance
	//if(arg_dist){

	//	dist_nrow = 0; 
	//	dist_ncol = ivector(0, 9);
	//	for(i=0; i<10; i++){
	//		dist_ncol[i] = 1;		
	//	}

	//	if((fi=fopen(ifile_dist, "r"))==NULL) {
	//		printf("Error: Cannot open distance file.\n");
	//	}else{   

	//		c = fgetc(fi);
	//		while(c != EOF){

	//			c=fgetc(fi);

	//			if(c == '\t')
	//				dist_ncol[dist_nrow]++;

	//			if(c =='\n' || (c==EOF && lastchar!='\n')){
	//				dist_nrow++;
	//			}
	//			lastchar = c;
	//		}

	//		fclose(fi);			
	//	}
	//	printf("distance input: #row = %d\n", dist_nrow);
	//	print_iv(dist_ncol, 0, dist_nrow-1, "dist_ncol");

	//	Dg=0; Dpg=0; Duw=0; Dbc=0;  Dj=0; 

	//	if((fi=fopen(ifile_dist, "r"))==NULL) {
	//		printf("Error: Cannot open OTU file.\n");
	//	}else{   

	//		for(i=0; i<dist_nrow; i++){

	//			fscanf(fi, "%s", dummy);


	//			if(strcmp(dummy, "Bray-Curtis")==0){
	//				Dbc = 1;	continue;
	//			}	

	//			
	//			if(strcmp(dummy, "Jaccard")==0){
	//				Dj = 1;	continue;
	//			}	

	//			if(strcmp(dummy, "wUniFrac")==0){
	//				Dg_type[Dg] = 1; 
	//				Dg += 1;
	//				continue;
	//			}

	//			if(strcmp(dummy, "pwUniFrac")==0){
	//				Dpg_type[Dpg] = 1; 
	//				Dpg += 1;
	//				continue;
	//			}

	//			if(strcmp(dummy, "uwUniFrac")==0){
	//				Duw = 1;	continue;
	//			}



	//			if(strcmp(dummy, "gUniFrac")==0){
	//				for(j=1; j<dist_ncol[i]; j++){
	//					fscanf(fi, "%lg", &(Dg_type[Dg]));
	//					Dg += 1;
	//				}
	//				continue;
	//			}

	//			if(strcmp(dummy, "pgUniFrac")==0){
	//				for(j=1; j<dist_ncol[i]; j++){
	//					fscanf(fi, "%lg", &(Dpg_type[Dpg]));
	//					Dpg += 1;
	//				}
	//				continue;
	//			}

	//			printf("\nWarning: Unknown distance option '%s'.\n", dummy);

	//		}



	//		fclose(fi);	
	//		

	//	}

	//	printf("#Dg = %d, #Dpg = %d\n", Dg, Dpg);	
	//	print_dv(Dg_type, 0, Dg-1, "Dw_type");
	//	print_dv(Dpg_type, 0, Dpg-1, "Dpg_type");
	//	printf("#Duw = %d\n", Duw);
	//	printf("#Dbc = %d, #Dj = %d\n", Dbc, Dj);

	//	ndist = Dg + Dpg + Duw + Dbc + Dj; 
	//	if(ndist > 1){
	//		npval = ndist + 1;
	//	}else{
	//		npval = 1;
	//	}
	//	
	//	free_ivector(dist_ncol, 0, 9);
	//}

	//pvalue = dvector(0, npval-1);
	////************* END: Data/arguments for distance

	//************* BEGIN: Data/arguments for OTU

	if(is_biom){

		
		if((fi = fopen(ifile_otu, "r")) != NULL){
			report_otu = transpose( readBiom(fi) );
			fclose(fi);
		}else{
			printf("\nError: Cannot open OTU .biom file.\n");
			kill_miProfile();
		}

		n = report_otu->rowCount;
		m = report_otu->colCount;
		//printf("m=%d, n=%d\n", m,n);

		otu_orig = dmatrix(0, n-1, 0, m-1);

		otu_subID = calloc(n,sizeof(char*));
		for(i=0;i<n;i++){
			otu_subID[i] = calloc(1024,sizeof(char));
		}

		otu_label = calloc(m,sizeof(char*));
		for(j=0;j<m;j++){
			otu_label[j] = calloc(4096,sizeof(char));
		}

		for(j=0; j<m; j++){
			strcpy(otu_label[j],  (report_otu -> colName)[j] );
		}

		for(i=0; i<n; i++){

			strcpy(otu_subID[i],  (report_otu -> rowName)[i] );
			for(j=0; j<m; j++){
				otu_orig[i][j] = (report_otu -> data)[i][j];
			}
		}

		
		//print_sv(otu_subID, 10, "first 10 subjects in OTU tab");
		//print_sv(otu_label, 10, "firest 10 OTU labels in OTU tab");
		//print_dm(otu_orig, 0, 14, 0, 14, "first 15 OTU at first 15 subjects");


		if((fi=fopen("otu_tab_from_biom.txt", "w"))==NULL) {
			printf("Error: Cannot open otu_tab_from_biom.txt.\n");
			kill_miProfile();
		}else{ 
			fprintf(fi, "subject_ID\t");
			for(j=0; j<m-1; j++){
				fprintf(fi, "%s\t", otu_label[j] );
			}
			fprintf(fi, "%s\n", otu_label[m-1] );

			for(i=0; i<n; i++){
				fprintf(fi, "%s\t", otu_subID[i]);
				for(j=0; j<m-1; j++){
					fprintf(fi, "%d\t", (int)(otu_orig[i][j]) );
				}
				fprintf(fi, "%d\n", (int)(otu_orig[i][m-1]) );
			}		
		}

		//if((fi=fopen("testBiom_otu_label", "w"))==NULL) {
		//	printf("Error: Cannot open testBiom_otu file.\n");
		//}else{ 

		//	for(j=0; j<m; j++){
		//		fprintf(fi, "%s\n", otu_label[j] );
		//	}

		//}

		//if((fi=fopen("testBiom_otu_subID", "w"))==NULL) {
		//	printf("Error: Cannot open testBiom_otu file.\n");
		//}else{ 

		//	for(i=0; i<n; i++){
		//		fprintf(fi, "%s\n", otu_subID[i] );
		//	}

		//}


	}else{

		otu_ncol=0; otu_nrow=0;
		if((fi=fopen(ifile_otu, "r"))==NULL) {
			printf("Error: Cannot open OTU file.\n");
		}else{   

			c = fgetc(fi);
			while(c != EOF){

				c=fgetc(fi);

				if(c == '\t')
					otu_ncol++;

				if(c =='\n' || (c==EOF && lastchar!='\n')){
					otu_nrow++;
				}
				lastchar = c;
			}

			fclose(fi);			
		}

		otu_ncol /= otu_nrow;
		otu_ncol += 1;
		//printf("otu_ncol=%d\n", otu_ncol);

		otu_subID = calloc(otu_nrow-1,sizeof(char*));
		for(i=0;i<otu_nrow-1;i++){
			otu_subID[i] = calloc(1024,sizeof(char));
		}

		otu_label = calloc(otu_ncol-1,sizeof(char*));
		for(j=0;j<otu_ncol-1;j++){
			otu_label[j] = calloc(4096,sizeof(char));
		}

		otu_orig = dmatrix(0, otu_nrow-2, 0, otu_ncol-2);

		if((fi=fopen(ifile_otu, "r"))==NULL) {
			printf("\nError: Cannot open OTU file.\n");
		}else{   

			// read headers
			fscanf(fi, "%s", dummy);
			for(j=0; j<(otu_ncol-1); j++){
				fscanf(fi, "%s", otu_label[j] );
			}

			// read otu
			for(i=0; i<(otu_nrow-1); i++){
				fscanf(fi, "%s", otu_subID[i]);
				for(j=0; j<(otu_ncol-1); j++){
					fscanf(fi, "%lg", &(otu_orig[i][j]) );
				}
			}

			fclose(fi);	
		}

		m = otu_ncol - 1;
		n = otu_nrow - 1;

		//************* END: Data/arguments for OTU
	}


	printf("OTU table input: #OTUs = %d, #subjects = %d\n", m, n);
	
	//************* BEGIN: Data/arguments for meta data
	which_cova = ivector(0, meta_ncol-2);
	which_conf = ivector(0, meta_ncol-2);
	for(j=0; j<meta_ncol-1; j++){
		which_cova[j] = -1;
		which_conf[j] = -1;

	}
	which_strata = -1;
	
	meta_subID = calloc(meta_nrow-1,sizeof(char*));
	for(i=0;i<meta_nrow-1;i++){
		meta_subID[i] = calloc(1024,sizeof(char));
	}
	
	meta_orig = dmatrix(0, meta_nrow-2, 0, meta_ncol-2);

	if((fi=fopen(ifile_meta, "r"))==NULL) {
		printf("\nError: Cannot open covariate file.\n");
		kill_miProfile();
	}else{   

		fscanf(fi, "%s", dummy);

		// read headers
		p = 0; q = 0;
		for(j=1; j<meta_ncol; j++){

			fscanf(fi, "%s", dummy);

			flag = 0;

			if(strata){
				if(strcmp(dummy, strata_var)==0){
					which_strata = j-1;
					flag = 1;
				}			
			}
			if(conf){
				for(k=0; k<conf; k++){
					if(strcmp(dummy, conf_var[k])==0){
						which_conf[k] = j-1;
						q++;
						flag = 1;
						break;
					}						
				}

			}

			//printf("j=%d, flag=%d, covariates=%d, p=%d\n", j, flag, cova,p);
			if(flag==0){
				if(cova){
					for(k=0; k<cova; k++){
						if(strcmp(dummy, cova_var[k])==0){
							which_cova[k] = j-1;
							p++;
							break;						
						}

					}
				}else{
					strcpy(cova_var[k], dummy);
					which_cova[p] = j-1;
					p++;
				}

				//printf("which_cova[%d]=%d\n", p, j-1);

			}
		}

		if(strata>0 && which_strata == -1){
			printf("\nError: Cannot find the variable for strata (%s) in the meta data %s\n", strata_var, ifile_meta);
			kill_miProfile();
		}
		if(cova){
			for(k=0; k<cova; k++){
				if(which_cova[k]==-1){
					printf("\nError: Cannot find the variable for covariates (%s) in the meta data %s\n", cova_var[k], ifile_meta);
					kill_miProfile();				
				}
			}		
		}
		if(conf){
			for(k=0; k<conf; k++){
				if(which_conf[k]==-1){
					printf("\nError: Cannot find the variable for confounders (%s) in the meta data %s\n", conf_var[k], ifile_meta);
					kill_miProfile();				
				}
			}
		}
		// read covariates
		for(i=0; i<(meta_nrow-1); i++){
			fscanf(fi, "%s", meta_subID[i]);
			for(j=0; j<(meta_ncol-1); j++){
				fscanf(fi, "%lg", &(meta_orig[i][j]) );
			}
		}

		fclose(fi);	
	}

	//print_sv(meta_subID, 10, "first 10 subjects in covariates file");
	//print_dm(meta_orig, 0, 14, 0, meta_ncol-2, "meta data in the first 15 subjects");

		
	for(i=0; i<(meta_nrow-1); i++){
		if(strcmp(otu_subID[i], meta_subID[i])){
			printf("\nError: subject IDs in the otuFile and the metaFile are not consistent.\n");
			kill_miProfile();				
		}
	}
	//************* END: Data/arguments for meta data



	//************* BEGIN: Data/arguments for tree
	if( Duw!=0 || Dg!=0 || Dpg!=0 ){

		forest* tree;
		int* counts;
		float** edgeMtx = NULL;

		if(m_treeFile==0){
			printf("\nError: -treeFile is not specified.\n");
			kill_miProfile();		
		}

		if((fi = fopen(ifile_tree, "r")) != NULL){
			fclose(fi);
		}else{
			printf("\nError: Cannot open tree file.\n");
			kill_miProfile();
		}

		tree = buildNewickTree(ifile_tree);
		
		i=0; counts=&i;
		tree_nedge = countEdge(tree->tree[0], counts);
		i=0; counts=&i;
		tree_ntip = countTip(tree->tree[0], counts);
		//printf("Tree input: #branches = %d, #tips=%d\n", tree_nedge, tree_ntip);

		tree_brLen = dvector(0, tree_nedge-1);
		tree_upNode = ivector(0, tree_nedge-1);
		tree_downNode = ivector(0, tree_nedge-1);

		i=0; counts = &i;
		edgeMtx = getEdgeWithDist(tree->tree[0], edgeMtx, counts,0);

		for( i=0; i<tree_nedge; i++){
			tree_upNode[i] = (int)edgeMtx[i][0];
			tree_downNode[i] = (int)edgeMtx[i][1];
			tree_brLen[i] = edgeMtx[i][2];
		}


		//print_iv(tree_upNode, 0, 14, "upper node of the first 15 branches");
		//print_iv(tree_downNode, 0, 14, "down node of the first 15 branches");
		//print_dv(tree_brLen, 0, 14, "length of the first 15 branches");

		// have long tip label
		tree_tipLabel = calloc(tree_ntip,sizeof(char*));
		for(j=0;j<tree_ntip;j++){
			tree_tipLabel[j] = calloc(4096,sizeof(char));
		}
		tree_tipLabel_ID = ivector(0, tree_ntip-1);

		i = 0; counts = &i;
		tree_tipLabel = getTipName(tree->tree[0], tree_tipLabel,  counts);
		i = 0; counts = &i;
		tree_tipLabel_ID = getTipID(tree->tree[0], tree_tipLabel_ID,  counts);

		//print_sv(tree_tipLabel, 10, "first 10 tip labels");
		//print_iv(tree_tipLabel_ID, 0, 10, "first 10 tip labels internal ID");

		if( m!= tree_ntip){
			printf("Error: numbers of OTUs do not agree in OTU input and tree input.\n");
			kill_miProfile();
		}else{
			
			nbr = tree_nedge;
			//printf("Final #subjects = %d\n", n);
			//printf("Final #OTU = %d\n", m);
		}

		printf("Tree input: #tips = %d, #branches = %d\n", tree_ntip, tree_nedge);
		//************* END: Data/arguments for tree
	








  //     // read tree data from txt format
		//int tree_edge_ncol=0, tree_edge_nrow=0;
		//if((fi=fopen("tree_edge.txt", "r"))==NULL) {
		//	printf("Error: Cannot open tree_edge file.\n");
		//}else{   

		//	c = fgetc(fi);
		//	while(c != EOF){

		//		c=fgetc(fi);

		//		if(c == '\t')
		//			tree_edge_ncol++;

		//		if(c =='\n' || (c==EOF && lastchar!='\n')){
		//			tree_edge_nrow++;
		//		}
		//		lastchar = c;
		//	}

		//	fclose(fi);			
		//}

		//tree_edge_ncol /= tree_edge_nrow;
		//tree_edge_ncol += 1;

		//if(tree_edge_ncol!=3){
		//	printf("Error: Tree edge file should have 3 columns.\n");
		//}
		//printf("Tree input: #branches = %d\n", tree_edge_nrow-1);

		////tree_brLen = dvector(0, tree_edge_nrow-2);
		////tree_upNode = ivector(0, tree_edge_nrow-2);
		////tree_downNode = ivector(0, tree_edge_nrow-2);

		//if((fi=fopen("tree_edge.txt", "r"))==NULL) {
		//	printf("Error: Cannot open tree_edge file.\n");
		//}else{   

		//	// read headers
		//	for(j=0; j<tree_edge_ncol; j++){
		//		fscanf(fi, "%s", dummy);
		//	}

		//	// read tree info
		//	for(i=0; i<(tree_edge_nrow-1); i++){

		//		fscanf(fi, "%d", &(tree_upNode[i]) );
		//		fscanf(fi, "%d", &(tree_downNode[i]) );
		//		fscanf(fi, "%lg", &(tree_brLen[i]) );

		//	}

		//	fclose(fi);	
		//}

		////print_iv(tree_upNode, 0, 14, "upper node of the first 15 branches");
		////print_iv(tree_downNode, 0, 14, "down node of the first 15 branches");
		////print_dv(tree_brLen, 0, 14, "length of the first 15 branches");

		//tree_ntip = 0;
		//if((fi=fopen("tree_tipLabel.txt", "r"))==NULL) {
		//	printf("Error: Cannot open tree_tipLabel file.\n");
		//}else{   

		//	c = fgetc(fi);
		//	while(c != EOF){

		//		c=fgetc(fi);

		//		if(c =='\n' || (c==EOF && lastchar!='\n')){
		//			tree_ntip++;
		//		}
		//		lastchar = c;
		//	}

		//	fclose(fi);			
		//}

		//printf("Tree input: #tip = %d\n", tree_ntip);
		//// have long tip label
		////tree_tipLabel = calloc(tree_ntip,sizeof(char*));
		////for(j=0;j<tree_ntip;j++){
		////	tree_tipLabel[j] = calloc(4096,sizeof(char));
		////}

		//if((fi=fopen("tree_tipLabel.txt", "r"))==NULL) {
		//	printf("Error: Cannot open tree_tipLabel file.\n");
		//}else{   

		//	// read headers
		//	for(j=0; j<tree_ntip; j++){
		//		fscanf(fi, "%s", tree_tipLabel[j] );
		//	}

		//	fclose(fi);	
		//}

		//print_sv(tree_tipLabel, 10, "first 10 tip labels");

		//if( (otu_ncol-1)!= tree_ntip){
		//	printf("Error: numbers of OTUs do not agree in OTU input and tree input.\n");

		//}else{
		//	
		//	nbr = tree_edge_nrow-1;
		//	printf("Final #subjects = %d\n", n);
		//	printf("Final #OTU = %d\n", m);
		//}

		//************* END: Data/arguments for tree
	
	}

	dist = dmatrix(0, n*(ndist+ndist_input) - 1, 0, n-1);
	//************* BEGIN: Data/arguments for test

	//************* END: Data/arguments for test

   //******************************************************
   //
   //          END: read data/arguments
   //
   //******************************************************



   //******************************************************
   //
   //          BEGIN: process OTU data and meta data
   //
   //******************************************************
	double **otu, **otu_perc, **otu_r_perc;
    int *otu_label_order, *otu_label_rank, *tree_tipLabel_order, *tree_tipLabel_rank,  itmp;
	
	////************* Checking/processing covariates
	//// remove subject with missing values

	otu_label_order = ivector(0, m-1);
	otu_label_rank = ivector(0, m-1);
	tree_tipLabel_order = ivector(0, m-1);
	tree_tipLabel_rank = ivector(0, m-1);
	otu = dmatrix(0, n-1, 0, m-1);
	otu_perc = dmatrix(0, n-1, 0, m-1);
	otu_r_perc = dmatrix(0, n-1, 0, m-1);

	//************* Checking/processing OTU
		//if((fi=fopen("OTU_label_tree_tipLabel.txt", "w"))==NULL) {
		//	printf("Error: Cannot open OTU file.\n");
		//}else{   

		//	// read headers
		//	for(j=0; j<m; j++){
		//		fprintf(fi, "%s\t%s\n", otu_label[j], tree_tipLabel[j] );
		//	}
		//}

	//****** re-arranged OTU in otu tab accroding to the tip labels
	//stringSort(otu_label, otu_label_order, otu_label_rank, m, 2);
	//print_sv(otu_label, 10, "rank of firest 10 OTU labels in otu tab");
	//stringSort(tree_tipLabel, tree_tipLabel_order, tree_tipLabel_rank, m, 2);
	//print_sv(tree_tipLabel, 10, "rank of firest 10 tip labels in tree");

	//for(j=0; j<m; j++){
	//	itmp = tree_tipLabel_order[(int)(otu_label_rank[j])];
	//	printf("%d ", itmp);
	//	for(i=0; i<n; i++){
	//		otu[i][itmp] = otu_orig[i][j];
	//	}
	//	
	//}

	for(j=0; j<m; j++){
		//itmp = tree_tipLabel_order[(int)(otu_label_rank[j])];
		//("%d\t", itmp);
		for(i=0; i<n; i++){
			otu[i][j] = otu_orig[i][j];
		}
		
	}

	free_ivector(otu_label_order, 0, m-1);
	free_ivector(otu_label_rank, 0, m-1);
	free_ivector(tree_tipLabel_order, 0, m-1);
	free_ivector(tree_tipLabel_rank, 0, m-1);
	//if((fo=fopen("OTU_ordered.txt", "w"))==NULL) {
	//	printf("Cannot create output file.\n");
	//	
	//}else{

	//	for(i=0; i<n; i++){
	//		fprintf(fo, "%d\t", (int)(otu[i][0]));
	//		for(j=1; j<m; j++){
	//			fprintf(fo, "\t%d", (int)(otu[i][j]));
	//		}
	//		fprintf(fo, "\n");
	//	}

	//	fclose(fo);
	//}


	

	//print_dm(otu_orig, 0, 14, 0, 14, "otu_orig: first 15 OTU at first 15 subjects");
	//print_dm(otu, 0, 14, 0, 14, "otu (after matching the tip label): first 15 OTU at first 15 subjects");
	
	
	
  
	x = dmatrix(0, p-1, 0, n-1);
	is_binary = ivector(0, p-1);
	//// will read externally from arguments
	//if(q==0){
	//	q = 1; //intercept
	//	for(i=0; i<n; i++){
	//		z[i][0] = 1;
	//	}
	//}

	// make covariates
	for(j=0; j<p; j++){

		for(i=0; i<n; i++){
			x[j][i] = meta_orig[i][which_cova[j]];
		}

		is_binary[j] = 1;
		for(i=0;i<n;i++){

			if( fabs(x[j][i]-0.)<1e-10 ) x[j][i]=0.;
			else if( fabs(x[j][i]-1.)<1e-10 ) x[j][i]=1.;
			else
			{	is_binary[j] = 0;
				break;
			}

		}

	}

	// use the standardized continous x before doing resampling
	for(j=0; j<p; j++){
		if(is_binary[j]==0){
			tmp = mean(x[j], 0, n-1);
			tmp2 = sd(x[j], 0, n-1, tmp);
			for(i=0;i<n;i++){
				x[j][i] = (x[j][i]-tmp)/tmp2;
			}				
		}
	}

	// indicator for binary traits (1) or quantitative (0)

	//printf("p=%d\n", p);
	//print_dm(x, 0, p-1, 0, 10, "covariates");
	//print_iv(is_binary, 0, p-1, "is_binary");

	// make confounders
	if(conf){
		z = dmatrix(0, n-1, 0, q-1);
		for(j=0; j<q; j++){
			for(i=0; i<n; i++){
				z[i][j] = meta_orig[i][which_conf[j]];
			}
		}	
		//printf("q=%d\n", q);
		//print_dm(z, 0, q-1, 0, 10, "confounders");
	}


	// make strata and re-order the observations (covariate, confounder, strata, OTUs, subjectID) such that the subjects within one stratum is together
	if(strata){

		str = ivector(0, n-1);
		str_index = ivector(0, n-1);
		for(i=0; i<n; i++){
			str[i] = (int)(meta_orig[i][which_strata]);
			str_index[i] = str[i];
		}	

		//print_iv(str, 0, 10, "strata");
		// 
		int *str_sort;
		double **x_sort, **z_sort, **otu_sort;
		char **meta_subID_sort;

		str_sort = ivector(0, n-1);
		x_sort = dmatrix(0, p-1, 0, n-1);
		otu_sort = dmatrix(0, n-1, 0, m-1);
		meta_subID_sort = calloc(meta_nrow-1,sizeof(char*));
		for(i=0;i<meta_nrow-1;i++){
			meta_subID_sort[i] = calloc(1024,sizeof(char));
		}
		if(conf){
			z_sort = dmatrix(0, n-1, 0, q-1);
		}

		qRank_noTie_int(n, str_index);

		for(i=0; i<n; i++){
			str_sort[str_index[i]] = str[i];
			for(j=0; j<p; j++){
				x_sort[j][str_index[i]] = x[j][i];	
			}
			for(j=0; j<m; j++){
				otu_sort[str_index[i]][j] = otu[i][j];
			}
			
			strcpy(meta_subID_sort[str_index[i]], meta_subID[i]);
		}
		if(conf){
			for(i=0; i<n; i++){
				for(j=0; j<q; j++){
					z_sort[str_index[i]][j] = z[i][j];	
				}
			}
		}

		// finalize 
		for(i=0; i<n; i++){
			str[i] = str_sort[i];
			for(j=0; j<p; j++){
				x[j][i] = x_sort[j][i];	
			}
			for(j=0; j<m; j++){
				otu[i][j] = otu_sort[i][j];
			}
			strcpy(meta_subID[i], meta_subID_sort[i]);
			
		}
		if(conf){
			for(i=0; i<n; i++){
				for(j=0; j<q; j++){
					z[i][j] = z_sort[i][j];	
				}
			}
		}


		free_ivector(str_sort, 0, n-1);
		free_dmatrix(x_sort, 0, p-1, 0, n-1);
		free_dmatrix(otu_sort, 0, n-1, 0, m-1);
		for (i=0; i<meta_nrow-1; i++) free(meta_subID_sort[i]); free(meta_subID_sort);
		if(conf){
			free_dmatrix(z_sort, 0, n-1, 0, q-1);
		}
		
	}

	
	for(i=0;i<n;i++){

		tmp = 0;
		for(j=0;j<m;j++){

			tmp += otu[i][j];

		}

		if(i==0){
			depth_MIN = (int)(tmp);
		}else{
			if(depth_MIN > (int)(tmp) ){
				depth_MIN = (int)(tmp);
			}
		}

		for(j=0; j<m; j++){
			otu_perc[i][j] = otu[i][j]/tmp;
		}

	}


	//printf("depth_MIN=%d\n", depth_MIN);
	//print_dm(otu_orig, 0, 10, 0, 10, "otu_orig");
	//print_dm(otu, 0, 10, 0, 10, "otu");

	if(depth_MIN > 1){
		for(i=0; i<n; i++){
			rarefy(m, otu[i], depth_MIN);
		}

		for(i=0;i<n;i++){

			for(j=0; j<m; j++){
				otu_r_perc[i][j] = otu[i][j]/depth_MIN;
			}

		}	

	}else{

		for(i=0;i<n;i++){

			for(j=0; j<m; j++){
				otu_r_perc[i][j] = otu_perc[i][j];
			}

		}			
	}

	//if((fo=fopen("otu_perc_post.txt", "w"))==NULL) {
	//	printf("Cannot output Jaccard distance file.\n");

	//}else{

	//	fprintf(fo, "%s", tree_tipLabel[0] );
	//	for(j=1; j<m; j++){
	//		fprintf(fo, "\t%s", tree_tipLabel[j] );
	//	}
	//	fprintf(fo, "\n");

	//	for(i=0; i<n; i++){

	//		if(otu_perc[i][0]==0){
	//			fprintf(fo, "0");
	//		}else{
	//			fprintf(fo, "%.18f", otu_perc[i][0]);
	//		}
	//		
	//		for(j=1; j<m; j++){
	//			if(otu_perc[i][j]==0){
	//				fprintf(fo, "\t0");
	//			}else{
	//				fprintf(fo, "\t%.18f", otu_perc[i][j] );
	//			}
	//			
	//		}
	//		fprintf(fo, "\n");

	//	}

	//	fclose(fo);
	//}

	free_ivector(which_cova, 0, meta_ncol-2);
	free_ivector(which_conf, 0, meta_ncol-2);

	//printf("#tested covariates=%d, #adjusted confounders=%d", p, q);
	// standardized continous x before test

		
	printf("\nFirst few observations of the covariates of interest: \n");
	printf("subject_ID\t");
	for(d=0; d<cova; d++){
		printf("%s\t", cova_var[d]);
	}
	printf("\n");	
	for(i=0; i<min(10, n); i++){
		printf("%s\t", meta_subID[i]);
		for(j=0; j<p; j++){
			printf("%f\t", x[j][i]);
		}
		printf("\n");	
	}

	
	if(conf>0){
		printf("\nFirst few observations of the confounders: \n");
		printf("subject_ID\t");
		for(d=0; d<conf; d++){
			printf("%s\t", conf_var[d]);
		}
		printf("\n");	
		for(i=0; i<min(10, n); i++){
			printf("%s\t", meta_subID[i]);
			for(j=0; j<q; j++){
				printf("%f\t", z[i][j]);
			}
			printf("\n");	
		}
	}
	if(strata>0){
		printf("\nFirst few observations of the strata: \n");
		printf("subject_ID\t%s\n", strata_var);
		
		for(i=0; i<min(10, n); i++){
			
			printf("%s\t%d\n", meta_subID[i], str[i]);
			
		}

	}

	printf("\nFirst few observations of a set of OTUs: \n");
	// cause core dump error when there is no tree file.
	//printf("subject_ID\t");
	//for(j=0; j<min(10, m); j++){
	//	printf("%s\t", tree_tipLabel[j] );
	//}
	//printf("\n");
	for(i=0; i<min(10, n); i++){
		printf("%s\t", meta_subID[i]);
		for(j=0; j<min(10, m); j++){
			printf("%f\t", otu[i][j]);
		}
		printf("\n");	
	}
	


	//******************************************************
	//
	//          END: process OTU data and meta data
	//
	//******************************************************

	//******************************************************
	//
	//          BEGIN: distance calculation
	//
	//******************************************************


	
	if(ndist > 0){

		if( Duw!=0 || Dg!=0 || Dpg!=0 ){
			
					
			//printf("n=%d, m=%d\n", n, m);
			//printf("nbr=%d\n", nbr);
			//printf("\n");
			//printf("Dg = %d\n", Dg);
			//print_dv(Dg_type, 0, Dg-1, "Dg_type");
			//print_iv(Dg_norm_type, 0, Dg-1, "Dg_norm_type");
			//printf("\n");
			//printf("Dpg = %d\n", Dpg);
			//print_dv(Dpg_type, 0, Dpg-1, "Dpg_type");
			//print_iv(Dpg_norm_type, 0, Dpg-1, "Dpg_norm_type");
			//printf("\n");
			//printf("Duw = %d, Duw_norm=%d\n", Duw, Duw_norm);
			//
			//printf("\n");
			//print_iv(tree_tipLabel_ID, 0, m-1, "tree_tipLabel_ID");
			//
			//printf("\n");
			//printf("tree_upNode\ttree_downNode\ttree_brLen\n");
			//for(i=0; i<10; i++){
			//	printf("%d\t%d\t%f\n", tree_upNode[i], tree_downNode[i], tree_brLen[i]);
			//}
			//
			//printf("\n");
			//print_dm(otu_perc, 0, 10, 0, 10, "otu_perc");
			//printf("\n");
			//print_dm(otu_r_perc, 0, 10, 0, 10, "otu_r_perc");

			treeDist_v4(n, m, nbr, Dg, Dg_type, Dg_norm_type, Dpg, Dpg_type, Dpg_norm_type, Duw, Duw_norm, tree_tipLabel_ID, tree_brLen, tree_upNode, tree_downNode, otu_perc, otu_r_perc, dist);

			print_dm(dist, 0, 5, 0, 5, "dist");

			if(Dg>0){

				for(d=0; d<Dg; d++){

					if(Dg_out_type[d]){

						//ret = sprintf(ofile_dist,"Dg_%f", Dg_type[d]);
						if((fo=fopen(ofile_Dg[d], "w"))==NULL) {
							printf("\nError: Cannot output abundance generalized UniFrac distance file.\n");
							kill_miProfile();
						}else{

							for(i=0; i<n; i++){
								fprintf(fo, "%f", dist[d*n+i][0]);
								for(j=1; j<n; j++){
									fprintf(fo, "\t%f", dist[d*n+i][j]);
								}
								fprintf(fo, "\n");

							}

							fclose(fo);
						}					
					}

				}			
			}


			if(Dpg>0){
				
				for(d=0; d<Dpg; d++){

					if(Dpg_out_type[d]){

						//ret = sprintf(ofile_dist,"Dpg_%f", Dpg_type[d]);
						if((fo=fopen(ofile_Dpg[d], "w"))==NULL) {
							printf("\nError: Cannot output presence-absence generalized UniFrac distance file.\n");
							kill_miProfile();
						}else{

							for(i=0; i<n; i++){
								fprintf(fo, "%f", dist[(Dg + d)*n+i][0]);
								for(j=1; j<n; j++){
									fprintf(fo, "\t%f", dist[(Dg + d)*n+i][j]);
								}
								fprintf(fo, "\n");

							}

							fclose(fo);
						}	
					}
				}				
			}


			if(Duw>0){

				if(Duw_out){

					//ret = sprintf(ofile_dist,"Duw");
					if((fo=fopen(ofile_Duw, "w"))==NULL) {
						printf("\nError: Cannot output unweighted UniFrac distance file.\n");
						kill_miProfile();
					}else{

						for(i=0; i<n; i++){
							fprintf(fo, "%f", dist[(Dg + Dpg)*n+i][0]);
							for(j=1; j<n; j++){
								fprintf(fo, "\t%f", dist[(Dg + Dpg)*n+i][j]);
							}
							fprintf(fo, "\n");

						}

						fclose(fo);
					}	
				}

			}

		}
		
		if(Dbc!=0 || Dj!=0){

			Dist_v3(n, m, Dbc, Dbc_norm, Dj, Dj_norm, otu_perc, otu_r_perc, &(dist[(Duw+Dg+Dpg)*n]));

			if(Dbc>0){

				if(Dbc_out){

					//ret = sprintf(ofile_dist,"Dbc");
					if((fo=fopen(ofile_Dbc, "w"))==NULL) {
						printf("\nError: Cannot output Bray-Curtis distance file.\n");
						kill_miProfile();
					}else{

						for(i=0; i<n; i++){
							fprintf(fo, "%f", dist[(Dg + Dpg + Duw)*n+i][0]);
							for(j=1; j<n; j++){
								fprintf(fo, "\t%f", dist[(Dg + Dpg + Duw)*n+i][j]);
							}
							fprintf(fo, "\n");

						}

						fclose(fo);
					}				
				}


			}

			if(Dj>0){

				if(Dj_out){

					//ret = sprintf(ofile_dist,"Dj");
					if((fo=fopen(ofile_Dj, "w"))==NULL) {
						printf("\nError: Cannot output Jaccard distance file.\n");
						kill_miProfile();
					}else{

						for(i=0; i<n; i++){
							fprintf(fo, "%f", dist[(Dg + Dpg + Duw + Dbc)*n+i][0]);
							for(j=1; j<n; j++){
								fprintf(fo, "\t%f", dist[(Dg + Dpg + Duw + Dbc)*n+i][j]);
							}
							fprintf(fo, "\n");

						}

						fclose(fo);
					}				
				}
				
			}

			

		}
		//printf("================= dist ================\n");
		//if(Dg>0){
		//	for(i=0; i<Dg; i++){
		//		print_dm(dist, (i*n), (i*n+10), 0, 10, "Dg");
		//	}
		//}

		//if(Dpg>0){
		//	for(i=0; i<Dpg; i++){
		//		print_dm(dist, (Dg*n + i*n), (Dg*n + i*n+10), 0, 10, "Dpg");
		//	}
		//}

		//if(Duw){
		//	print_dm(dist, ((Dg+Dpg)*n), ((Dg+Dpg)*n+10), 0, 10, "Duw");
		//}

		//if(Dbc){
		//	print_dm(dist, ((Dg+Dpg+Duw)*n), ((Dg+Dpg+Duw)*n+10), 0, 10, "Dbc");
		//}
		//	
		//if(Dj){
		//	print_dm(dist, ((Dg+Dpg+Duw+Dbc)*n), ((Dg+Dpg+Duw+Dbc)*n+10), 0, 10, "Dj");
		//}

	}


	if( ndist_input>0 ){
		
		for(d=0; d<ndist_input; d++){

			if((fi=fopen(ifile_dist[d], "r"))==NULL) {

				printf("\nError: Cannot read distance file %s.\n", ifile_dist[d]);
				kill_miProfile();
			}else{

				for(i=0; i<n; i++){
					for(j=0; j<n; j++){
						
						fscanf(fi, "%lg", &(dist[(ndist+d)*n+i][j]) );
					}
				}


			}		

		}

	}

	//printf("ndist=%d, ndist_input=%d\n", ndist, ndist_input);
	//print_dm(dist, (ndist*n), (ndist*n+10), 0, 10, "Dj");

	//******************************************************
	//
	//          END: distance calculation
	//
	//******************************************************

	//******************************************************
	//
	//          BEGIN: PERMANOVA
	//
	//******************************************************
	//bix=7335; biy=4623; biz=8097;
	if(strata){
		printf("conducting restricted permutation...\n");
	
		PermanovaStrata_woCov_v1(str, n, ndist+ndist_input, max_nperm, dist, p, x, pvalue, Fstat);

	}else{
		if(q==0){

			Permanova_woCov_v1(n, ndist+ndist_input, max_nperm, dist, p, x, pvalue, Fstat);

		}else{

			Permanova_wCov_v1(n, ndist+ndist_input, max_nperm, dist, p, is_binary, x, q, z, pvalue, Fstat);
		}
		
	}
	
	//print_dv(pvalue, 0, npval-1, "pvalue");
	//******************************************************
	//
	//          END: PERMANOVA
	//
	//******************************************************


	//******************************************************
	//
	//          BEGIN: output results
	//
	//******************************************************
	if((fo=fopen(ofile_pvalue, "w"))==NULL) {
		printf("Error: Cannot write to pvalue file.\n");
		kill_miProfile();
	}else{   

		if(Dg>0){
			for(d=0; d<Dg; d++){
				if(Dg_type[d] == 1){
					ret = sprintf(ofile_dist,"Weighted_UniFrac");
					fprintf(fo, "%s\t", ofile_dist);					
				
				}else{
					ret = sprintf(ofile_dist,"Generalized_UniFrac_%.2f", Dg_type[d]);
					fprintf(fo, "%s\t", ofile_dist);				
				}

			}
			
		}
		if(Dpg>0){
			for(d=0; d<Dpg; d++){
				ret = sprintf(ofile_dist,"Presence_Weighted_UniFrac_%.2f", Dpg_type[d]);
				fprintf(fo, "%s\t", ofile_dist);
			}			
		}
		if(Duw>0){
			ret = sprintf(ofile_dist,"Unweighted_UniFrac");
			fprintf(fo, "%s\t", ofile_dist);			
		}
		if(Dbc>0){
			ret = sprintf(ofile_dist,"Bray_Curtis");
			fprintf(fo, "%s\t", ofile_dist);			
		}
		if(Dj>0){
			ret = sprintf(ofile_dist,"Jaccard");
			fprintf(fo, "%s\t", ofile_dist);			
		}
		if(ndist_input>0){
			for(d=0; d<ndist_input; d++){
				fprintf(fo, "%s\t", ifile_dist[d]);
			}
			
		}
		if(ndist+ndist_input>1){
			fprintf(fo, "Unified\t");			
		}
		fprintf(fo, "\n");	

		if(ndist+ndist_input>1){
			
			for(j=0; j<npval-1; j++){
				fprintf(fo, "%E(%E)\t", pvalue[j], Fstat[j] );
			}
			fprintf(fo, "%E\t", pvalue[j] );
			
		}else{
			
			for(j=0; j<npval; j++){
				fprintf(fo, "%E(%E)\t", pvalue[j], Fstat[j] );
			}			
			
		}

		fprintf(fo, "\n");
		fclose(fo);	
	}



	//******************************************************
	//
	//          END: output results
	//
	//******************************************************
	
	for (i=0; i<n; i++) free(otu_subID[i]); free(otu_subID);
	for (j=0; j<m; j++) free(otu_label[j]); free(otu_label);
	free_dmatrix(otu_orig, 0, n-1, 0, m-1);
	for (i=0; i<meta_nrow-1; i++) free(meta_subID[i]); free(meta_subID);
	free_dmatrix(meta_orig, 0, meta_nrow-2, 0, meta_ncol-2);

	for (j=0; j<meta_ncol-1; j++) free(cova_var[j]); free(cova_var);
	for (j=0; j<meta_ncol-1; j++) free(conf_var[j]); free(conf_var);

	if( Duw!=0 || Dg!=0 || Dpg!=0 ){

		free_dvector(tree_brLen, 0, tree_nedge-1);
		free_ivector(tree_upNode, 0, tree_nedge-1);
		free_ivector(tree_downNode, 0, tree_nedge-1);
		for (j=0; j<tree_ntip; j++) free(tree_tipLabel[j]); free(tree_tipLabel);
		free_ivector(tree_tipLabel_ID, 0, tree_ntip-1);
	}
	free_dmatrix(dist, 0, n*(ndist+ndist_input) - 1, 0, n-1);

	free_dmatrix(otu, 0, n-1, 0, m-1);
	free_dmatrix(otu_perc, 0, n-1, 0, m-1);
	free_dmatrix(otu_r_perc, 0, n-1, 0, m-1);
	
	free_dmatrix(x, 0, p-1, 0, n-1);
	free_ivector(is_binary, 0, p-1);
	if(q>0){
		free_dmatrix(z, 0, n-1, 0, q-1);
	}
	if(strata){
		free_ivector(str, 0, n-1);
	}
	free_dvector(pvalue, 0, npval-1);
	free_dvector(Fstat, 0, npval-1);
	free_dvector(Dg_type, 0, MAX_Dg-1);
	free_dvector(Dpg_type, 0, MAX_Dg-1);
	free_ivector(Dg_norm_type, 0, MAX_Dg-1); 
	free_ivector(Dpg_norm_type, 0, MAX_Dg-1); 
	free_ivector(Dg_out_type, 0, MAX_Dg-1); 
	free_ivector(Dpg_out_type, 0, MAX_Dg-1); 
	for (j=0; j<MAX_Dg; j++) free(ofile_Dg[j]); free(ofile_Dg);
	for (j=0; j<MAX_Dg; j++) free(ofile_Dpg[j]); free(ofile_Dpg);
	for (j=0; j<MAX_ifile_dist; j++) free(ifile_dist[j]); free(ifile_dist);
	return(0);
}

