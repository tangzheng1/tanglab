
//info for each node on the tree
struct node{
    int id;  //internal use an unique sequential number 
    char* name;  //name of the node
    float distance; //distance of this node to next level
    
    int childNum;  //number of child node
    struct node** childPtr;  //array of child node
    
    struct node* parentPtr;  //pointer to parent nodei, NULL is root
};
typedef struct node node;

//all tree info
struct forest{
    char* forestName;
    int treeNum;
    int* nodeCounts;
    struct node** tree;
};
typedef struct forest forest; 

//determin if a string is numeric 
int isNumericStr(char* s){
    int i, length = strlen(s);
    int dotCt = 0;
    int flag = 1;
    int aChar;

    for(i = 0; i< length; i++){
        aChar = (int) s[i];
        if(aChar == 46){
            dotCt++;
        }

        if(!((aChar >= 48 && aChar <= 57) || aChar == 46)){
            flag = 0;
            break;
            
        } 

        if(dotCt > 1){
            flag = 0;
            break;
        }
    }
    return flag;
}

//printing data from extractNode()
printExtractNode(int* rst){
    printf("EXTRACTNODE INFO:[%d %d %d %d %d]\n",rst[0], rst[1],rst[2],rst[3],rst[4] );
}

/******************************************************************
Get one node information. beginning and ending positions

return int* val.  
val[0]:  type.  tip= 1, internal = 2, root = 3, invalid node = -1;
val[1]:  node starting position.
val[2]:  node ending position.
val[3]:  if it's an internal node, this is the location of the ending parenthesis
         otherwise -1
val[4]:  position of colon.  if it dosen't exist, it equals to -1
********************************************************************/
int* extractNode(char* s, int startPos, int endPos, int printing){
    int partsEnd = -1,nodeEnd = -1, colonPos = -1;
    int partsFind = 0, comaFind = 0;  //flags.  no = 0 yes = 1
    int balance = -1;  //count the () pairs , when it's 0 we find the position
    int i; //loop counts
    int nonComma = 1;  //flag to remove first comma
    int* val = calloc(5, sizeof(int));
    int type = -1;  //node type: tip = 1; internal = 2
    int newStart = startPos;

    //loop one.  1. search determin node type.  2. remove leading comma
    for(i = startPos; i <= endPos; i++){
        if(nonComma == 1){
            if(s[i] == ',' || s[i] == ';'){
                newStart = i+1;
            } else {
                nonComma = 2;
            }
        }

        if(s[i] == '('){
            partsFind = 1;
            type = 2;
            break;
        }

        if(s[i] == ','){
            if(partsFind == 0 && nonComma == 2){
                type = 1;
                break;
            }
        }
    }

    //one special condition:  single node
    if(type == -1 && startPos < endPos){
        type = 1;
    }

    startPos = newStart;
    val[0] = type;

    //processing internal node
    if(type == 2){
        for(i = startPos; i <= endPos; i++){
            if(s[i] == '(' && partsEnd == -1){
                if(balance == -1){
                    //find first ( then initialize balance
                    balance = 0;
                }
                balance++;
            }

            if(s[i] == ')' && balance > 0){
                balance--;
            }

            if(balance == 0 && partsEnd == -1){
                partsEnd = i;
            }else {
                if(balance == 0){
                    if(s[i] == ':'){
                        colonPos = i;
                    }

                    if(s[i] == ',' || s[i]== ';' || s[i] == ')' || i == endPos){
                    
                        if(s[i] == ',' || s[i]== ';'){
                            nodeEnd = i-1;
                        }else if(s[i] == ')'){
                            if(colonPos ==-1){
                                nodeEnd = i-1;
                            }else{
                                nodeEnd = i;
                            }
                        }else{
                            nodeEnd = i;
                        }
                        break;  //get out of the loop
                    }
                }
            }

        }
        val[1] = newStart;  //starting position
        val[2] =  nodeEnd;  //ending position
        val[3] = partsEnd;
        val[4] = colonPos;
    }

    //processing tip node
    if(type == 1){
        for(i = startPos; i <= endPos; i++){
            if(s[i] == ':'){
                colonPos = i;
            }

            if(s[i] == ',' || s[i]== ';' || s[i] == ')' || i == endPos){
                if(s[i] == ',' || s[i]== ';'){
                    nodeEnd = i-1;
                }else {
                    nodeEnd = i;
                }
                break;  //get out of the loop
            }
        }
        val[1] = newStart;  //starting position
        val[2] =  nodeEnd;  //ending position
        val[3] = -1;
        val[4] = colonPos;
    }

    //determine root node
    if(val[2] == val[3] && s[nodeEnd+1] == ';'){
         val[0] = 3;
    }

    //determine invalid node
    if(nodeEnd == -1 || val[1] == val[2]){
        val[0] = -1;
    }

    if(printing != 0){
        printExtractNode(val);
    }

    return val;
}

node* searchById(node* aNode, int id){
    int i;
    node* ptr = NULL;
    if(aNode-> id == id){
        ptr = aNode;
    }else{
        if(aNode-> childNum >1){
            for(i = 0; i< aNode-> childNum; i++){
                ptr = searchById(aNode->childPtr[i], id);
                if(ptr != NULL){
                    break;
                }
            }
        }
    }
    return ptr;
}


//WARNING!!! NOT WORKING FOR LONG STRINGS.  BUG ON strcmp()
node* searchByName(node* aNode, char* name){
    int i;
    node* ptr = NULL;

    if(aNode-> name != NULL){
        if(strcmp(aNode-> name, name) == 0){
            ptr = aNode;
        }
    }else{
        if(aNode-> childNum >1){
            for(i = 0; i< aNode-> childNum; i++){
                ptr = searchByName(aNode->childPtr[i], name);
                if(ptr != NULL){
                    break;
                }
            }
        }
    }

    return ptr;
}

void printNode(node* aNode){
    if(aNode == NULL){
        printf("node not found\n");
    } else {
        printf("node info: %d %s %f %d\n", aNode-> id, aNode-> name, aNode-> distance,aNode-> childNum);    
    }
}

void printEdge(node* aNode){
    int i;
    node* child;
    int counts;

    if(aNode-> childNum >1){
        counts = aNode-> id;

        for(i = 0; i< aNode-> childNum; i++){
            child = aNode->childPtr[i];
            printf("parentId: %d childId: %d childName:[%s]\n", counts, child-> id, child-> name);
            printEdge(child);
        }
    }

}

void printEdgeWithDist(node* aNode){
    int i;
    node* child;
    int counts;

    if(aNode-> childNum >1){
        counts = aNode-> id;

        for(i = 0; i< aNode-> childNum; i++){
            child = aNode->childPtr[i];
            printf("parentId: %d childId: %d distance %f childName:[%s]\n", counts, child-> id, child-> distance,child-> name);
            printEdgeWithDist(child);
        }
    }

}

int  countTip(node* aNode, int* counts){
    int i;

    if(aNode-> childNum == 0){
        *counts = *counts + 1;
    }else{
        for(i = 0; i< aNode-> childNum; i++){
            countTip(aNode-> childPtr[i], counts);
        }
    }

    return *counts;
}

char** getTipName(node* aNode, char** tip, int* count){
    int i = 0,j;
    node* child;
    int* myc;
    myc = &i;

    if(tip == NULL){
        count = &i; //initialize count to 0;
        i = countTip(aNode, myc);
        //allocate memory
        tip = calloc(i, sizeof(char*));

        i = 0;
        count = &i;  //initialize count
        getTipName(aNode, tip,count);
    } else {
        if(aNode-> childNum > 0){
            for(i = 0; i< aNode-> childNum; i++){
                child = aNode->childPtr[i];
                getTipName(child, tip,count);
            }
        }else {
            tip[*count] = calloc(strlen(aNode->name), sizeof(char*));
            memcpy(tip[*count], aNode->name, strlen(aNode->name));
            *count = *count + 1;
        }
    }

    return tip;
}


int* getTipID(node* aNode, int* tip, int* count){
    int i = 0,j;
    node* child;
    int* myc;
    myc = &i;

    if(tip == NULL){
        count = &i; //initialize count to 0;
        i = countTip(aNode, myc);
        //allocate memory
        tip = calloc(i, sizeof(int));

        i = 0;
        count = &i;  //initialize count
        getTipID(aNode, tip,count);
    } else {
        if(aNode-> childNum > 0){
            for(i = 0; i< aNode-> childNum; i++){
                child = aNode->childPtr[i];
                getTipID(child, tip,count);
            }
        }else {
            tip[*count] = aNode->id;
            *count = *count + 1;
        }
    }

    return tip;
}



//counting number of edges
int countEdge(node* aNode, int* counts){
    int i;

    if(aNode-> childNum >1){
        for(i = 0; i< aNode-> childNum; i++){
            countEdge(aNode-> childPtr[i], counts);
            *counts = *counts + 1;
        }
    }

    return *counts;
}

int**  getEdge(node* aNode, int** edge, int* count, int parentId){
    int i = 0,j;
    node* child;
    int* myc;
    myc = &i;

    if(edge == NULL){
        count = &i; //initialize count to 0;
        i = countEdge(aNode, myc);
//        printf("edges: %d\n", i);

        //allocate memory
        edge = calloc(i, sizeof(int*));
        for(j = 0; j< i; j++){
            edge[j] = calloc(2, sizeof(int));
        }

        i = 0;
        count = &i;  //initialize count
        getEdge(aNode, edge,count,aNode->id);
    } else {
        if(aNode-> childNum >1){
            for(i = 0; i< aNode-> childNum; i++){
                child = aNode->childPtr[i];
                edge[*count][0] = parentId;
                edge[*count][1] = child-> id;
                *count = *count + 1;
                getEdge(child, edge,count,child-> id);
            }
        }
    }

    return edge;
}

float**  getEdgeWithDist(node* aNode, float** edge, int* count, int parentId){
    int i = 0,j;
    node* child;
    int* myc;
    myc = &i;

    if(edge == NULL){
        count = &i; //initialize count to 0;
        i = countEdge(aNode, myc);
//        printf("edges: %d\n", i);

        //allocate memory
        edge = calloc(i, sizeof(int*));
        for(j = 0; j< i; j++){
            edge[j] = calloc(3, sizeof(int));
        }

        i = 0;
        count = &i;  //initialize count
        getEdgeWithDist(aNode, edge,count,aNode->id);
    } else {
        if(aNode-> childNum >1){
            for(i = 0; i< aNode-> childNum; i++){
                child = aNode->childPtr[i];
                edge[*count][0] = parentId;
                edge[*count][1] = child-> id;
                edge[*count][2] = child-> distance;
                *count = *count + 1;
                getEdgeWithDist(child, edge,count,child-> id);
            }
        }
    }

    return edge;
}



printNodeNames(node* aNode, int* counts){
    int i;
    if(aNode-> name != NULL){
        printf("counts: %d id: %d node name:[%s]\n", *counts, aNode-> id, aNode-> name);
        *counts = *counts+1;
    }
    if(aNode-> childNum >1){
        for(i = 0; i< aNode-> childNum; i++){
            printNodeNames(aNode->childPtr[i], counts);
        }
    }

}

void printATree(node* aNode){
    //int id, char* name, float distance, int childNum, struct node** childPtr
    int i;
    printNode(aNode);
    if(aNode-> childNum >1){
        for(i = 0; i< aNode-> childNum; i++){
            printATree(aNode->childPtr[i]);
        }
    } 
}

void printNewickiToFile(node* tree){

}


//find number of nudes within given string section
//searching string s within the section defined by startp and endp.  put result in map
//return number of node found.  reutrn -1 if no node found
int getNodeCount(char* s, int* val){
    int i, sLoc, eLoc, nodeCt = 0, nCt;
    int* searchRst;

    //invalid node
    if(val[0] == -1){
        nodeCt = 0;
    }

    //tip node
    if(val[0] == 1){
        nodeCt = 1;
    }

    //root or internal node
    if(val[0] == 2 || val[0] == 3){
        sLoc = val[1] + 1;  //new start position
        eLoc = val[3] ;  //new ending

        while(sLoc < eLoc){
            searchRst = extractNode(s, sLoc, eLoc, 0);
            if(searchRst[0] != -1){
                sLoc = searchRst[2] + 1;
                nodeCt++;
            } else{
                break;
            }
        }
    }

    return nodeCt;
}

int** getNodeInfo(char* s, int* val, int nodeCt, int printing){
    int i, sLoc, eLoc,  nCt;
    int* searchRst;
    int** map;

    //invalid node
    if(val[0] == -1){
        nodeCt = 0;
    }

    //tip node
    if(val[0] == 1 ){
        nodeCt = 1;
        map = calloc(nodeCt,sizeof(int*));
        if(map == NULL){
            printf("OUT OF MEMORY!!! (getNodeInfo1)\n");
            exit(-1);
        }

        map[0] = val;
    }

    //root or internal node
    if(val[0] == 2 || val[0] == 3){
        sLoc = val[1] + 1;
        eLoc = val[3] ;
        map = calloc(nodeCt, sizeof(int*));
        if(map == NULL){
            printf("OUT OF MEMORY!!! (getNodeInfo2)\n");
            exit(-1);
        }

        i = 0;
        while(sLoc < eLoc){
            searchRst = extractNode(s, sLoc, eLoc, 0);

            if(searchRst[0] != -1){
                sLoc = searchRst[2] + 1;
                map[i] = searchRst;
                i++;
            } else{
                free(searchRst);
                break;
            }
        }
    }

    if(printing != 0){
        printf("Printing node info:\n");
        for(i = 0; i< nodeCt; i++){
            printf("[%d %d %d %d %d]\n", map[i][0], map[i][1],map[i][2],map[i][3],map[i][4]);
        }
        printf("Printing node info END\n\n");
    }
    return map;
}


//s:  string to be used to build tree
//startPos:  starting position on the string to be used
//endPos:  ending position on the string to be used
//id:  node id
//return: a pointer to the built node
node* buildNode(char* s, int startPos, int endPos, int* id, node* parent){
    int i;
    node* aNode = calloc(1, sizeof(node));
    int* myEnd = extractNode(s, startPos, endPos+1, 0);
    char* mydist;
    char* myname;
    int* extracts;
    int nameEnd;
    int nodeCt;
    int** nodeInfo;

    aNode-> parentPtr = parent;  //assign parent node

    //tip node
    if(myEnd[0] == 1){
       //processing distance and name info
        if(myEnd[4] != -1){
            //with distance
            mydist = calloc(myEnd[2] - myEnd[4], sizeof(char));

            memcpy(mydist, s+myEnd[4]+1, myEnd[2] - myEnd[4]); 
            aNode->distance = atof(mydist);
            free(mydist);
            //name
            nameEnd = myEnd[4]-1; //one char before :
        }else{
            aNode->distance = -1;  //if there is no distance set value to -1
            nameEnd = myEnd[2];  //location of node end
        }

        myname = calloc(nameEnd - myEnd[1]+1, sizeof(char));
        if(myname == NULL){
                printf("OUT OF MEMORY!!! (buildNode3)\n");
                exit(-1);
        }

        memcpy(myname, s+ myEnd[1], nameEnd - myEnd[1]+1);
        aNode->name = myname;
        aNode->childNum = 0;
        aNode-> childPtr = NULL;
        aNode -> id = *id;
        *id = *id+1;
    }

    //root node
    if(myEnd[0] == 3){
        aNode->distance = -1;  //root node has no distance
        aNode->name = NULL; //root node has no namei
        extracts = myEnd;
        nodeCt = getNodeCount( s,  extracts);
        nodeInfo = getNodeInfo( s,  extracts, nodeCt, 0);
        aNode->childNum = nodeCt;
        aNode->childPtr = calloc(nodeCt, sizeof(node));

        aNode -> id = *id;
        *id = *id+1;
        for(i = 0; i< nodeCt; i++){
            aNode->childPtr[i] = buildNode(s, nodeInfo[i][1], nodeInfo[i][2],  id, NULL);
        }
        free(nodeInfo);
    }

    //internal nodes
    if(myEnd[0] == 2){
       //processing distance and name info
        if(myEnd[4] != -1){
            //with distance
            mydist = calloc(myEnd[2] - myEnd[4], sizeof(char));
            memcpy(mydist, s+myEnd[4]+1, myEnd[2] - myEnd[4]);
            aNode->distance = atof(mydist);
            free(mydist);

            //name
            nameEnd = myEnd[4]-1; //one char before :
        }else{
            aNode->distance = -1;  //if there is no distance set value to -1
            nameEnd = myEnd[2];  //location of node end
        }

        myname = calloc(nameEnd - myEnd[3], sizeof(char));
        memcpy(myname, s+ myEnd[3]+1, nameEnd - myEnd[3]);

        if(isNumericStr(myname) == 1){
            aNode->name = NULL;
        } else {
            aNode->name = myname;
        }

        extracts = myEnd;
        nodeCt = getNodeCount( s,  extracts);
        nodeInfo = getNodeInfo( s,  extracts, nodeCt, 0);
        aNode->childNum = nodeCt;
        aNode->childPtr = calloc(nodeCt, sizeof(node));


        aNode -> id = *id;
        *id = *id+1;
        for(i = 0; i< nodeCt; i++){
            aNode->childPtr[i] = buildNode(s, nodeInfo[i][1], nodeInfo[i][2],  id, aNode);
        }
        free(nodeInfo);
    }

    //release memory
    free(myEnd);
    return aNode;  //temporary return
}

forest* buildNewickTree(char* fileName){
    FILE *inFilePtr;
    int fcount = 0, treeCount = 0, i, startp, endp;
    int* nodeId;
    char cha;
    int* semiCol;  //position of semicolon in a string.  this determin the beginning and ending of a tree
    char* str; //str to store the file content
    forest* maple;

    if((inFilePtr = fopen(fileName, "r")) != NULL){
        while(!feof(inFilePtr)){
            if((int) fgetc(inFilePtr) == 59){
                treeCount++;
            }
            fcount++;
        }

        rewind(inFilePtr); //reset file pointer
        str = calloc(fcount, sizeof(char));
        semiCol = calloc(treeCount, sizeof(int));
        fcount = 0;  //reset
        treeCount = 0;
        while(!feof(inFilePtr)){
            cha = fgetc(inFilePtr);

            //only get printable characters, ascii code > 32
            if((int) cha > 32){
                str[fcount] = cha;

                //search for ; ascii code 59
                if((int) cha == 59){
                    semiCol[treeCount] = fcount;
                    treeCount++;
                }
                fcount++;
            }
        }
        fclose(inFilePtr);  //close file pointer

        //build forest/tree
        nodeId = calloc(1, sizeof(int));
        maple = calloc(1, sizeof(forest));
        maple-> forestName = NULL;
        maple-> treeNum = treeCount;
        maple-> tree = calloc(treeCount, sizeof(node*));
        maple-> nodeCounts = calloc(treeCount, sizeof(int));

        for( i = 0; i < treeCount; i++){
//            printf("TREE number %d\n", i);

            if(i == 0){
                startp = 0;
                endp = semiCol[i];
            }else {
                startp = semiCol[i-1]+1;
                endp = semiCol[i];
            }
            maple->tree[i] = buildNode(str,startp,endp, nodeId, NULL);
            maple->nodeCounts = nodeId;
            *nodeId = 0;
        }
    }
    //end of if/fileName

    return maple;
}
