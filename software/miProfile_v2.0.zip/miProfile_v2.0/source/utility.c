#include "utility.h"
#include <stdio.h>
#include <math.h>
#include <float.h>
#include <string.h>
#include <stdlib.h>
 
//===================================
//	  BASIC: BEGIN
//===================================
double gammln(double xx)
{

    double x, y, tmp, ser;
    static const double cof[6] = { 76.18009172947146,-86.50532032941677,24.01409824083091,
            -1.231739572450155, 0.1208650973866179e-2, -0.5395239384953e-5};

    int j;

    y = x = xx;
    tmp = x+5.5;
    tmp -= (x+0.5)*log(tmp);
    ser = 1.000000000190015;

        for (j=0; j < 6; j++)
            ser += cof[j]/++y;

    return -tmp+log(2.5066282746310005*ser/x);
}

//===================================
//	  BASIC: END
//===================================


//===================================
//	  SPACE ALLOCATION: BEGIN
//===================================
//===================================================================
// function to allocate space for vector and matrix: from nrutil.cpp
void nrerror(const char* error_text)
{
//    void exit(int);

    fprintf(stderr,"Numerical Recipes run-time error...\n");
    fprintf(stderr,"%s\n",error_text);
    fprintf(stderr,"...now exiting to system...\n");
    system("pause");
    exit(1);
}

int *ivector(int nl, int nh)
	/* allocate a int vector with subscript range v[nl..nh] */
{
    int *v;
    v=(int *)malloc((unsigned) (nh-nl+1)*sizeof(int));
    if (!v) nrerror("allocation failure in ivector()");
    return v-nl;
}

void free_ivector(int *v, int nl, int nh)
{free((char*) (v+nl));
}

double *dvector(long nl, long nh)
/* allocate a double vector with subscript range v[nl..nh] */
{
	double *v;
	v=(double *)malloc((size_t) ((nh-nl+1)*sizeof(double)));
	if (!v) nrerror("allocation failure in dvector()");
	return v-nl;
}

void free_dvector(double *v, long nl, long nh)
/* free a double vector allocated with dvector() */
{
	free((char*) (v+nl));
}


double **dmatrix(long nrl, long nrh, long ncl, long nch)
/* allocate a double matrix with subscript range m[nrl..nrh][ncl..nch] */
{
	long i, nrow=nrh-nrl+1,ncol=nch-ncl+1;
	double **m;
	/* allocate pointers to rows */
	m=(double **) malloc((size_t)((nrow)*sizeof(double*)));
	if (!m) nrerror("allocation failure 1 in matrix()");
	m += 0;
	m -= nrl;
	/* allocate rows and set pointers to them */
	m[nrl]=(double *) malloc((size_t)((nrow*ncol)*sizeof(double)));
	if (!m[nrl]) nrerror("allocation failure 2 in matrix()");
	m[nrl] += 0;
	m[nrl] -= ncl;
	for(i=nrl+1;i<=nrh;i++) m[i]=m[i-1]+ncol;
	/* return pointer to array of pointers to rows */
	return m;
}

void free_dmatrix(double **m, long nrl, long nrh, long ncl, long nch)
/* free a double matrix allocated by dmatrix() */
{
	free((char*) (m[nrl]+ncl));
	free((char*) (m+nrl));
}

int **imatrix(long nrl, long nrh, long ncl, long nch)
/* allocate a double matrix with subscript range m[nrl..nrh][ncl..nch] */
{
	long i, nrow=nrh-nrl+1,ncol=nch-ncl+1;
	int **m;
	/* allocate pointers to rows */
	m=(int **) malloc((size_t)((nrow)*sizeof(int*)));
	if (!m) nrerror("allocation failure 1 in matrix()");
	m += 0;
	m -= nrl;
	/* allocate rows and set pointers to them */
	m[nrl]=(int *) malloc((size_t)((nrow*ncol)*sizeof(int)));
	if (!m[nrl]) nrerror("allocation failure 2 in matrix()");
	m[nrl] += 0;
	m[nrl] -= ncl;
	for(i=nrl+1;i<=nrh;i++) m[i]=m[i-1]+ncol;
	/* return pointer to array of pointers to rows */
	return m;
}

void free_imatrix(int **m, long nrl, long nrh, long ncl, long nch)
/* free a double matrix allocated by dmatrix() */
{
	free((char*) (m[nrl]+ncl));
	free((char*) (m+nrl));
}

//===================================
//	  SPACE ALLOCATION: END
//===================================


//===================================
//	  O/I: BEGIN
//===================================

void print_dv(double *vector, int starti, int endi, const char *pstring){
	printf("\n=== %s ===\n", pstring);
	int i;
	for(i=starti;i<=endi;i++){
		printf("%e ", vector[i]);
	}
	printf("\n");
}

void print_iv(int *vector, int starti, int endi, const char *pstring){
	printf("\n=== %s ===\n", pstring);
	int i;
	for(i=starti;i<=endi;i++){
		printf("%d ", vector[i]);
	}
	printf("\n");
}


void print_dm(double **matrix, int starti, int endi, int startj, int endj, const char *pstring){
	printf("\n=== %s ===\n", pstring);
	int i, j;
	for(i=starti;i<=endi;i++){
		for(j=startj;j<=endj;j++){
			printf("%e ", matrix[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}

void print_im(int **matrix, int starti, int endi, int startj, int endj, const char *pstring){
	printf("\n=== %s ===\n", pstring);
	int i, j;
	for(i=starti;i<=endi;i++){
		for(j=startj;j<=endj;j++){
			printf("%d ", matrix[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}

void print_sv(char **array, int len, const char *pstring) 
{ 
	printf("\n=== %s ===\n", pstring);
    int i;
 
    for(i=0; i<len; i++) 
        printf("%s | ", array[i]);
 
    putchar('\n');
} 

//===================================
//	  O/I: END
//===================================

//===================================
//	  OBJECT MANIPULATION: START 
//===================================
double mean(double* x, long nl, long nh)
{
    double sum = 0.0;
    long i;
    for(i=nl; i<=nh; i++){
        sum += x[i];
    }
    sum /= (nh-nl+1);
    return(sum);
}

double sd(double* x, long nl, long nh, double mean_x)
{
  double sum2=0.0, t, sd;
  long i;
  long n = nh - nl + 1;
  for(i=nl; i<=nh; i++){
      t = x[i] - mean_x;
      sum2 += t*t;
  }
  sum2 /= n;
  sd = sqrt(sum2);

  if (sd < 1e-10) { sd = 1e-10; }

  return(sd);
}

double median(double *x, long nl, long nh) {

    double *tmp, temp;
    long i, j;
	long n = nh - nl + 1;

	tmp = dvector(0, n-1);

	for(i=nl; i<=nh; i++){
		tmp[i-nl] = x[i];
	}
    // the following two loops sort the array x in ascending order
    for(i=0; i<n-1; i++) {
        for(j=i+1; j<n; j++) {
            if(tmp[j] < tmp[i]) {
                // swap elements
                temp = tmp[i];
                tmp[i] = tmp[j];
                tmp[j] = temp;
            }
        }
    }
 
    if(n%2==0) {
        // if there is an even number of elements, return mean of the two elements in the middle
        return((tmp[n/2] + tmp[n/2 - 1]) / 2.0);
    } else {
        // else return the element in the middle
        return tmp[n/2];
    }

	free_dvector(tmp, 0, n-1);
}


double sd_MAD(double *x, long nl, long nh) {

	double *tmp, x_median;
	long i, j;
	long n = nh - nl + 1;
	tmp = dvector(0, n-1);


	x_median = median(x, nl, nh);

	for(i=0; i<n; i++){
		tmp[i] = fabs(x[i+nl] - x_median);
	}

	return (1.4826 * median(tmp, 0, n-1));

	free_dvector(tmp, 0, n-1);

}


int cmp(const void *a, const void *b) 
{ 
    const double **ia = (const double **)a; // casting pointer types 
    const double **ib = (const double **)b;
	if(**ia  > **ib)	return 1;
	if(**ia  == **ib)	return 0;
    if(**ia  < **ib)	return -1;
}

void qRank_noTie(long arrayLen, double *Array){

	long i, j;
	double **pArray;

	//double ** pArray = new double*[arrayLen];
	pArray = (double **) malloc((size_t) ((arrayLen)*sizeof(double*)));
	if (!pArray) nrerror("allocation failure for pArray");

	for(i = 0; i < arrayLen; ++i)
	{
		pArray[i] = &Array[i];
	}

	// This function sorts the pointers according to the values they
	// point to. In effect, it sorts intArray without losing the positional
	// information.
	//double *s;
	//for(i=0;i<arrayLen-1;++i){
	//	for(j=1;j<arrayLen-i;++j){
	//		if(*pArray[j-1]>*pArray[j]){
	//			s=pArray[j-1];
	//			pArray[j-1]=pArray[j];
	//			pArray[j]=s;
	//		}
	//	}
	//}
	qsort(pArray, arrayLen, sizeof(double*), cmp);

	// Dereference the pointers and assign their sorted position.
	for(i = 0; i < arrayLen; ++i)	*pArray[i] = i;

	free((char**) (pArray));

}


int cmp_int(const void *a, const void *b) 
{ 
    const int **ia = (const int **)a; // casting pointer types 
    const int **ib = (const int **)b;
	if(**ia  > **ib)	return 1;
	if(**ia  == **ib)	return 0;
    if(**ia  < **ib)	return -1;
}

void qRank_noTie_int(int arrayLen, int *Array){

	int i, j;
	int **pArray;

	pArray = (int **) malloc((size_t) ((arrayLen)*sizeof(int*)));
	if (!pArray) nrerror("allocation failure for pArray");

	for(i = 0; i < arrayLen; ++i)
	{
		pArray[i] = &Array[i];
	}

	qsort(pArray, arrayLen, sizeof(int*), cmp_int);

	// Dereference the pointers and assign their sorted position.
	for(i = 0; i < arrayLen; ++i)	*pArray[i] = i;

	free((char**) (pArray));

}

char** stringSort(char** s, int *order_s, int *rank_s, int n, int order){

    char *temp;
    char** str;
    int i, j, tmp;

    str = calloc(n, sizeof(char*));
    for(i = 0; i<n;i++){
        str[i] = calloc(strlen(s[i]), sizeof(char));
        strcpy(str[i], s[i]);
    }

	for(i=0; i<n; i++){
		order_s[i] = i;
	}

    for (i = 0; i < n; i++) {
       for (j = 0; j < n - 1; j++) {

            if(order == 2){
                if (strcmp(str[j], str[j + 1]) > 0) {
                    temp = calloc(strlen(str[j]), sizeof(char));
                    strcpy(temp, str[j]);
                    free(str[j]);
                    str[j] = calloc(strlen(str[j+1]), sizeof(char));
                    strcpy(str[j], str[j + 1]);
                    free(str[j + 1]);
                    str[j+1] = calloc(strlen(temp), sizeof(char));
                    strcpy(str[j + 1], temp);
                    free(temp);

					tmp = order_s[j];
					order_s[j] = order_s[j+1];
					order_s[j+1] = tmp;
					
               }
           }

            if(order == 1){
                if (strcmp(str[j], str[j + 1]) < 0) {
                    temp = calloc(strlen(str[j]), sizeof(char));
                    strcpy(temp, str[j]);
                    free(str[j]);
                    str[j] = calloc(strlen(str[j+1]), sizeof(char));
                    strcpy(str[j], str[j + 1]);
                    free(str[j + 1]);
                    str[j+1] = calloc(strlen(temp), sizeof(char));
                    strcpy(str[j + 1], temp);
                    free(temp);

					tmp = order_s[j];
					order_s[j] = order_s[j+1];
					order_s[j+1] = tmp;
               }
           }

           
       }
    }
 
	for(i=0; i<n; i++){
		rank_s[order_s[i]] = i;
	}

   return str;
}

// BEGIN: MATRIX INVERSE
//invert a matrix A
//simply call invv(A, p), where "p" is the length of row/column.
void ludcmp(double **a,int n,int *indx)
{
    int i,imax,j,k;
    double big,dum,sum,temp;
    double *vv, TINY;

        TINY=1.0e-40;
    vv=dvector(1,n);
    for (i=1;i<=n;i++) {
        big=0.0;
        for (j=1;j<=n;j++)
            if ((temp=fabs(a[i][j])) > big) big=temp;
        if (big == 0.0) nrerror("Sigmatrix in ludcmp");
        vv[i]=1.0/big;
    }
    for (j=1;j<=n;j++) {
        for (i=1;i<j;i++) {
            sum=a[i][j];
            for (k=1;k<i;k++) sum -= a[i][k]*a[k][j];
            a[i][j]=sum;
        }
        big=0.0;
        for (i=j;i<=n;i++) {
            sum=a[i][j];
            for (k=1;k<j;k++)
                sum -= a[i][k]*a[k][j];
            a[i][j]=sum;
            if ( (dum=vv[i]*fabs(sum)) >= big) {
                big=dum;
                imax=i;
            }
        }
        if (j != imax) {
            for (k=1;k<=n;k++) {
                dum=a[imax][k];
                a[imax][k]=a[j][k];
                a[j][k]=dum;
            }
            vv[imax]=vv[j];
        }
        indx[j]=imax;
        if (a[j][j] == 0.0) a[j][j]=TINY;
        if (j != n) {
            dum=1.0/(a[j][j]);
            for (i=j+1;i<=n;i++) a[i][j] *= dum;
        }
    }
    free_dvector(vv,1,n);
}

void lubksb(double **a, int n, int *indx, double *b)
{
    int i,ii=0,ip,j;
    double sum;

    for (i=1;i<=n;i++) {
        ip=indx[i];
        sum=b[ip];
        b[ip]=b[i];
        if (ii)
            for (j=ii;j<=i-1;j++)
                     sum -= a[i][j]*b[j];
        else if (sum) ii=i;
        b[i]=sum;
    }
    for (i=n;i>=1;i--) {
        sum=b[i];
        for (j=i+1;j<=n;j++) sum -= a[i][j]*b[j];
        b[i]=sum/a[i][i];
    }
}
void invv(double **fma, int nn)  /* any nn x nn matrix's inverse */
{
    int  i, j, k, *indx;
    double *COL, **ipi;

    indx=ivector(1, nn);    COL=dvector(1, nn);     ipi=dmatrix(1, nn, 1, nn);

    ludcmp(fma, nn, indx);
    for(i=1; i<=nn; i++){
        for(j=1; j<=nn; j++) COL[j]=0.0;
        COL[i]=1.0;
        lubksb(fma, nn, indx, COL);
        for(j=1; j<=nn; j++) ipi[j][i]=COL[j];
    }
    for(k=1; k<=nn; k++)
        for(i=1; i<=nn; i++) fma[k][i]=ipi[k][i];

    free_ivector(indx, 1, nn);
    free_dvector(COL, 1, nn);
    free_dmatrix(ipi, 1, nn, 1, nn);

}   // end of invv.c /

// END: MATRIX INVERSE


// START: DETERMINANT
// LU decomposition for determinant function
void ludcmp2(double **a, int n, int *indx, double *d)
{
	int i,imax,j,k;
	double big,dum,sum,temp;
	double *vv, TINY; 
	TINY=1.0e-40;
	vv=dvector(1,n);
	*d=1.0; 
	for (i=1;i<=n;i++) { 
		big = 0.0;
		for (j=1;j<=n;j++)
			if ((temp=fabs(a[i][j])) > big) big=temp;
		if (big == 0.0) {
			*d = 0.;
			break;
		}
		vv[i]=1.0/big; 
	}
	if(*d > 0.){
		for (j=1;j<=n;j++) {
			for (i=1;i<j;i++) { 
				sum=a[i][j];
				for (k=1;k<i;k++) sum -= a[i][k]*a[k][j];
				a[i][j]=sum;
			}
			big=0.0; 
			for (i=j;i<=n;i++) { 
				sum=a[i][j]; 
				for (k=1;k<j;k++)
					sum -= a[i][k]*a[k][j];
				a[i][j]=sum;
				if ( (dum=vv[i]*fabs(sum)) >= big) {
					big=dum;
					imax=i;
				}
			}
			if (j != imax) { 
				for (k=1;k<=n;k++) { 
					dum=a[imax][k];
					a[imax][k]=a[j][k];
					a[j][k]=dum;
				}
				*d = -(*d); 
				vv[imax]=vv[j]; 
			}
			indx[j]=imax;
			if (a[j][j] == 0.0) a[j][j]=TINY;

			if (j != n) { 
				dum=1.0/(a[j][j]);
				for (i=j+1;i<=n;i++) a[i][j] *= dum;
			}
		} 
	}
	free_dvector(vv,1,n);
}

//Determinant of a Square Matrix: using LU decomposition "ludcmp2"
double Determinant(double **a,int n)
{
   double d;
   int j, *index;
   index = ivector(1,n);
   ludcmp2(a,n,index,&d);
   for(j=1;j<=n;j++) d *= a[j][j];
   free_ivector(index,1,n);
   return(d);

}
// END: DETERMINANT
//===================================
//	  OBJECT MANIPULATION: END 
//===================================




//===================================
//	  RANDOM GENERATOR: START 
//===================================
double runifC3(){
	//simulate uniform distribution on (0,1)
      double r;
	  extern long gix, giy, giz;
	 
      gix = 171 * (gix % 177) - 2 * (gix / 177);
      giy = 172 * (giy % 176) - 35 * (giy / 176);
      giz = 170 * (giz % 178) - 63 * (giz / 178);
	
      if (gix < 0) gix = gix + 30269;
      if (giy < 0) giy = giy + 30307;
      if (giz < 0) giz = giz + 30323;
	 
      r = fmod((double)(gix) / 30269. + (double)(giy) / 30307. +  (double)(giz) / 30323., 1.0);
	 
      return r;
}

//diff set of seed
double runifC3P(){
	//simulate uniform distribution on (0,1)
      double r;

	  extern long bix, biy, biz;
 
      bix = 171 * (bix % 177) - 2 * (bix / 177);
      biy = 172 * (biy % 176) - 35 * (biy / 176);
      biz = 170 * (biz % 178) - 63 * (biz / 178);

      if (bix < 0) bix = bix + 30269;
      if (biy < 0) biy = biy + 30307;
      if (biz < 0) biz = biz + 30323;

      r = fmod((double)(bix) / 30269. + (double)(biy) / 30307. +  (double)(biz) / 30323., 1.0);

      return r;
}

double rbinomC(double pp, int n)
//Returns as a floating-point number an integer value that is a random deviate drawn from
//a binomial distribution of n trials each of probability pp, using runifC3() as a source of
//uniform random deviates.
{
	double gammln(double xx);
	double runifC3();
	int j;
	static int nold=(-1);
	double am,em,g,angle,p,bnl,sq,t,y;
	static double pold=(-1.0),pc,plog,pclog,en,oldg;
	p=(pp <= 0.5 ? pp : 1.0-pp);
	//The binomial distribution is invariant under changing pp to 1-pp, if we also change the
	//answer to n minus itself; we'll remember to do this below.
	am=n*p; //This is the mean of the deviate to be produced.
	if (n < 25) { //Use the direct method while n is not too large.
		bnl=0.0;    //This can  require up to 25 calls to runifC3.
		for (j=1;j<=n;j++)
			if (runifC3() < p) ++bnl;
	} else if (am < 1.0) { //If fewer than one event is expected out of 25
		g=exp(-am);				//or more trials, then the distribution is quite
		t=1.0;					//accurately Poisson. Use direct Poissonmethod.
		for (j=0;j<=n;j++) {
			t *= runifC3();
			if (t < g) break;
		}
		bnl=(j <= n ? j : n);
	} else { //Use the rejection method.
		if (n != nold) { //If n has changed, then compute useful quantities.
			en=n;
			oldg=gammln(en+1.0);
			nold=n;
		} if (p != pold) { //If p has changed, then compute useful quantities.
			pc=1.0-p;
			plog=log(p);
			pclog=log(pc);
			pold=p;
		}
		sq=sqrt(2.0*am*pc); //The following code should by now seem familiar:
		do {					//rejection method with a Lorentzian comparison function.
			do {
				angle=PI*runifC3();
				y=tan(angle);
				em=sq*y+am;
			} while (em < 0.0 || em >= (en+1.0)); //Reject.
			em=floor(em); //Trick for integer-valued distribution.
			t=1.2*sq*(1.0+y*y)*exp(oldg-gammln(em+1.0)-gammln(en-em+1.0)+em*plog+(en-em)*pclog);
		} while (runifC3() > t); //Reject. This happens about 1.5 times per deviate, on average.
			bnl=em;
	}
	if (p != pp) bnl=n-bnl; //Remember to undo the symmetry transformation.
	return bnl;
}

//generate random N(0,1) using random uniform(0,1) generator runifC3()
double rnormC()
{
	double runifC3();
	static int iset=0;
	static double gset;
	double fac,rsq,v1,v2;
	if (iset == 0) {
		do {
			v1=2.0*runifC3()-1.0;
			v2=2.0*runifC3()-1.0;
			rsq=v1*v1+v2*v2;
		} while (rsq >= 1.0 || rsq == 0.0);
		fac=sqrt(-2.0*log(rsq)/rsq);
		gset=v1*fac;
		iset=1;
		return v2*fac;
	} else {
		iset=0;
		return gset;
	}
}



//generate random N(0,1) using random uniform(0,1) generator runifC3P()
double rnormCP()
{
	double runifC3P();
	static int iset=0;
	static double gset;
	double fac,rsq,v1,v2;
	if (iset == 0) {
		do {
			v1=2.0*runifC3P()-1.0;
			v2=2.0*runifC3P()-1.0;
			rsq=v1*v1+v2*v2;
		} while (rsq >= 1.0 || rsq == 0.0);
		fac=sqrt(-2.0*log(rsq)/rsq);
		gset=v1*fac;
		iset=1;
		return v2*fac;
	} else {
		iset=0;
		return gset;
	}
}


/**********************************************************************
*
* getPermute
*
* generate a permutaion from 0 to n-1 using Knuth shuffle
* http://en.wikipedia.org/wiki/Knuth_shuffle
*
**********************************************************************/
void getPermute_data(int* per, int n) {

	double runifC3();
	double ran;
	int i, j, v, k;

	for (i=0; i<n; i++) {
		per[i] = i;
	}

	for (i=n-1; i>0; i--) {

		ran=(i+1)*runifC3();
		/* a integer from 0 to i */
		for(k=0;k<(i+1);k++){
			if( (k<=ran) && (ran<=(k+1)) ){
				j=k;
				break;
			}
		}

		v = per[i];
		per[i] = per[j];
		per[j] = v;
	}

}

void getPermute(int* per, int n) {

	double runifC3P();
	double ran;
	int i, j, v, k;

	for (i=0; i<n; i++) {
		per[i] = i;
	}

	for (i=n-1; i>0; i--) {

		ran=(i+1)*runifC3P();
		/* a integer from 0 to i */
		for(k=0;k<(i+1);k++){
			if( (k<=ran) && (ran<=(k+1)) ){
				j=k;
				break;
			}
		}

		v = per[i];
		per[i] = per[j];
		per[j] = v;
	}

}


//===================================
//	  RANDOM GENERATOR: END 
//===================================

//===================================
//	  STATISTICAL DISTRIBUTION: START 
//===================================
// START: CHI-SQUARE CDF
double gammq(double a, double x)
{
    double gammcf, gamser, gln;

    if (x < 0.0 || a <= 0.0) {
        printf("Invalid arguments in routine gammp\n");
        exit(1);
    }

    if (x < (a + 1.0)) {
        gser(&gamser, a, x, &gln);
        return 1.0-gamser;
    } else {
        gcf(&gammcf, a, x, &gln);
        return gammcf;
    }
} /* gammq_ */


void gser(double *gamser, double a, double x, double *gln)
{
    int n;
    double ap, del, sum;

    *gln = gammln(a);
    if (x <= 0.0) {
        if (x < 0.0) {
            printf("x less than 0 in routine gser\n");
            exit(1);
        }
        *gamser = 0.0;
        return;
    } else {
        ap = a;
        del = sum = 1.0/a;
        for (n = 1; n <= ITMAX; n++) {
            ap = ap+1.0;
            del *= x/ap;
            sum += del;
            if (fabs(del) < fabs(sum)*EPS) {
                *gamser = sum*exp(-x + a*log(x)-(*gln));
                return;
            }
        }
        printf("a too large, ITMAX too small in routine gser\n");
        exit(1);
    }
}

void gcf(double *gammcf, double a, double x, double *gln)
{
    /* Local variables */
    int i;
    double an, b, c, d, del, h;

    *gln = gammln(a);
    b = x + 1.0 - a;
    c = 1.0/FPMIN;
    d = 1.0/b;
    h = d;

    for (i = 1; i <= ITMAX; i++) {
        an = -i*(i-a);
        b += 2.0;
        d = an*d+b;
        if (fabs(d) < FPMIN) d = FPMIN;
        c = b+an/c;
        if (fabs(c) < FPMIN) c = FPMIN;
        d = 1.0/d;
        del = d*c;
        h *= del;
        if (fabs(del-1.0) < EPS) break;
    }
    if (i > ITMAX) {
        printf("A too large, ITMAX too small\n");
        exit(1);
    }

    *gammcf = exp(-x+a*log(x)-(*gln))*h;
}
// END: CHI-SQUARE CDF
//===================================
//	  STATISTICAL DISTRIBUTION: END
//===================================


//===================================
//	  MODEL: START 
//===================================
//LINEAR REGRESSION
void linearMLE(int N, int P, double *y, double **x, double *vbeta){

	void invv(double **fma, int nn);
	double **dmatrix(long nrl, long nrh, long ncl, long nch);
	void free_dmatrix(double **m, long nrl, long nrh, long ncl, long nch);

	int i,j,jj;
	double **xx, *xy, **inv_xx;
	xx = dmatrix(0,P-1,0,P-1);
	xy = dvector(0,P-1);
	inv_xx = dmatrix(1,P,1,P);

	//--- calculate xx and xy
	for(j=0;j<P;j++){
		for(jj=0;jj<P;jj++){

			xx[j][jj] = 0.;
			for(i=0;i<N;i++)
				xx[j][jj] += x[i][j]*x[i][jj];

		}

		xy[j] = 0.;
		for(i=0;i<N;i++)
			xy[j] += x[i][j]*y[i];

	}

	//--- calculate inverse(xx)
	for(j=0;j<P;j++){
		for(jj=0;jj<P;jj++){
			inv_xx[j+1][jj+1]=xx[j][jj];
		}
	}
	invv(inv_xx, P);

	//--- beta
	for(j=0;j<P;j++){
		vbeta[j] = 0.;
		for(jj=0;jj<P;jj++){
			vbeta[j] += inv_xx[j+1][jj+1]*xy[jj];
		}
	}

	free_dmatrix(xx,0,P-1,0,P-1);
	free_dvector(xy,0,P-1);
	free_dmatrix(inv_xx,1,P,1,P);
}

// LOGISTIC REGRSSION
void logisticReg_v0(int N, int D, double *y, double **x, double *vbeta1){

	int i, j, d, k, h, convergeFlag=0;
	double *vbeta2, yfreq, *vstep, **I, **inv_I, *U;
	double loglik_vbeta1, loglik_vbeta2, xbeta1, xbeta2, exp_xbeta1, centerY, v;

	vbeta2 = dvector(0,D-1);
	vstep = dvector(0,D-1);
	U = dvector(0,D-1);
	I = dmatrix(0,D-1,0,D-1);
	inv_I = dmatrix(1,D,1,D);

	//=============================================== MLE
    // get inital value for beta
	for(j=0;j<D;j++){
		vbeta1[j]=0.;
	}

	yfreq = 0.;
	for(i=0; i<N; i++){
	    yfreq += y[i];
	}

	yfreq /= N;

	vbeta1[0] = log(yfreq/(1-yfreq));

	// loglikelihood for initial beta
	loglik_vbeta1 = 0.;
	for(i=0;i<N;i++){
		xbeta1=0.;
		for(j=0;j<D;j++){
			xbeta1 += x[i][j] * vbeta1[j];
		}

		loglik_vbeta1 += (y[i]*xbeta1 - log(1+exp(xbeta1)));

	}

	// iteration begin
	for(k=0; k<ITER_MAX; k++){


		for(j=0; j<D; j++){
			U[j]=0.;
			for(d=0; d<D; d++){
				I[j][d]=0.;
			}
		}

		// calculate score vector and information matrix
		for(i=0; i<N; i++){
			xbeta1 = 0.;
			for(j=0;j<D;j++)	xbeta1 += vbeta1[j]*x[i][j];
			exp_xbeta1 = exp(xbeta1);
			centerY = y[i] - exp_xbeta1/(1.+exp_xbeta1);
			v = exp_xbeta1 /pow((1.+exp_xbeta1),2);

			for(j=0;j<D;j++){
				U[j] += centerY * x[i][j];
				for(d=0;d<D;d++){
					I[j][d] += v * x[i][j] * x[i][d];
				}
			}

		}

		// inverse information matrix
		for(j=0;j<D;j++){
			for(d=0;d<D;d++){
				inv_I[j+1][d+1]=I[j][d];
			}
		}
		invv(inv_I, D);

		for(j=0;j<D;j++){
			vstep[j] = 0.;
			for(d=0;d<D;d++){
				vstep[j] += inv_I[j+1][d+1] * U[d];
			}
			vbeta2[j] = vbeta1[j] + vstep[j];
		}

		// step-halving step
		loglik_vbeta2 = 0.;

		for(i=0;i<N;i++){

			xbeta2=0.;
			for(j=0;j<D;j++){
				xbeta2 += x[i][j] * vbeta2[j];
			}
			loglik_vbeta2 += (y[i]*xbeta2 - log(1+exp(xbeta2)));
		}

		if(loglik_vbeta2 < loglik_vbeta1){
			for(h=0;h<HALF_MAX;h++){

				for(j=0; j<D; j++){
					vstep[j] *= 0.5;
					vbeta2[j] = vbeta1[j] + vstep[j];
				}

				loglik_vbeta2 = 0.;
				for(i=0;i<N;i++){

					xbeta2=0.;
					for(j=0;j<D;j++){
						xbeta2 += x[i][j] * vbeta2[j];
					}

					loglik_vbeta2 += (y[i]*xbeta2 - log(1+exp(xbeta2)));
				}

				if(loglik_vbeta2 >= loglik_vbeta1)	break;
				//else if(h==(HALF_MAX-1)) printf("\nLogisticReg Warining: Step_Halfing Fail with HALF_MAX steps!\n");
			}
		}


		// hit stop condition
		for(j=0; j<D; j++){
			vbeta1[j] = vbeta2[j];
		}

		if(fabs((loglik_vbeta2-loglik_vbeta1)/loglik_vbeta2)<STOP_EPSILON){
			loglik_vbeta1 = loglik_vbeta2;
			convergeFlag = 1;
			break;
		}else{
			loglik_vbeta1 = loglik_vbeta2;
			if(k==(ITER_MAX-1))	printf("\nLogisticReg Warning:MLE iteration NOT converge!\n");
		}

	}// iteration end

	free_dvector(vbeta2,0,D-1);
	free_dvector(vstep,0,D-1);
	free_dvector(U,0,D-1);
	free_dmatrix(I,0,D-1,0,D-1);
	free_dmatrix(inv_I,1,D,1,D);
}

//===================================
//	  MODEL: END
//===================================



