
//===================================
//	  BASIC
//===================================
double gammln(double xx);

//===================================
//	  SPACE ALLOCATION
//===================================
void nrerror(const char* error_text);
int *ivector(int nl, int nh);
void free_ivector(int *v, int nl, int nh);
double *dvector(long nl, long nh);
void free_dvector(double *v, long nl, long nh);
double **dmatrix(long nrl, long nrh, long ncl, long nch);
void free_dmatrix(double **m, long nrl, long nrh, long ncl, long nch);
int **imatrix(long nrl, long nrh, long ncl, long nch);
void free_imatrix(int **m, long nrl, long nrh, long ncl, long nch);

//===================================
//	  O/I
//===================================
//PRINT
void print_dv(double *vector, int starti, int endi, const char *pstring);
void print_iv(int *vector, int starti, int endi, const char *pstring);
void print_dm(double **matrix, int starti, int endi, int startj, int endj, const char *pstring);
void print_im(int **matrix, int starti, int endi, int startj, int endj, const char *pstring);
void print_sv(char **array, int len, const char *pstring);

//===================================
//	  OBJECT MANIPULATION
//===================================
double mean(double* x, long nl, long nh);
double sd(double* x, long nl, long nh, double mean_x);
double median(double *x, long nl, long nh);
double sd_MAD(double *x, long nl, long nh);

//INVERSE
void ludcmp(double **a,int n,int *indx);
void lubksb(double **a, int n, int *indx, double *b);
void invv(double **fma, int nn);

//DETERMINANT
double Determinant(double **a,int n);
void ludcmp2(double **a, int n, int *indx, double *d);

//SORTING, INDEXING
int cmp(const void *a, const void *b);
void qRank_noTie(long arrayLen, double *Array);
int cmp_int(const void *a, const void *b);
void qRank_noTie_int(int arrayLen, int *Array);
char** stringSort(char** s, int *order_s, int *rank_s, int n, int order);

//===================================
//	  RANDOM GENERATOR
//===================================
//UNIFORM
double runifC3();
double runifC3P();

//BINOMIAL
#define PI 3.141592654
double rbinomC(double pp, int n);
double rnormC();
double rnormCP();

void getPermute(int* per, int n);
void getPermute_data(int* per, int n);
//===================================
//	  STATISTICAL DISTRIBUTION
//===================================
//CHI-SQ
#define ITMAX 100
#define EPS 0.00000000000000022204460492503
double gammq(double a, double x);
void gser(double *gamser, double a, double x, double *gln);
#define FPMIN 1.00208e-292
void gcf(double *gammcf, double a, double x, double *gln);

//===================================
//	  MODEL
//===================================
#define ITER_MAX 5000
#define HALF_MAX 15
#define STOP_EPSILON 1E-8

//LINEAR REGRESSION
void logisticReg_v0(int N, int D, double *y, double **x, double *vbeta1);

//LOGISTIC REGRESSION
void linearMLE(int N, int P, double *y, double **x, double *vbeta);















