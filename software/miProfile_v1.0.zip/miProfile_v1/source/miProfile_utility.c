#include "utility.h"
#include "miProfile_utility.h"
#include <stdio.h>
#include <math.h>
#include <float.h>
#include <string.h>
#include <stdlib.h>
//#include <gsl/gsl_randist.h>
//#include <gsl/gsl_math.h>
//#include <gsl/gsl_eigen.h>
//#include <gsl/gsl_cdf.h>
//#include <gsl/gsl_linalg.h>
//#include <gsl/gsl_matrix.h>
//#include <gsl/gsl_matrix_double.h>
//#include <gsl/gsl_rng.h>


void kill_miProfile(){
	printf("\nmiProfile was stopped due to error(s) listed above.\n\n");
	exit(1);
}

// x: input: otu count vector; output: rarefied otu count vector
// depth should be smaller than the total count in x
void rarefy(int m, double *x, int depth) {

	int i, j, depth_x = 0, index, *x_index, *perm_index;
	double *x_rare;
	for(j=0; j<m; j++){
		depth_x += (int)(x[j]);
	}
	x_index = ivector(0, depth_x -1);
	perm_index = ivector(0, depth_x -1);

	index =0;
	for(j=0; j<m; j++){
		if(x[j]>0){
			for(i=0; i<((int)(x[j])); i++){
				x_index[index + i] = j;
			}
			index += (int)(x[j]);
		}
	}
	//print_iv(x_index, 0, depth_x-1, "x_index");


	getPermute(perm_index, depth_x);
	//print_iv(perm_index, 0, depth_x-1, "perm_index");

	for(j=0; j<m; j++){
		x[j] = 0;
	}

	for(i=0; i<depth; i++){
		x[x_index[perm_index[i]]] += 1;
	}


	free_ivector(x_index, 0, depth_x -1);
	free_ivector(perm_index, 0, depth_x -1);
}



// Distance v3: (only include UniFrac distance) unweighted (Duw), generalized weighted (Dg),  generalized presence-absence (Dpg)
// provide two version of OTU: percentages from counts with and without rarefaction. 
// provide normalization method for each distance
void treeDist_v3(int n, int m, int nbr, int Dg, double *Dg_type, int *Dg_norm_type, int Dpg, double *Dpg_type, int *Dpg_norm_type, int Duw, int Duw_norm, double *tree_brLen, int *tree_upNode, int *tree_downNode, double **otu, double **otu_r, double **dist){

	int ndist = Duw+Dg+Dpg, *indexD, flag=0, d, k, i, j, nbr2, nbr2_r, *tree_upNode_rank, *tree_upNode_index, *tree_upNode_sort, *tree_downNode_rank, *tree_downNode_index, *tree_downNode_sort, tip_loc, node, node_loc;
	double **cum, **cum_b, **cum_r, **cum_rb,  *cum1, *cum1_r, *cum2, *cum2_r, *tree_brLen2, *tree_brLen2_r, *diff, *diff_r, w, tmp, tmp1, tmp2;
	//double **otu_perc;

	
	//otu_perc = dmatrix(0, n-1, 0, m-1);
	indexD = ivector(0, ndist-1);
	cum = dmatrix(0, nbr-1, 0, n-1);
	cum_b = dmatrix(0, nbr-1, 0, n-1);
	cum_r = dmatrix(0, nbr-1, 0, n-1);
	cum_rb = dmatrix(0, nbr-1, 0, n-1);
	cum1 = dvector(0, nbr-1);
	cum1_r = dvector(0, nbr-1);
	cum2 = dvector(0, nbr-1);
	cum2_r = dvector(0, nbr-1);
	diff = dvector(0, nbr-1);
	diff_r = dvector(0, nbr-1);
	tree_brLen2 = dvector(0, nbr-1);
	tree_brLen2_r = dvector(0, nbr-1);

	
	tree_upNode_rank = ivector(0, nbr-1); tree_upNode_index = ivector(0, nbr-1); tree_upNode_sort = ivector(0, nbr-1);
	tree_downNode_rank = ivector(0, nbr-1); tree_downNode_index = ivector(0, nbr-1); tree_downNode_sort = ivector(0, nbr-1);
	//node = ivector(0, nbr-1);
	//node_loc = ivector(0, nbr-1);

	//for(i=0; i<n; i++){
	//	tmp1 = 0;
	//	for(j=0; j<m; j++){
	//		tmp1 += otu[i][j];
	//	}
	//	for(j=0; j<m; j++){
	//		otu_perc[i][j] = otu[i][j]/tmp1;
	//	}
	//}

	for(j=0; j<nbr; j++){
		for(i=0; i<n; i++){
			cum[j][i] = 0.;
			cum_b[j][i] = 0.;
			cum_r[j][i] = 0.;
			cum_rb[j][i] = 0.;
		}
		tree_upNode_rank[j] = tree_upNode[j];
		tree_downNode_rank[j] = tree_downNode[j];
	}

	//print_iv(tree_upNode_rank, 0, 9, "first 10 upNode");
	//print_iv(tree_downNode_rank, 0, 9, "first 10 downNode");

	qRank_noTie_int(nbr, tree_upNode_rank);
	qRank_noTie_int(nbr, tree_downNode_rank);

	//print_iv(tree_upNode_rank, 0, 9, "rank of the first 10 upNode");
	//print_iv(tree_downNode_rank, 0, 9, "rank of the first 10 downNode");

	for(j=0; j<nbr; j++){
		tree_upNode_index[tree_upNode_rank[j]] = j;
		tree_upNode_sort[tree_upNode_rank[j]] = tree_upNode[j];
		tree_downNode_index[tree_downNode_rank[j]] = j;
		tree_downNode_sort[tree_downNode_rank[j]] = tree_downNode[j];
	}

	//print_iv(tree_upNode_index, 0, 9, "index of the first 10 upNode");
	//print_iv(tree_downNode_index, 0, 9, "index of the first 10 downNode");

	//print_iv(tree_upNode_sort, 0, 9, "sorted first 10 upNode");
	//print_iv(tree_downNode_sort, 0, 9, "sorted first 10 downNode");

	//print_dv(tree_tipLabel, 0, 9, "rank of firest 10 tip labels in tree");

	for(k=0; k<m; k++){

		//printf("==== k=%d ====\n", k);
		tip_loc = tree_downNode_index[k];
		//printf("tip_loc=%d\n", tip_loc);
		for(i=0; i<n; i++){
			cum[tip_loc][i] += otu[i][k];
			if(otu[i][k]>0){
				cum_b[tip_loc][i] += 1;
			}
			cum_r[tip_loc][i] += otu_r[i][k];
			if(otu_r[i][k]>0){
				cum_rb[tip_loc][i] += 1;
			}
		}


		node = tree_upNode[tip_loc];
		//printf("node=%d\n", node);

		flag = 0;
		for(j=0; j<nbr; j++){
			if(tree_downNode_sort[j] == node){
				node_loc = tree_downNode_index[j];
				flag = 1;
				break;
			}
		}

		//printf("node_loc=%d, flag=%d\n", node_loc, flag);

		while(flag){

			for(i=0; i<n; i++){
				cum[node_loc][i] += otu[i][k];
				if(otu[i][k]>0){
					cum_b[node_loc][i] += 1;
				}
				cum_r[node_loc][i] += otu_r[i][k];
				if(otu_r[i][k]>0){
					cum_rb[node_loc][i] += 1;
				}
			}
			node = tree_upNode[node_loc];

			flag = 0;
			for(j=0; j<nbr; j++){
				if(tree_downNode_sort[j] == node){
					node_loc = tree_downNode_index[j];
					flag = 1;
					break;
				}
			}

		}


	}
	//print_dm(cum, 0, 9, 0, 9, "cum for the first 10 branch and first 10 subjects");
	//print_dm(cum_b, 0, 9, 0, 9, "cum_b for the first 10 branch and first 10 subjects");
	//print_dm(cum_r, 0, 9, 0, 9, "cum_r for the first 10 branch and first 10 subjects");
	//print_dm(cum_rb, 0, 9, 0, 9, "cum_rb for the first 10 branch and first 10 subjects");

	for(d=0; d<ndist; d++){
		indexD[d] = d*n;
		for(i=0; i<n; i++){
			dist[indexD[d]+i][i] = 0.;
		}

	}

	for(i=1; i<n; i++){
		for(j=0; j<i; j++){


			// abundance distance 
			if(Dg>0){

	
				nbr2 = 0;
				nbr2_r = 0;

				for(k=0; k<nbr; k++){

					if((cum[k][i] + cum[k][j])!=0){
						cum1[nbr2] = cum[k][i];
						cum2[nbr2] = cum[k][j];
						tree_brLen2[nbr2] = tree_brLen[k];
						nbr2++;
					}

					if((cum_r[k][i] + cum_r[k][j])!=0){
						cum1_r[nbr2_r] = cum_r[k][i];
						cum2_r[nbr2_r] = cum_r[k][j];
						tree_brLen2_r[nbr2_r] = tree_brLen[k];
						nbr2_r++;
					}
				}

				for(k=0; k<nbr2; k++){
					diff[k] = fabs(cum1[k]-cum2[k])/(cum1[k]+cum2[k]);
				}	

				for(k=0; k<nbr2_r; k++){
					diff_r[k] = fabs(cum1_r[k]-cum2_r[k])/(cum1_r[k]+cum2_r[k]);
				}


				for(d=0; d<Dg; d++){

					if(Dg_norm_type[d]==0){  //unrarefied
						tmp1 = 0.;
						tmp2 = 0.;
						for(k=0; k<nbr2; k++){
							w = tree_brLen2[k] * pow((cum1[k]+cum2[k]), Dg_type[d]);
							tmp1 += w;
							tmp2 += diff[k]*w;
						}							
	

					}else{  //rarefied
						tmp1 = 0.;
						tmp2 = 0.;
						for(k=0; k<nbr2_r; k++){
							w = tree_brLen2_r[k] * pow((cum1_r[k]+cum2_r[k]), Dg_type[d]);
							tmp1 += w;
							tmp2 += diff_r[k]*w;
						}							

					}

					dist[indexD[d]+i][j] = tmp2/tmp1;	
					dist[indexD[d]+j][i] = dist[indexD[d]+i][j];	

				}


			}

			//presence-absence distance
			if(Dpg>0 || Duw>0){

				nbr2 = 0;
				nbr2_r = 0;

				for(k=0; k<nbr; k++){
					if((cum_b[k][i] + cum_b[k][j])!=0){
						cum1[nbr2] = cum_b[k][i];
						cum2[nbr2] = cum_b[k][j];
						tree_brLen2[nbr2] = tree_brLen[k];
						nbr2++;
					}

					if((cum_rb[k][i] + cum_rb[k][j])!=0){
						cum1_r[nbr2_r] = cum_rb[k][i];
						cum2_r[nbr2_r] = cum_rb[k][j];
						tree_brLen2_r[nbr2_r] = tree_brLen[k];
						nbr2_r++;
					}
				}


				if(Dpg>0){

					for(k=0; k<nbr2; k++){
						diff[k] = fabs(cum1[k]-cum2[k])/(cum1[k]+cum2[k]);
					}	

					for(k=0; k<nbr2_r; k++){
						diff_r[k] = fabs(cum1_r[k]-cum2_r[k])/(cum1_r[k]+cum2_r[k]);
					}

					for(d=0; d<Dpg; d++){

						if(Dpg_norm_type[d]==0){ //unrarefied

							tmp1 = 0.;
							tmp2 = 0.;
							for(k=0; k<nbr2; k++){
								w = tree_brLen2[k] * pow((cum1[k]+cum2[k]), Dpg_type[d]);
								tmp1 += w;
								tmp2 += diff[k]*w;
							}								

						}else{  //rarefied

							tmp1 = 0.;
							tmp2 = 0.;
							for(k=0; k<nbr2_r; k++){
								w = tree_brLen2_r[k] * pow((cum1_r[k]+cum2_r[k]), Dpg_type[d]);
								tmp1 += w;
								tmp2 += diff[k]*w;
							}							
	
						}

						dist[indexD[Dg+d]+i][j] = tmp2/tmp1;	
						dist[indexD[Dg+d]+j][i] = dist[indexD[Dg+d]+i][j];	

					}


				}

				if(Duw>0){

					if(Duw_norm==0){ //unrarefied

						tmp1 = 0.;
						tmp2 = 0.;
						for(k=0; k<nbr2; k++){

							tmp1 += tree_brLen2[k];
							if(cum1[k]>0) cum1[k] = 1;
							if(cum2[k]>0) cum2[k] = 1;
							tmp2 += ( fabs(cum1[k]-cum2[k])/(cum1[k]+cum2[k]) ) * tree_brLen2[k];

						}		

					}else{  //rarefied
						
						tmp1 = 0.;
						tmp2 = 0.;
						for(k=0; k<nbr2_r; k++){

							tmp1 += tree_brLen2_r[k];
							if(cum1_r[k]>0) cum1_r[k] = 1;
							if(cum2_r[k]>0) cum2_r[k] = 1;
							tmp2 += ( fabs(cum1_r[k]-cum2_r[k])/(cum1_r[k]+cum2_r[k]) ) * tree_brLen2_r[k];

						}

					}


					dist[indexD[Dg+Dpg]+i][j] = tmp2/tmp1;	
					dist[indexD[Dg+Dpg]+j][i] = dist[indexD[Dg+Dpg]+i][j];


				}

			}






		}
	}



	//free_ivector(node, 0, nbr-1);
	//free_ivector(node_loc, 0, nbr-1);
	//free_dmatrix(otu_perc, 0, n-1, 0, m-1);

	free_ivector(indexD, 0, ndist-1);
	free_dvector(cum1, 0, nbr-1);
	free_dvector(cum1_r, 0, nbr-1);
	free_dvector(cum2, 0, nbr-1);
	free_dvector(cum2_r, 0, nbr-1);
	free_dvector(diff, 0, nbr-1);
	free_dvector(diff_r, 0, nbr-1);
	free_dvector(tree_brLen2, 0, nbr-1);
	free_dvector(tree_brLen2_r, 0, nbr-1);
	free_ivector(tree_upNode_rank, 0, nbr-1); free_ivector(tree_upNode_index, 0, nbr-1); free_ivector(tree_upNode_sort, 0, nbr-1);
	free_ivector(tree_downNode_rank, 0, nbr-1); free_ivector(tree_downNode_index, 0, nbr-1); free_ivector(tree_downNode_sort, 0, nbr-1);
} 

// Tree Distance v4: input internal ID corresponding to tipLabel and simplify the code a little when searching for node location
void treeDist_v4(int n, int m, int nbr, int Dg, double *Dg_type, int *Dg_norm_type, int Dpg, double *Dpg_type, int *Dpg_norm_type, int Duw, int Duw_norm, int *tree_tipLabel_ID, double *tree_brLen, int *tree_upNode, int *tree_downNode, double **otu, double **otu_r, double **dist){

	//int *tree_upNode_sort, *tree_downNode_sort, flag=0;
	int ndist = Duw+Dg+Dpg, *indexD, d, k, i, j, nbr2, nbr2_r, *tree_upNode_rank, *tree_upNode_index, *tree_downNode_rank, *tree_downNode_index, tip_loc, node, node_loc;
	double **cum, **cum_b, **cum_r, **cum_rb,  *cum1, *cum1_r, *cum2, *cum2_r, *tree_brLen2, *tree_brLen2_r, *diff, *diff_r, w, tmp, tmp1, tmp2;
	//double **otu_perc;

	
	//otu_perc = dmatrix(0, n-1, 0, m-1);
	indexD = ivector(0, ndist-1);
	cum = dmatrix(0, nbr-1, 0, n-1);
	cum_b = dmatrix(0, nbr-1, 0, n-1);
	cum_r = dmatrix(0, nbr-1, 0, n-1);
	cum_rb = dmatrix(0, nbr-1, 0, n-1);
	cum1 = dvector(0, nbr-1);
	cum1_r = dvector(0, nbr-1);
	cum2 = dvector(0, nbr-1);
	cum2_r = dvector(0, nbr-1);
	diff = dvector(0, nbr-1);
	diff_r = dvector(0, nbr-1);
	tree_brLen2 = dvector(0, nbr-1);
	tree_brLen2_r = dvector(0, nbr-1);

	
	tree_upNode_rank = ivector(0, nbr-1); tree_upNode_index = ivector(0, nbr-1); //tree_upNode_sort = ivector(0, nbr-1);
	tree_downNode_rank = ivector(0, nbr-1); tree_downNode_index = ivector(0, nbr-1); //tree_downNode_sort = ivector(0, nbr-1);
	//node = ivector(0, nbr-1);
	//node_loc = ivector(0, nbr-1);

	//for(i=0; i<n; i++){
	//	tmp1 = 0;
	//	for(j=0; j<m; j++){
	//		tmp1 += otu[i][j];
	//	}
	//	for(j=0; j<m; j++){
	//		otu_perc[i][j] = otu[i][j]/tmp1;
	//	}
	//}

	for(j=0; j<nbr; j++){
		for(i=0; i<n; i++){
			cum[j][i] = 0.;
			cum_b[j][i] = 0.;
			cum_r[j][i] = 0.;
			cum_rb[j][i] = 0.;
		}
		tree_upNode_rank[j] = tree_upNode[j];
		tree_downNode_rank[j] = tree_downNode[j];
	}

	//print_iv(tree_upNode_rank, 0, 9, "first 10 upNode");
	//print_iv(tree_downNode_rank, 0, 9, "first 10 downNode");

	qRank_noTie_int(nbr, tree_upNode_rank);
	qRank_noTie_int(nbr, tree_downNode_rank);

	//print_iv(tree_upNode_rank, 0, 9, "rank of the first 10 upNode");
	//print_iv(tree_downNode_rank, 0, 9, "rank of the first 10 downNode");

	for(j=0; j<nbr; j++){
		tree_upNode_index[tree_upNode_rank[j]] = j;
		//tree_upNode_sort[tree_upNode_rank[j]] = tree_upNode[j];
		tree_downNode_index[tree_downNode_rank[j]] = j;
		//tree_downNode_sort[tree_downNode_rank[j]] = tree_downNode[j];
	}

	//print_iv(tree_upNode_index, 0, 9, "index of the first 10 upNode");
	//print_iv(tree_downNode_index, 0, 9, "index of the first 10 downNode");

	//print_iv(tree_upNode_sort, 0, 9, "sorted first 10 upNode");
	//print_iv(tree_downNode_sort, 0, 9, "sorted first 10 downNode");

	//print_dv(tree_tipLabel, 0, 9, "rank of firest 10 tip labels in tree");

	for(k=0; k<m; k++){

		//printf("==== k=%d ====\n", k);
		//tip_loc = tree_downNode_index[k];
		tip_loc = tree_downNode_index[tree_tipLabel_ID[k]-1];
		//printf("tip_loc=%d\n", tip_loc);
		for(i=0; i<n; i++){
			cum[tip_loc][i] += otu[i][k];
			if(otu[i][k]>0){
				cum_b[tip_loc][i] += 1;
			}
			cum_r[tip_loc][i] += otu_r[i][k];
			if(otu_r[i][k]>0){
				cum_rb[tip_loc][i] += 1;
			}
		}


		node = tree_upNode[tip_loc];
		//printf("node=%d\n", node);

		// this section can be simplied because the root has internal ID = 0 in Zhouwen's rule
		//flag = 0;
		//for(j=0; j<nbr; j++){
		//	if(tree_downNode_sort[j] == node){
		//		node_loc = tree_downNode_index[j];
		//		flag = 1;
		//		break;
		//	}
		//}

		

		//printf("node_loc=%d, flag=%d\n", node_loc, flag);

		while(node){ // not root

			node_loc = tree_downNode_index[node-1];

			for(i=0; i<n; i++){
				cum[node_loc][i] += otu[i][k];
				if(otu[i][k]>0){
					cum_b[node_loc][i] += 1;
				}
				cum_r[node_loc][i] += otu_r[i][k];
				if(otu_r[i][k]>0){
					cum_rb[node_loc][i] += 1;
				}
			}
			node = tree_upNode[node_loc];

			//flag = 0;
			//for(j=0; j<nbr; j++){
			//	if(tree_downNode_sort[j] == node){
			//		node_loc = tree_downNode_index[j];
			//		flag = 1;
			//		break;
			//	}
			//}


		}


	}
	//print_dm(cum, 0, 9, 0, 9, "cum for the first 10 branch and first 10 subjects");
	//print_dm(cum_b, 0, 9, 0, 9, "cum_b for the first 10 branch and first 10 subjects");
	//print_dm(cum_r, 0, 9, 0, 9, "cum_r for the first 10 branch and first 10 subjects");
	//print_dm(cum_rb, 0, 9, 0, 9, "cum_rb for the first 10 branch and first 10 subjects");

	for(d=0; d<ndist; d++){
		indexD[d] = d*n;
		for(i=0; i<n; i++){
			dist[indexD[d]+i][i] = 0.;
		}

	}

	for(i=1; i<n; i++){
		for(j=0; j<i; j++){


			// abundance distance 
			if(Dg>0){

	
				nbr2 = 0;
				nbr2_r = 0;

				for(k=0; k<nbr; k++){

					if((cum[k][i] + cum[k][j])!=0){
						cum1[nbr2] = cum[k][i];
						cum2[nbr2] = cum[k][j];
						tree_brLen2[nbr2] = tree_brLen[k];
						nbr2++;
					}

					if((cum_r[k][i] + cum_r[k][j])!=0){
						cum1_r[nbr2_r] = cum_r[k][i];
						cum2_r[nbr2_r] = cum_r[k][j];
						tree_brLen2_r[nbr2_r] = tree_brLen[k];
						nbr2_r++;
					}
				}

				for(k=0; k<nbr2; k++){
					diff[k] = fabs(cum1[k]-cum2[k])/(cum1[k]+cum2[k]);
				}	

				for(k=0; k<nbr2_r; k++){
					diff_r[k] = fabs(cum1_r[k]-cum2_r[k])/(cum1_r[k]+cum2_r[k]);
				}


				for(d=0; d<Dg; d++){

					if(Dg_norm_type[d]==0){  //unrarefied
						tmp1 = 0.;
						tmp2 = 0.;
						for(k=0; k<nbr2; k++){
							w = tree_brLen2[k] * pow((cum1[k]+cum2[k]), Dg_type[d]);
							tmp1 += w;
							tmp2 += diff[k]*w;
						}							
	

					}else{  //rarefied
						tmp1 = 0.;
						tmp2 = 0.;
						for(k=0; k<nbr2_r; k++){
							w = tree_brLen2_r[k] * pow((cum1_r[k]+cum2_r[k]), Dg_type[d]);
							tmp1 += w;
							tmp2 += diff_r[k]*w;
						}							

					}

					dist[indexD[d]+i][j] = tmp2/tmp1;	
					dist[indexD[d]+j][i] = dist[indexD[d]+i][j];	

				}


			}

			//presence-absence distance
			if(Dpg>0 || Duw>0){

				nbr2 = 0;
				nbr2_r = 0;

				for(k=0; k<nbr; k++){
					if((cum_b[k][i] + cum_b[k][j])!=0){
						cum1[nbr2] = cum_b[k][i];
						cum2[nbr2] = cum_b[k][j];
						tree_brLen2[nbr2] = tree_brLen[k];
						nbr2++;
					}

					if((cum_rb[k][i] + cum_rb[k][j])!=0){
						cum1_r[nbr2_r] = cum_rb[k][i];
						cum2_r[nbr2_r] = cum_rb[k][j];
						tree_brLen2_r[nbr2_r] = tree_brLen[k];
						nbr2_r++;
					}
				}


				if(Dpg>0){

					for(k=0; k<nbr2; k++){
						diff[k] = fabs(cum1[k]-cum2[k])/(cum1[k]+cum2[k]);
					}	

					for(k=0; k<nbr2_r; k++){
						diff_r[k] = fabs(cum1_r[k]-cum2_r[k])/(cum1_r[k]+cum2_r[k]);
					}

					for(d=0; d<Dpg; d++){

						if(Dpg_norm_type[d]==0){ //unrarefied

							tmp1 = 0.;
							tmp2 = 0.;
							for(k=0; k<nbr2; k++){
								w = tree_brLen2[k] * pow((cum1[k]+cum2[k]), Dpg_type[d]);
								tmp1 += w;
								tmp2 += diff[k]*w;
							}								

						}else{  //rarefied

							tmp1 = 0.;
							tmp2 = 0.;
							for(k=0; k<nbr2_r; k++){
								w = tree_brLen2_r[k] * pow((cum1_r[k]+cum2_r[k]), Dpg_type[d]);
								tmp1 += w;
								tmp2 += diff[k]*w;
							}							
	
						}

						dist[indexD[Dg+d]+i][j] = tmp2/tmp1;	
						dist[indexD[Dg+d]+j][i] = dist[indexD[Dg+d]+i][j];	

					}


				}

				if(Duw>0){

					if(Duw_norm==0){ //unrarefied

						tmp1 = 0.;
						tmp2 = 0.;
						for(k=0; k<nbr2; k++){

							tmp1 += tree_brLen2[k];
							if(cum1[k]>0) cum1[k] = 1;
							if(cum2[k]>0) cum2[k] = 1;
							tmp2 += ( fabs(cum1[k]-cum2[k])/(cum1[k]+cum2[k]) ) * tree_brLen2[k];

						}		

					}else{  //rarefied
						
						tmp1 = 0.;
						tmp2 = 0.;
						for(k=0; k<nbr2_r; k++){

							tmp1 += tree_brLen2_r[k];
							if(cum1_r[k]>0) cum1_r[k] = 1;
							if(cum2_r[k]>0) cum2_r[k] = 1;
							tmp2 += ( fabs(cum1_r[k]-cum2_r[k])/(cum1_r[k]+cum2_r[k]) ) * tree_brLen2_r[k];

						}

					}


					dist[indexD[Dg+Dpg]+i][j] = tmp2/tmp1;	
					dist[indexD[Dg+Dpg]+j][i] = dist[indexD[Dg+Dpg]+i][j];


				}

			}






		}
	}



	//free_ivector(node, 0, nbr-1);
	//free_ivector(node_loc, 0, nbr-1);
	//free_dmatrix(otu_perc, 0, n-1, 0, m-1);

	free_ivector(indexD, 0, ndist-1);
	free_dvector(cum1, 0, nbr-1);
	free_dvector(cum1_r, 0, nbr-1);
	free_dvector(cum2, 0, nbr-1);
	free_dvector(cum2_r, 0, nbr-1);
	free_dvector(diff, 0, nbr-1);
	free_dvector(diff_r, 0, nbr-1);
	free_dvector(tree_brLen2, 0, nbr-1);
	free_dvector(tree_brLen2_r, 0, nbr-1);
	free_ivector(tree_upNode_rank, 0, nbr-1); free_ivector(tree_upNode_index, 0, nbr-1); //free_ivector(tree_upNode_sort, 0, nbr-1);
	free_ivector(tree_downNode_rank, 0, nbr-1); free_ivector(tree_downNode_index, 0, nbr-1); //free_ivector(tree_downNode_sort, 0, nbr-1);
} 



// Distance: (only include dist that don't use tree) Bray-Curtis (Dbc) and Jaccard (Dj)
// provide two version of OTU: percentages from counts with and without rarefaction. 
// provide normalization method for each distance
void Dist_v3(int n, int m, int Dbc, int Dbc_norm, int Dj, int Dj_norm, double **otu, double **otu_r, double **dist){

	int ndist=Dbc+Dj, *indexD, flag=0, d, k, i, j;
	double tmp, tmp1, tmp2;

	indexD = ivector(0, ndist-1);

	for(i=0; i<n; i++){
		dist[i][i] = 0.;
	}

	for(d=0; d<ndist; d++){
		indexD[d] = d*n;
		for(i=0; i<n; i++){
			dist[indexD[d]+i][i] = 0.;
		}

	}	


	for(i=1; i<n; i++){
		for(j=0; j<i; j++){

			if(Dbc){

				if(Dbc_norm==0){  //unrarefied
					tmp1 = 0.;
					tmp2 = 0.;
					for(k=0; k<m; k++){
						tmp2 += fabs(otu[i][k] - otu[j][k]);
						tmp1 += (otu[i][k] + otu[j][k]);
					}				
				}else{ //rarefied
					tmp1 = 0.;
					tmp2 = 0.;
					for(k=0; k<m; k++){
						tmp2 += fabs(otu_r[i][k] - otu_r[j][k]);
						tmp1 += (otu_r[i][k] + otu_r[j][k]);
					}					
				}

				dist[i][j] = tmp2/tmp1;	
				dist[j][i] = dist[i][j];
			}

			if(Dj){

				if(Dj_norm==0){  //unrarefied

					tmp1 = 0.;
					tmp2 = 0.;
					for(k=0; k<m; k++){
						if(otu[i][k]>0 || otu[j][k]>0){
							tmp1 += 1;
						}
						if(otu[i][k]>0 && otu[j][k]>0){
							tmp2 += 1;
						}					
					}	

				}else{ //rarefied
					
					tmp1 = 0.;
					tmp2 = 0.;
					for(k=0; k<m; k++){
						if(otu_r[i][k]>0 || otu_r[j][k]>0){
							tmp1 += 1;
						}
						if(otu_r[i][k]>0 && otu_r[j][k]>0){
							tmp2 += 1;
						}					
					}

				}

				dist[indexD[Dbc]+i][j] = 1- tmp2/tmp1;	
				dist[indexD[Dbc]+j][i] = dist[indexD[Dbc]+i][j];

			}

		}
	}	
	
	free_ivector(indexD, 0, ndist-1);

} 

void Hat(int n, int p, double **x, double **H){
	
		int i, j, k;
		double **tmp_m, **tmp_m2;

		tmp_m = dmatrix(1, p, 1, p);
		tmp_m2 = dmatrix(0,n-1,0,p-1);
		
		for(j=0; j<p; j++){
			for(k=j; k<p; k++){
				tmp_m[j+1][k+1] = 0.;
				for(i=0; i<n; i++){
					tmp_m[j+1][k+1] += x[j][i] * x[k][i];
				}
				tmp_m[k+1][j+1] = tmp_m[j+1][k+1];
			}
		}
		
		invv(tmp_m, p);

		for(i=0; i<n; i++){
			for(j=0; j<p; j++){
				tmp_m2[i][j] = 0.;
				for(k=0; k<p; k++){
					tmp_m2[i][j] += x[k][i] * tmp_m[k+1][j+1];
				}
			}
		}

		for(i=0; i<n; i++){
			for(j=i; j<n; j++){
				H[i][j] = 0;
				for(k=0; k<p; k++){
					H[i][j] += tmp_m2[i][k] * x[k][j];
				}
				H[j][i] = H[i][j];
			}
		}

		free_dmatrix(tmp_m, 1, p, 1, p);
		free_dmatrix(tmp_m2, 0,n-1,0,p-1);
	}

//void trF(int n, int ndist, double **H, double **G_dist, double *s_obs){
//
//	int i, j, d, k, indexD;
//	double **tmp_m, **tmp_Im, **IH, *tmp_s_obs;
//	tmp_m = dmatrix(0, n-1, 0, n-1);
//	IH = dmatrix(0, n-1, 0, n-1);
//	tmp_Im = dmatrix(0, n-1, 0, n-1);
//	tmp_s_obs = dvector(0, ndist-1);
//
//	for(i=0; i<n; i++){
//		for(j=0; j<n; j++){
//			if(i==j){
//				IH[i][j] = 1-H[i][j];
//			}else{
//				IH[i][j] = -H[i][j];
//			}
//			
//		}
//	}
//
//	for(d=0; d<ndist; d++){
//		indexD = d*n;
//		for(i=0; i<n; i++){
//			for(j=0; j<n; j++){
//				tmp_m[i][j] = 0;
//				tmp_Im[i][j] = 0;
//				for(k=0; k<n; k++){
//					tmp_m[i][j] += H[i][k] * G_dist[indexD+k][j];
//					tmp_Im[i][j] += IH[i][k] * G_dist[indexD+k][j];
//				}
//				
//			}
//		}
//
//		//print_dm(tmp_m, 0, 10, 0, 10, "tmp_m");
//
//		s_obs[d] = 0;
//		tmp_s_obs[d] = 0;
//		for(i=0; i<n; i++){
//			for(j=0; j<n; j++){
//				s_obs[d] += tmp_m[i][j] * H[j][i];
//				tmp_s_obs[d] += tmp_Im[i][j] * IH[j][i];
//			}
//
//		}
//
//		s_obs[d] /= tmp_s_obs[d];
//	}
//
//	free_dmatrix(tmp_m, 0, n-1, 0, n-1);
//	free_dmatrix(IH, 0, n-1, 0, n-1);
//	free_dmatrix(tmp_Im, 0, n-1, 0, n-1);
//	free_dvector(tmp_s_obs, 0, ndist-1);
//}


void trGH(int n, int ndist, double **H, double **G_dist, double *s_obs){

	int i, j, d, k, indexD;
	double **tmp_m;
	tmp_m = dmatrix(0, n-1, 0, n-1);
	
	for(d=0; d<ndist; d++){
		indexD = d*n;

		//print_dm(tmp_m, 0, 10, 0, 10, "tmp_m");

		s_obs[d] = 0;
		for(i=0; i<n; i++){
			for(j=0; j<n; j++){
				s_obs[d] += G_dist[indexD+i][j] * H[j][i];
			}

		}

	}

	free_dmatrix(tmp_m, 0, n-1, 0, n-1);
	
}

void permute_work_woCov_v1(int n, int p, double **x, int ndist, double **G_dist, double *s_obs, double **s_perm, long start_nperm, long end_nperm, double *count_dist, int *flag, long *next_end_nperm){

	long l;
	int i, j, k, d, *perm_index;
	double **x_perm, **H_perm, tmp;

	perm_index = ivector(0, n-1);
	x_perm = dmatrix(0, p-1, 0, n-1);
	H_perm = dmatrix(0, n-1, 0, n-1);

	for(l=start_nperm; l<=end_nperm; l++){

		//permute X
		getPermute(perm_index, n);

		for(i=0; i<n; i++){
			for(j=0; j<p; j++){
				x_perm[j][i] = x[j][perm_index[i]];
			}

		}
		//if(l==0)	print_dm(x_perm, 0, 0, 0, 10, "first 10 obs in x_perm at the first round of permutation");
		//get permuted test stat
		Hat(n, p, x_perm, H_perm);
		trGH(n, ndist, H_perm, G_dist, s_perm[l]);
		//if(l<10) {
		//	printf("====== #sim=%ld ========\n", l );
		//	print_dv(s_perm[l], 0, ndist-1, "s_perm");

		//}
		tmp = 0;
		for(d=0; d<ndist; d++){
			if(s_perm[l][d] > s_obs[d]){
				count_dist[d] +=1;
			}
			if(s_perm[l][d] > tmp){
				tmp = s_perm[l][d];
			}		
		}

	}

	(*flag) = 0;
	tmp = end_nperm + 1;
	for(d=0; d<ndist; d++){
		if(tmp > count_dist[d]){
			tmp = count_dist[d];
		}
	}

	if(tmp<1){
		(*next_end_nperm) = ( end_nperm + 1) * 100 - 1;
		(*flag) = 1;

	}else if(tmp<10){
		(*next_end_nperm) = ( end_nperm + 1) * 10 - 1;
		(*flag) = 1;

	}else if(tmp<20){
		(*next_end_nperm) = ( end_nperm + 1) * 5 - 1;
		(*flag) = 1;

	}else{
		(*next_end_nperm) = ( end_nperm + 1) - 1;
		(*flag) = 0;	
	}
	
	//if(tmp<10){
	//	(*next_end_nperm) = ( end_nperm + 1) * 100 - 1;
	//	(*flag) = 1;

	//}else if(tmp<20){
	//	(*next_end_nperm) = ( end_nperm + 1) * 50 - 1;
	//	(*flag) = 1;

	//}else if(tmp<50){
	//	(*next_end_nperm) = ( end_nperm + 1) * 20 - 1;
	//	(*flag) = 1;

	//}else{
	//	(*next_end_nperm) = ( end_nperm + 1) - 1;
	//	(*flag) = 0;	
	//}

	free_ivector(perm_index, 0, n-1);
	free_dmatrix(x_perm, 0, p-1, 0, n-1);
	free_dmatrix(H_perm, 0, n-1, 0, n-1);
}

void permuteStrata_work_woCov_v1(int nstrata, int *n_subj_strata, int n, int p, double **x, int ndist, double **G_dist, double *s_obs, double **s_perm, long start_nperm, long end_nperm, double *count_dist, int *flag, long *next_end_nperm){

	long l;
	int i, j, k, d, s, subj_start, *perm_index;
	double **x_perm, **H_perm, tmp;

	perm_index = ivector(0, n-1);
	x_perm = dmatrix(0, p-1, 0, n-1);
	H_perm = dmatrix(0, n-1, 0, n-1);

	for(l=start_nperm; l<=end_nperm; l++){

		//permute X
		//getPermute(perm_index, n);

		//for(i=0; i<n; i++){
		//	for(j=0; j<p; j++){
		//		x_perm[j][i] = x[j][perm_index[i]];
		//	}

		//}

		// restircted permute X
		//for(i=0; i<(int)(n/2); i++){
		//	if(runifC3P()<0.5){
		//		for(j=0; j<p; j++){
		//			x_perm[j][i*2] = x[j][i*2+1];
		//			x_perm[j][i*2+1] = x[j][i*2];
		//		}			
		//	}else{
		//		for(j=0; j<p; j++){
		//			x_perm[j][i*2] = x[j][i*2];
		//			x_perm[j][i*2+1] = x[j][i*2+1];
		//		}
		//	}
		//}
		subj_start = 0;
		for(s=0; s<nstrata; s++){
			getPermute(perm_index, n_subj_strata[s]);
			for(i=0; i<n_subj_strata[s]; i++){
				for(j=0; j<p; j++){
					x_perm[j][i+subj_start] = x[j][perm_index[i]+subj_start];
					//if(l==0 && s==(nstrata-1) && i==(n_subj_strata[s]-1)){
					//	printf("nstrata-1=%d, n_subj_strata[s]-1=%d, subj_start=%d, i+subj_start=%d, perm_index[i]+subj_start=%d, x[j][perm_index[i]+subj_start]=%f\n",  nstrata-1, n_subj_strata[s]-1, subj_start, i+subj_start, perm_index[i]+subj_start, x[j][perm_index[i]+subj_start]);
					//}
				}				
			}
			subj_start += n_subj_strata[s];
			
		}

		//if(l==0){
		//	
		//	print_dm(x, 0, 0, 0, n-1, "original x");
		//	print_dm(x_perm, 0, 0, 0, n-1, "x_perm at the first round of permutation");
		//}

		//get permuted test stat
		Hat(n, p, x_perm, H_perm);
		trGH(n, ndist, H_perm, G_dist, s_perm[l]);

		tmp = 0;
		for(d=0; d<ndist; d++){
			if(s_perm[l][d] > s_obs[d]){
				count_dist[d] +=1;
			}
			if(s_perm[l][d] > tmp){
				tmp = s_perm[l][d];
			}		
		}

	}

	(*flag) = 0;
	tmp = end_nperm + 1;
	for(d=0; d<ndist; d++){
		if(tmp > count_dist[d]){
			tmp = count_dist[d];
		}
	}

	if(tmp<1){
		(*next_end_nperm) = ( end_nperm + 1) * 100 - 1;
		(*flag) = 1;

	}else if(tmp<10){
		(*next_end_nperm) = ( end_nperm + 1) * 10 - 1;
		(*flag) = 1;

	}else if(tmp<20){
		(*next_end_nperm) = ( end_nperm + 1) * 5 - 1;
		(*flag) = 1;

	}else{
		(*next_end_nperm) = ( end_nperm + 1) - 1;
		(*flag) = 0;	
	}
	
	//if(tmp<10){
	//	(*next_end_nperm) = ( end_nperm + 1) * 100 - 1;
	//	(*flag) = 1;

	//}else if(tmp<20){
	//	(*next_end_nperm) = ( end_nperm + 1) * 50 - 1;
	//	(*flag) = 1;

	//}else if(tmp<50){
	//	(*next_end_nperm) = ( end_nperm + 1) * 20 - 1;
	//	(*flag) = 1;

	//}else{
	//	(*next_end_nperm) = ( end_nperm + 1) - 1;
	//	(*flag) = 0;	
	//}

	free_ivector(perm_index, 0, n-1);
	free_dmatrix(x_perm, 0, p-1, 0, n-1);
	free_dmatrix(H_perm, 0, n-1, 0, n-1);
}


void permutePair_work_woCov_v1(int n, int p, double **x, int ndist, double **G_dist, double *s_obs, double **s_perm, long start_nperm, long end_nperm, double *count_dist, int *flag, long *next_end_nperm){

	long l;
	int i, j, k, d, *perm_index;
	double **x_perm, **H_perm, tmp;

	perm_index = ivector(0, n-1);
	x_perm = dmatrix(0, p-1, 0, n-1);
	H_perm = dmatrix(0, n-1, 0, n-1);

	for(l=start_nperm; l<=end_nperm; l++){

		//permute X
		//getPermute(perm_index, n);

		//for(i=0; i<n; i++){
		//	for(j=0; j<p; j++){
		//		x_perm[j][i] = x[j][perm_index[i]];
		//	}

		//}

		// restircted permute X
		for(i=0; i<(int)(n/2); i++){
			if(runifC3P()<0.5){
				for(j=0; j<p; j++){
					x_perm[j][i*2] = x[j][i*2+1];
					x_perm[j][i*2+1] = x[j][i*2];
				}			
			}else{
				for(j=0; j<p; j++){
					x_perm[j][i*2] = x[j][i*2];
					x_perm[j][i*2+1] = x[j][i*2+1];
				}
			}
		}

		//if(l==0)	print_dm(x_perm, 0, 0, 0, 10, "first 10 obs in x_perm at the first round of permutation");
		//get permuted test stat
		Hat(n, p, x_perm, H_perm);
		trGH(n, ndist, H_perm, G_dist, s_perm[l]);

		tmp = 0;
		for(d=0; d<ndist; d++){
			if(s_perm[l][d] > s_obs[d]){
				count_dist[d] +=1;
			}
			if(s_perm[l][d] > tmp){
				tmp = s_perm[l][d];
			}		
		}

	}

	(*flag) = 0;
	tmp = end_nperm + 1;
	for(d=0; d<ndist; d++){
		if(tmp > count_dist[d]){
			tmp = count_dist[d];
		}
	}

	if(tmp<1){
		(*next_end_nperm) = ( end_nperm + 1) * 100 - 1;
		(*flag) = 1;

	}else if(tmp<10){
		(*next_end_nperm) = ( end_nperm + 1) * 10 - 1;
		(*flag) = 1;

	}else if(tmp<20){
		(*next_end_nperm) = ( end_nperm + 1) * 5 - 1;
		(*flag) = 1;

	}else{
		(*next_end_nperm) = ( end_nperm + 1) - 1;
		(*flag) = 0;	
	}
	
	//if(tmp<10){
	//	(*next_end_nperm) = ( end_nperm + 1) * 100 - 1;
	//	(*flag) = 1;

	//}else if(tmp<20){
	//	(*next_end_nperm) = ( end_nperm + 1) * 50 - 1;
	//	(*flag) = 1;

	//}else if(tmp<50){
	//	(*next_end_nperm) = ( end_nperm + 1) * 20 - 1;
	//	(*flag) = 1;

	//}else{
	//	(*next_end_nperm) = ( end_nperm + 1) - 1;
	//	(*flag) = 0;	
	//}

	free_ivector(perm_index, 0, n-1);
	free_dmatrix(x_perm, 0, p-1, 0, n-1);
	free_dmatrix(H_perm, 0, n-1, 0, n-1);
}

void Permanova_woCov_v1(int n, int ndist, long max_nperm, double **dist, int p, double **x, double *pvalue){

	long l, start_nperm=0, end_nperm=0, next_end_nperm=0;
	int flag, i, j, k, d, indexD, stage1_nperm=1000, *perm_index;
	double tmp, **tmp_dist, **G_dist, **H, *s_obs, **s_perm, *s_perm_d, count_min, *count_dist, minP=0, *minP_perm, pval_min=0;

	tmp_dist = dmatrix(0, n-1, 0, n-1);
	G_dist = dmatrix(0, (ndist*n-1), 0, n-1);
	H = dmatrix(0,n-1,0,n-1);
	s_obs = dvector(0, ndist-1);
	perm_index = ivector(0, n-1);
	s_perm = dmatrix(0, max_nperm-1, 0, ndist-1);

	count_dist = dvector(0, ndist-1);

	//transform the distance matrix
	for(d=0; d<ndist; d++){

		indexD = d*n;

		G_dist[indexD][0] = 0.;

		for(i=1; i<n; i++){
			G_dist[indexD+i][i] = 0.;
			for(j=0; j<i; j++){
				G_dist[indexD+i][j] = - (dist[indexD+i][j] * dist[indexD+i][j])/2;	
				G_dist[indexD+j][i] = G_dist[indexD+i][j];
			}
		}


		for(i=0; i<n; i++){
			tmp = 0.;
			for(j=0; j<n; j++){
				tmp += G_dist[indexD+j][i];
			}
			tmp /= n;

			for(j=0; j<n; j++){
				tmp_dist[j][i] = G_dist[indexD+j][i] - tmp;
			}
		}

		for(i=0; i<n; i++){
			tmp = 0.;
			for(j=0; j<n; j++){
				tmp += tmp_dist[i][j];
			}
			tmp /= n;
			for(j=0; j<n; j++){
				G_dist[indexD+i][j] = tmp_dist[i][j] - tmp;
			}

		}
		
	}

	
	//print_dm(G_dist, 0, 10, 0, 10, "G_d_0.5");

	//print_dm(G_dist, n, n+10, 0, 10, "G_d_1");

	//print_dm(G_dist, (2*n), (2*n)+10, 0, 10, "G_d_uw");

	// Calculate hat matrix H based on x
	Hat(n, p, x, H);
	//print_dm(H, 0, 10, 0, 10, "H");

	// Calculate observed test statistics
	trGH(n, ndist, H, G_dist, s_obs);
	
	//print_dv(s_obs, 0, ndist-1, "s_obs");

	// Do permutation
	for(d=0; d<ndist; d++){
		count_dist[d] = 0;
	}
	

	start_nperm = 0;
	end_nperm = 999;
	flag = 1;
	while( flag && end_nperm < max_nperm){

		permute_work_woCov_v1(n, p, x, ndist, G_dist, s_obs, s_perm, start_nperm, end_nperm, count_dist, &flag, &next_end_nperm);

		//printf("start_nperm=%ld, end_nperm=%ld, flag=%d, next_end_nperm=%ld\n", start_nperm, end_nperm, flag, next_end_nperm);
		if(flag){

			start_nperm = end_nperm + 1;
			end_nperm = next_end_nperm;

		}else{
			//printf("Pvalue accuracy achieved with the %d th permutation.\n", end_nperm+1);
			// the last step
			minP = 1;
			
			for(d=0; d<ndist; d++){
				pvalue[d] = (count_dist[d] + 1)/(end_nperm + 2);
				if(minP > pvalue[d]){
					minP = pvalue[d];
				}
			}
			
			if(ndist>1){

				
				s_perm_d = dvector(0, end_nperm);
				minP_perm = dvector(0, end_nperm);
				for(l=0; l<=end_nperm; l++){
					minP_perm[l] = 1;
				}

				for(d=0; d<ndist; d++){
					for(l=0; l<=end_nperm; l++){
						s_perm_d[l] = s_perm[l][d];
					}

					qRank_noTie((end_nperm+1), s_perm_d);
					for(l=0; l<=end_nperm; l++){
						if(minP_perm[l] > -s_perm_d[l]){
							minP_perm[l] = -s_perm_d[l];
						}
					}
				}

				count_min  = 0;
				for(l=0; l<=end_nperm; l++){
					if( minP > (end_nperm + 1 + minP_perm[l])/(end_nperm + 2) ){
						count_min += 1;
					}
				}
				pval_min = (count_min + 1)/(end_nperm + 2);

				pvalue[ndist] = pval_min;

				free_dvector(s_perm_d, 0, end_nperm);
				free_dvector(minP_perm, 0, end_nperm);				
			}

		}


		if(end_nperm >= max_nperm){
			printf("Warning: Inaccurate pvalue with %d permutation.\n", max_nperm);
			// the last step
			permute_work_woCov_v1(n, p, x, ndist, G_dist, s_obs, s_perm, start_nperm, max_nperm-1, count_dist, &flag, &next_end_nperm);

			minP = 1;
			for(d=0; d<ndist; d++){
				pvalue[d] = (count_dist[d] + 1)/(max_nperm + 1);
				if(minP > pvalue[d]){
					minP = pvalue[d];
				}
			}
			
			if(ndist>1){

				
				s_perm_d = dvector(0, max_nperm-1);
				minP_perm = dvector(0, max_nperm-1);
				for(l=0; l<max_nperm; l++){
					minP_perm[l] = 1;
				}

				for(d=0; d<ndist; d++){
					for(l=0; l<max_nperm; l++){
						s_perm_d[l] = s_perm[l][d];
					}

					qRank_noTie(max_nperm, s_perm_d);
					for(l=0; l<max_nperm; l++){
						if(minP_perm[l] > -s_perm_d[l]){
							minP_perm[l] = -s_perm_d[l];
						}
					}
				}

				count_min  = 0;
				for(l=0; l<max_nperm; l++){
					if( minP > (max_nperm + minP_perm[l])/(max_nperm + 1) ){
						count_min += 1;
					}
				}
				pval_min = (count_min + 1)/(max_nperm + 1);

				pvalue[ndist] = pval_min; 

				free_dvector(s_perm_d, 0, max_nperm-1);
				free_dvector(minP_perm, 0, max_nperm-1);

			}





		}
	}


	free_dmatrix(tmp_dist, 0, n-1, 0, n-1);
	free_dmatrix(G_dist, 0, (ndist*n-1), 0, n-1);
	free_dmatrix(H, 0, n-1, 0, n-1);

	free_dvector(s_obs, 0, ndist-1);

	free_ivector(perm_index, 0, n-1);
	free_dmatrix(s_perm, 0, max_nperm-1, 0, ndist-1);
	free_dvector(count_dist, 0, ndist-1);



}


void PermanovaPair_woCov_v1(int n, int ndist, long max_nperm, double **dist, int p, double **x, double *pvalue){

	long l, start_nperm=0, end_nperm=0, next_end_nperm=0;
	int flag, i, j, k, d, indexD, stage1_nperm=1000, *perm_index;
	double tmp, **tmp_dist, **G_dist, **H, *s_obs, **s_perm, *s_perm_d, count_min, *count_dist, minP=0, *minP_perm, pval_min=0;

	tmp_dist = dmatrix(0, n-1, 0, n-1);
	G_dist = dmatrix(0, (ndist*n-1), 0, n-1);
	H = dmatrix(0,n-1,0,n-1);
	s_obs = dvector(0, ndist-1);
	perm_index = ivector(0, n-1);
	s_perm = dmatrix(0, max_nperm-1, 0, ndist-1);

	count_dist = dvector(0, ndist-1);

	//transform the distance matrix
	for(d=0; d<ndist; d++){

		indexD = d*n;

		G_dist[indexD][0] = 0.;

		for(i=1; i<n; i++){
			G_dist[indexD+i][i] = 0.;
			for(j=0; j<i; j++){
				G_dist[indexD+i][j] = - (dist[indexD+i][j] * dist[indexD+i][j])/2;	
				G_dist[indexD+j][i] = G_dist[indexD+i][j];
			}
		}


		for(i=0; i<n; i++){
			tmp = 0.;
			for(j=0; j<n; j++){
				tmp += G_dist[indexD+j][i];
			}
			tmp /= n;

			for(j=0; j<n; j++){
				tmp_dist[j][i] = G_dist[indexD+j][i] - tmp;
			}
		}

		for(i=0; i<n; i++){
			tmp = 0.;
			for(j=0; j<n; j++){
				tmp += tmp_dist[i][j];
			}
			tmp /= n;
			for(j=0; j<n; j++){
				G_dist[indexD+i][j] = tmp_dist[i][j] - tmp;
			}

		}
		
	}

	
	//print_dm(G_dist, 0, 10, 0, 10, "G_d_0.5");

	//print_dm(G_dist, n, n+10, 0, 10, "G_d_1");

	//print_dm(G_dist, (2*n), (2*n)+10, 0, 10, "G_d_uw");

	// Calculate hat matrix H based on x
	Hat(n, p, x, H);
	//print_dm(H, 0, 10, 0, 10, "H");

	// Calculate observed test statistics
	trGH(n, ndist, H, G_dist, s_obs);
	
	//print_dv(s_obs, 0, ndist-1, "s_obs");

	// Do permutation
	for(d=0; d<ndist; d++){
		count_dist[d] = 0;
	}
	

	start_nperm = 0;
	end_nperm = 999;
	flag = 1;
	while( flag && end_nperm < max_nperm){

		permutePair_work_woCov_v1(n, p, x, ndist, G_dist, s_obs, s_perm, start_nperm, end_nperm, count_dist, &flag, &next_end_nperm);

		//printf("start_nperm=%ld, end_nperm=%ld, flag=%d, next_end_nperm=%ld\n", start_nperm, end_nperm, flag, next_end_nperm);
		if(flag){

			start_nperm = end_nperm + 1;
			end_nperm = next_end_nperm;

		}else{
			//printf("Pvalue accuracy achieved with the %d th permutation.\n", end_nperm+1);
			// the last step
			minP = 1;
			for(d=0; d<ndist; d++){
				pvalue[d] = (count_dist[d] + 1)/(end_nperm + 2);
				if(minP > pvalue[d]){
					minP = pvalue[d];
				}
			}
			
			if(ndist>1){

				
				s_perm_d = dvector(0, end_nperm);
				minP_perm = dvector(0, end_nperm);
				for(l=0; l<=end_nperm; l++){
					minP_perm[l] = 1;
				}

				for(d=0; d<ndist; d++){
					for(l=0; l<=end_nperm; l++){
						s_perm_d[l] = s_perm[l][d];
					}

					qRank_noTie((end_nperm+1), s_perm_d);
					for(l=0; l<=end_nperm; l++){
						if(minP_perm[l] > -s_perm_d[l]){
							minP_perm[l] = -s_perm_d[l];
						}
					}
				}

				count_min  = 0;
				for(l=0; l<=end_nperm; l++){
					if( minP > (end_nperm + 1 + minP_perm[l])/(end_nperm + 2) ){
						count_min += 1;
					}
				}
				pval_min = (count_min + 1)/(end_nperm + 2);

				pvalue[ndist] = pval_min;

				free_dvector(s_perm_d, 0, end_nperm);
				free_dvector(minP_perm, 0, end_nperm);				
			}

		}


		if(end_nperm >= max_nperm){
			printf("Warning: Inaccurate pvalue with %d permutation.\n", max_nperm);
			// the last step
			permutePair_work_woCov_v1(n, p, x, ndist, G_dist, s_obs, s_perm, start_nperm, max_nperm-1, count_dist, &flag, &next_end_nperm);

			minP = 1;
			for(d=0; d<ndist; d++){
				pvalue[d] = (count_dist[d] + 1)/(max_nperm + 1);
				if(minP > pvalue[d]){
					minP = pvalue[d];
				}
			}
			
			if(ndist>1){

				
				s_perm_d = dvector(0, max_nperm-1);
				minP_perm = dvector(0, max_nperm-1);
				for(l=0; l<max_nperm; l++){
					minP_perm[l] = 1;
				}

				for(d=0; d<ndist; d++){
					for(l=0; l<max_nperm; l++){
						s_perm_d[l] = s_perm[l][d];
					}

					qRank_noTie(max_nperm, s_perm_d);
					for(l=0; l<max_nperm; l++){
						if(minP_perm[l] > -s_perm_d[l]){
							minP_perm[l] = -s_perm_d[l];
						}
					}
				}

				count_min  = 0;
				for(l=0; l<max_nperm; l++){
					if( minP > (max_nperm + minP_perm[l])/(max_nperm + 1) ){
						count_min += 1;
					}
				}
				pval_min = (count_min + 1)/(max_nperm + 1);

				pvalue[ndist] = pval_min; 

				free_dvector(s_perm_d, 0, max_nperm-1);
				free_dvector(minP_perm, 0, max_nperm-1);

			}





		}
	}


	free_dmatrix(tmp_dist, 0, n-1, 0, n-1);
	free_dmatrix(G_dist, 0, (ndist*n-1), 0, n-1);
	free_dmatrix(H, 0, n-1, 0, n-1);

	free_dvector(s_obs, 0, ndist-1);

	free_ivector(perm_index, 0, n-1);
	free_dmatrix(s_perm, 0, max_nperm-1, 0, ndist-1);
	free_dvector(count_dist, 0, ndist-1);



}

void PermanovaStrata_woCov_v1(int *strata, int n, int ndist, long max_nperm, double **dist, int p, double **x, double *pvalue){

	long l, start_nperm=0, end_nperm=0, next_end_nperm=0;
	int flag, nstrata, *n_subj_strata, i, j, k, d, indexD, stage1_nperm=1000, *perm_index;
	double tmp, **tmp_dist, **G_dist, **H, *s_obs, **s_perm, *s_perm_d, count_min, *count_dist, minP=0, *minP_perm, pval_min=0;

	tmp_dist = dmatrix(0, n-1, 0, n-1);
	G_dist = dmatrix(0, (ndist*n-1), 0, n-1);
	H = dmatrix(0,n-1,0,n-1);
	s_obs = dvector(0, ndist-1);
	perm_index = ivector(0, n-1);
	s_perm = dmatrix(0, max_nperm-1, 0, ndist-1);
	n_subj_strata = ivector(0, n-1);

	count_dist = dvector(0, ndist-1);

	// obtain the unique strata and #obs in each strata
	nstrata = 0;
	for(i=0; i<n; i++){
		n_subj_strata[i] = 1;
	}
	for(i=1; i<n; i++){
		if(strata[i]==strata[i-1]){
			n_subj_strata[nstrata] += 1;
		}else{
			nstrata++;
		}
	}
	nstrata++;
	//print_iv(strata, 0, n-1, "strata variable");
	//printf("nstrata=%d\n", nstrata);
	//print_iv(n_subj_strata, 0, nstrata-1, "#obs in each strata");

	// transform the distance matrix
	for(d=0; d<ndist; d++){

		indexD = d*n;

		G_dist[indexD][0] = 0.;

		for(i=1; i<n; i++){
			G_dist[indexD+i][i] = 0.;
			for(j=0; j<i; j++){
				G_dist[indexD+i][j] = - (dist[indexD+i][j] * dist[indexD+i][j])/2;	
				G_dist[indexD+j][i] = G_dist[indexD+i][j];
			}
		}


		for(i=0; i<n; i++){
			tmp = 0.;
			for(j=0; j<n; j++){
				tmp += G_dist[indexD+j][i];
			}
			tmp /= n;

			for(j=0; j<n; j++){
				tmp_dist[j][i] = G_dist[indexD+j][i] - tmp;
			}
		}

		for(i=0; i<n; i++){
			tmp = 0.;
			for(j=0; j<n; j++){
				tmp += tmp_dist[i][j];
			}
			tmp /= n;
			for(j=0; j<n; j++){
				G_dist[indexD+i][j] = tmp_dist[i][j] - tmp;
			}

		}
		
	}

	
	//print_dm(G_dist, 0, 10, 0, 10, "G_d_0.5");

	//print_dm(G_dist, n, n+10, 0, 10, "G_d_1");

	//print_dm(G_dist, (2*n), (2*n)+10, 0, 10, "G_d_uw");

	// Calculate hat matrix H based on x
	Hat(n, p, x, H);
	//print_dm(H, 0, 10, 0, 10, "H");

	// Calculate observed test statistics
	trGH(n, ndist, H, G_dist, s_obs);
	
	//print_dv(s_obs, 0, ndist-1, "s_obs");

	// Do permutation
	for(d=0; d<ndist; d++){
		count_dist[d] = 0;
	}
	

	start_nperm = 0;
	end_nperm = 999;
	flag = 1;
	while( flag && end_nperm < max_nperm){

		permuteStrata_work_woCov_v1(nstrata, n_subj_strata, n, p, x, ndist, G_dist, s_obs, s_perm, start_nperm, end_nperm, count_dist, &flag, &next_end_nperm);

		//printf("start_nperm=%ld, end_nperm=%ld, flag=%d, next_end_nperm=%ld\n", start_nperm, end_nperm, flag, next_end_nperm);
		if(flag){

			start_nperm = end_nperm + 1;
			end_nperm = next_end_nperm;

		}else{
			//printf("Pvalue accuracy achieved with the %d th permutation.\n", end_nperm+1);
			// the last step
			minP = 1;
			for(d=0; d<ndist; d++){
				pvalue[d] = (count_dist[d] + 1)/(end_nperm + 2);
				if(minP > pvalue[d]){
					minP = pvalue[d];
				}
			}
			
			if(ndist>1){

				
				s_perm_d = dvector(0, end_nperm);
				minP_perm = dvector(0, end_nperm);
				for(l=0; l<=end_nperm; l++){
					minP_perm[l] = 1;
				}

				for(d=0; d<ndist; d++){
					for(l=0; l<=end_nperm; l++){
						s_perm_d[l] = s_perm[l][d];
					}

					qRank_noTie((end_nperm+1), s_perm_d);
					for(l=0; l<=end_nperm; l++){
						if(minP_perm[l] > -s_perm_d[l]){
							minP_perm[l] = -s_perm_d[l];
						}
					}
				}

				count_min  = 0;
				for(l=0; l<=end_nperm; l++){
					if( minP > (end_nperm + 1 + minP_perm[l])/(end_nperm + 2) ){
						count_min += 1;
					}
				}
				pval_min = (count_min + 1)/(end_nperm + 2);

				pvalue[ndist] = pval_min;

				free_dvector(s_perm_d, 0, end_nperm);
				free_dvector(minP_perm, 0, end_nperm);				
			}

		}


		if(end_nperm >= max_nperm){
			printf("Warning: Inaccurate pvalue with %d permutation.\n", max_nperm);
			// the last step
			permuteStrata_work_woCov_v1(nstrata, n_subj_strata, n, p, x, ndist, G_dist, s_obs, s_perm, start_nperm, max_nperm-1, count_dist, &flag, &next_end_nperm);

			minP = 1;
			for(d=0; d<ndist; d++){
				pvalue[d] = (count_dist[d] + 1)/(max_nperm + 1);
				if(minP > pvalue[d]){
					minP = pvalue[d];
				}
			}
			
			if(ndist>1){

				
				s_perm_d = dvector(0, max_nperm-1);
				minP_perm = dvector(0, max_nperm-1);
				for(l=0; l<max_nperm; l++){
					minP_perm[l] = 1;
				}

				for(d=0; d<ndist; d++){
					for(l=0; l<max_nperm; l++){
						s_perm_d[l] = s_perm[l][d];
					}

					qRank_noTie(max_nperm, s_perm_d);
					for(l=0; l<max_nperm; l++){
						if(minP_perm[l] > -s_perm_d[l]){
							minP_perm[l] = -s_perm_d[l];
						}
					}
				}

				count_min  = 0;
				for(l=0; l<max_nperm; l++){
					if( minP > (max_nperm + minP_perm[l])/(max_nperm + 1) ){
						count_min += 1;
					}
				}
				pval_min = (count_min + 1)/(max_nperm + 1);

				pvalue[ndist] = pval_min; 

				free_dvector(s_perm_d, 0, max_nperm-1);
				free_dvector(minP_perm, 0, max_nperm-1);

			}





		}
	}


	free_dmatrix(tmp_dist, 0, n-1, 0, n-1);
	free_dmatrix(G_dist, 0, (ndist*n-1), 0, n-1);
	free_dmatrix(H, 0, n-1, 0, n-1);

	free_dvector(s_obs, 0, ndist-1);

	free_ivector(perm_index, 0, n-1);
	free_dmatrix(s_perm, 0, max_nperm-1, 0, ndist-1);
	free_dvector(count_dist, 0, ndist-1);
	free_ivector(n_subj_strata, 0, n-1);


}



void Res(int n, int BIN, double *x, int q, double **z, double *x_est, double *x_res){

	int i, j, jj;
	double *est, x_mean, x_sd, *xz, **zz;
	est = dvector(0, q-1);
	
	if(BIN){
		
		logisticReg_v0(n, q, x, z, est);
		
		for(i=0;i<n;i++){
			x_est[i] = 0.;
			for(j=0;j<q;j++){
				x_est[i] += est[j]*z[i][j];
			}
			x_est[i] = exp(x_est[i]);
			x_est[i] = x_est[i]/(1+x_est[i]);
			x_res[i] = x[i] - x_est[i];
		}

	}else{

		xz = dvector(0, q-1);
		zz = dmatrix(0, q, 0, q);

		for(j=0;j<q;j++){
			xz[j] = 0.;
			for(i=0;i<n;i++){
				xz[j] += x[i]*z[i][j];
			}

			for(jj=0;jj<q;jj++){
				zz[j+1][jj+1] = 0.;
				for(i=0;i<n;i++){
					zz[j+1][jj+1] += z[i][j] * z[i][jj];
				}	
			}
		}

		invv(zz, q);
		for(j=0;j<q;j++){
			est[j] = 0.;
			for(jj=0;jj<q;jj++){
				est[j] += zz[j+1][jj+1]*xz[jj];
			}
		}
		//print_dv(est, 0, q-1, "est");

		for(i=0;i<n;i++){
			x_est[i] = 0.;
			for(j=0;j<q;j++){
				x_est[i] += est[j]*z[i][j];
			}		
			x_res[i] = (x[i]-x_est[i]);
		}

		free_dvector(xz, 0, q-1);
		free_dmatrix(zz, 0, q, 0, q);

	}

	free_dvector(est, 0, q-1);
}


// if pb > 0 and pc > 0, then xb_tmp is a (pb x n) matrix containing the vector gamma*z, xb_par_xc is a (pb x pc) matrix containing the parameter estimate of beta in regression xb ~ r*z + beta*xc
// if pb > 0 and pc == 0, then xb_tmp is a (pb x n) matrix containing the vector xb_est
void permute_work_wCov_v1(int n, int pb, double **xb_tmp, double **xb_par_xc, int pc, double **xc_est, double **xc_res, int q, double **z, int ndist, double **G_dist, double *s_obs, double **s_perm, long start_nperm, long end_nperm, double *count_dist, int *flag, long *next_end_nperm){

	long l;
	int i, j, k, d, p = pb+pc, *perm_index;
	double *sample_unif, **xb_est, **x_perm, *x_tmp, **H_perm, tmp, *tmp_v;

	sample_unif = dvector(0, n-1);
	perm_index = ivector(0, n-1);
	x_perm = dmatrix(0, p-1, 0, n-1);
	x_tmp = dvector(0, n-1);
	tmp_v = dvector(0, n-1);
	H_perm = dmatrix(0, n-1, 0, n-1);
	
	if(pb>0){
		xb_est = dmatrix(0, pb, 0, n-1);
		if(pc == 0){
			for(j=0; j<pb; j++){
				for(i=0;i<n;i++){
					xb_est[j][i] = xb_tmp[j][i];
				}
			}
		}
	}

	for(l=start_nperm; l<=end_nperm; l++){

		//permute X
		if(pb>0 && pc>0){ // binary + continous
		
			for(j=0; j<pb; j++){
				for(i=0; i<n; i++){
					xb_est[j][i] = 0;
				}
			}

			// continous part
			getPermute(perm_index, n);

			for(j=0; j<pc; j++){
				
				for(i=0; i<n; i++){
					x_tmp[i] = xc_res[j][perm_index[i]] + xc_est[j][i];
				}
				Res(n, 0, x_tmp, q, z, tmp_v, x_perm[j]);	

				// update xb_est based on permuted xc_res
				for(k=0; k<pb; k++){
					for(i=0; i<n; i++){
						xb_est[k][i] += xb_par_xc[k][j] * xc_res[j][perm_index[i]];
					}
				}
				

			}

			for(j=0; j<pb; j++){
				for(i=0; i<n; i++){
					tmp = exp(xb_est[j][i]);
					xb_est[j][i] = tmp/(1+tmp);
				}
			}

			// binary part
			for(i=0;i<n;i++){
				sample_unif[i] = runifC3P();
			}

			for(j=0; j<pb; j++){
				
				for(i=0;i<n;i++){
					if(sample_unif[i] < xb_est[j][i]){
						x_tmp[i] = 1;
					}else{
						x_tmp[i] = 0;
					}
					
				}
				Res(n, 1, x_tmp, q, z, tmp_v, x_perm[j+pc]);			
			}

		}else if(pb>0){  // all binary: parametric bootstrap

			for(i=0;i<n;i++){
				sample_unif[i] = runifC3P();
			}

			for(j=0; j<pb; j++){
				
				for(i=0;i<n;i++){
					if(sample_unif[i] < xb_est[j][i]){
						x_tmp[i] = 1;
					}else{
						x_tmp[i] = 0;
					}
					
				}
				Res(n, 1, x_tmp, q, z, tmp_v, x_perm[j]);			
			}

		}else{ // all continous: Freeman-Lane permutation

			getPermute(perm_index, n);

			for(j=0; j<pc; j++){
				
				for(i=0; i<n; i++){
					x_tmp[i] = xc_res[j][perm_index[i]] + xc_est[j][i];
				}
				Res(n, 0, x_tmp, q, z, tmp_v, x_perm[j]);				
			}
		
		}


		//if(l==0)	print_dm(x_perm, 0, 0, 0, 10, "first 10 obs in x_perm at the first round of permutation");
		//get permuted test stat
		Hat(n, p, x_perm, H_perm);
		trGH(n, ndist, H_perm, G_dist, s_perm[l]);

		tmp = 0;
		for(d=0; d<ndist; d++){
			if(s_perm[l][d] > s_obs[d]){
				count_dist[d] +=1;
			}
			if(s_perm[l][d] > tmp){
				tmp = s_perm[l][d];
			}		
		}

	}

	(*flag) = 0;
	tmp = end_nperm + 1;
	for(d=0; d<ndist; d++){
		if(tmp > count_dist[d]){
			tmp = count_dist[d];
		}
	}

	if(tmp<1){
		(*next_end_nperm) = ( end_nperm + 1) * 100 - 1;
		(*flag) = 1;

	}else if(tmp<10){
		(*next_end_nperm) = ( end_nperm + 1) * 10 - 1;
		(*flag) = 1;

	}else if(tmp<20){
		(*next_end_nperm) = ( end_nperm + 1) * 5 - 1;
		(*flag) = 1;

	}else{
		(*next_end_nperm) = ( end_nperm + 1) - 1;
		(*flag) = 0;	
	}
	
	//if(tmp<10){
	//	(*next_end_nperm) = ( end_nperm + 1) * 100 - 1;
	//	(*flag) = 1;

	//}else if(tmp<20){
	//	(*next_end_nperm) = ( end_nperm + 1) * 50 - 1;
	//	(*flag) = 1;

	//}else if(tmp<50){
	//	(*next_end_nperm) = ( end_nperm + 1) * 20 - 1;
	//	(*flag) = 1;

	//}else{
	//	(*next_end_nperm) = ( end_nperm + 1) - 1;
	//	(*flag) = 0;	
	//}

	if(pb>0){
		free_dmatrix(xb_est, 0, pb, 0, n-1);
	}
	free_dvector(sample_unif, 0, n-1);
	free_ivector(perm_index, 0, n-1);
	free_dmatrix(x_perm, 0, p-1, 0, n-1);
	free_dvector(x_tmp, 0, n-1);
	free_dvector(tmp_v, 0, n-1);
	free_dmatrix(H_perm, 0, n-1, 0, n-1);
}

void Permanova_wCov_v1(int n, int ndist, long max_nperm, double **dist, int p, int *xBIN, double **x, int q, double **z, double *pvalue){

	long l, start_nperm=0, end_nperm=0, next_end_nperm=0;
	int flag, pb, pc, i, j, k, d, indexD, stage1_nperm=1000, *perm_index;  // pb and pc are numbers of binary and continous traits
	double tmp, **tmp_dist, **G_dist, **H, *s_obs, **s_perm, *s_perm_d, count_min, *count_dist, minP=0, *minP_perm, pval_min=0;
	// x_est contains the predicted x baed on z
	// x_res contains the residual of x
	double **xb, **xb_tmp, **xb_res, **xc, **xc_est, **xc_res, **x_res;
	double **zxc, *est, **xb_par_xc;
	
	x_res = dmatrix(0, p-1, 0, n-1);

	xb_par_xc = dmatrix(0, p-1, 0, p-1);
	xb = dmatrix(0, p-1, 0, n-1);
	xb_tmp = dmatrix(0, p-1, 0, n-1);
	xb_res = dmatrix(0, p-1, 0, n-1);
	xc = dmatrix(0, p-1, 0, n-1);
	xc_est = dmatrix(0, p-1, 0, n-1);
	xc_res = dmatrix(0, p-1, 0, n-1);
	tmp_dist = dmatrix(0, (ndist*n-1), 0, n-1);
	G_dist = dmatrix(0, (ndist*n-1), 0, n-1);
	H = dmatrix(0,n-1,0,n-1);
	s_obs = dvector(0, ndist-1);
	perm_index = ivector(0, n-1);
	s_perm = dmatrix(0, max_nperm-1, 0, ndist-1);
	
	count_dist = dvector(0, ndist-1);


	//transform the distance matrix
	for(d=0; d<ndist; d++){

		indexD = d*n;

		G_dist[indexD][0] = 0.;

		for(i=1; i<n; i++){
			G_dist[indexD+i][i] = 0.;
			for(j=0; j<i; j++){
				G_dist[indexD+i][j] = - (dist[indexD+i][j] * dist[indexD+i][j])/2;	
				G_dist[indexD+j][i] = G_dist[indexD+i][j];
			}
		}


		for(i=0; i<n; i++){
			tmp = 0.;
			for(j=0; j<n; j++){
				tmp += G_dist[indexD+j][i];
			}
			tmp /= n;

			for(j=0; j<n; j++){
				tmp_dist[indexD+j][i] = G_dist[indexD+j][i] - tmp;
			}
		}

		for(i=0; i<n; i++){
			tmp = 0.;
			for(j=0; j<n; j++){
				tmp += tmp_dist[indexD+i][j];
			}
			tmp /= n;
			for(j=0; j<n; j++){
				G_dist[indexD+i][j] = tmp_dist[indexD+i][j] - tmp;
			}

		}


	}

	//print_dm(G_dist, 0, 10, 0, 10, "G_d_0.5");

	//print_dm(G_dist, n, n+10, 0, 10, "G_d_1");

	//print_dm(G_dist, (2*n), (2*n)+10, 0, 10, "G_d_uw");

	//print_dm(G_dist, (3*n), (3*n)+10, 0, 10, "G_d_bc");

	// split x as binary and continous parts
	pb = 0; pc = 0;
	for(j=0; j<p; j++){

		if(xBIN[j]){

			for(i=0; i<n; i++){
				xb[pb][i] = x[j][i];
			}
			pb++;
		}else{

			for(i=0; i<n; i++){
				xc[pc][i] = x[j][i];
			}
			pc++;
		}
		
	
	}
	//printf("pb=%d, pc=%d\n", pb, pc);
	
	// adjust for covariates
	if(pb>0 && pc>0){  // binary + continous

		for(j=0; j<pc; j++){

			Res(n, 0, xc[j], q, z, xc_est[j], xc_res[j]);

			for(i=0; i<n; i++){
				x_res[j][i] = xc_res[j][i];
			}

		}

		zxc = dmatrix(0, n-1, 0, q+pc-1);
		est = dvector(0, q+pc-1);
		for(i=0; i<n; i++){
			for(j=0; j<q; j++){
				zxc[i][j] = z[i][j];		
			}
		}
		for(i=0; i<n; i++){
			for(j=0; j<pc; j++){
				zxc[i][j+q] = xc_res[j][i];		
			}
		}
		
		//print_dm(zxc, 0, 10, 0, q+pc-1, "zxc");
		//print_dm(xb, 0, 0, 0, 10, "xb");
		for(j=0; j<pb; j++){ 
			
			logisticReg_v0(n, (q + pc), xb[j], zxc, est);

			for(k=0; k<pc; k++){
				xb_par_xc[j][k] = est[q+k];
			}

			for(i=0;i<n;i++){
				xb_tmp[j][i] = 0;
				for(k=0; k<q; k++){
					xb_tmp[j][i] += z[i][k] * est[k];
				}

				x_res[j+pc][i] = xb_tmp[j][i];
				for(k=0; k<pc; k++){
					x_res[j+pc][i] += xc_res[k][i] * est[k+q];
				}
				tmp = exp(x_res[j+pc][i]);
				x_res[j+pc][i] = xb[j][i] - tmp/(1+tmp);
			}

		}

		free_dmatrix(zxc, 0, n-1, 0, q+pc-1);
		free_dvector(est, 0, q+pc-1);

	}else if(pb>0){  // all binary
		
		for(j=0; j<pb; j++){
			
			Res(n, 1, xb[j], q, z, xb_tmp[j], xb_res[j]);
			
			for(i=0; i<n; i++){
				x_res[j][i] = xb_res[j][i];
			}

		}	
		//print_dm(xb_tmp, 0, 0, 0, 10, "first 10 xb_est");
		//print_dm(xb_res, 0, 0, 0, 10, "first 10 xb_res");

	}else{   // all continous

		//print_dm(xc, 0, 0, 0, 10, "first 10 xc[0,]");
		//print_dm(z, 0, 10, 0, 1, "first 10 z");
		
		for(j=0; j<pc; j++){

			Res(n, 0, xc[j], q, z, xc_est[j], xc_res[j]);

			for(i=0; i<n; i++){
				x_res[j][i] = xc_res[j][i];
			}
		}
		//print_dm(xc_est, 0, 0, 0, 10, "first 10 xc_est[0,]");
		//print_dm(xc_res, 0, 0, 0, 10, "first 10 xc_res[0,]");
	}

	
	// Calculate hat matrix H based on x_res
	Hat(n, p, x_res, H);
	
	
	// Calculate observed test statistics
	trGH(n, ndist, H, G_dist, s_obs);
	
	//print_dv(s_obs, 0, ndist-1, "s_obs");

	// Do permutation
	for(d=0; d<ndist; d++){
		count_dist[d] = 0;
	}


	start_nperm = 0;
	end_nperm = 999;
	flag = 1;
	while( flag && end_nperm < max_nperm){

		
		permute_work_wCov_v1(n, pb, xb_tmp, xb_par_xc, pc, xc_est, xc_res, q, z, ndist, G_dist, s_obs, s_perm, start_nperm, end_nperm, count_dist, &flag, &next_end_nperm);

		//printf("start_nperm=%ld, end_nperm=%ld, flag=%d, next_end_nperm=%ld\n", start_nperm, end_nperm, flag, next_end_nperm);
		if(flag){

			start_nperm = end_nperm + 1;
			end_nperm = next_end_nperm;

		}else{
			//printf("Pvalue accuracy achieved with the %d th permutation.\n", end_nperm+1);
			// the last step
			minP = 1;
			for(d=0; d<ndist; d++){
				pvalue[d] = (count_dist[d] + 1)/(end_nperm + 2);
				if(minP > pvalue[d]){
					minP = pvalue[d];
				}
			}
			
			if(ndist>1){

				s_perm_d = dvector(0, end_nperm);
				minP_perm = dvector(0, end_nperm);
				for(l=0; l<=end_nperm; l++){
					minP_perm[l] = 1;
				}

				for(d=0; d<ndist; d++){
					for(l=0; l<=end_nperm; l++){
						s_perm_d[l] = s_perm[l][d];
					}

					qRank_noTie((end_nperm+1), s_perm_d);
					for(l=0; l<=end_nperm; l++){
						if(minP_perm[l] > -s_perm_d[l]){
							minP_perm[l] = -s_perm_d[l];
						}
					}
				}

				count_min  = 0;
				for(l=0; l<=end_nperm; l++){
					if( minP > (end_nperm + 1 + minP_perm[l])/(end_nperm + 2) ){
						count_min += 1;
					}
				}
				pval_min = (count_min + 1)/(end_nperm + 2);

				pvalue[ndist] = pval_min;

				free_dvector(s_perm_d, 0, end_nperm);
				free_dvector(minP_perm, 0, end_nperm);				
			}

		}


		if(end_nperm >= max_nperm){
			printf("Warning: Inaccurate pvalue with %d permutation.\n", max_nperm);
			// the last step
			permute_work_wCov_v1(n, pb, xb_tmp, xb_par_xc, pc, xc_est, xc_res, q, z, ndist, G_dist, s_obs, s_perm, start_nperm, max_nperm-1, count_dist, &flag, &next_end_nperm);

			minP = 1;
			for(d=0; d<ndist; d++){
				pvalue[d] = (count_dist[d] + 1)/(max_nperm + 1);
				if(minP > pvalue[d]){
					minP = pvalue[d];
				}
			}
			
			if(ndist>1){

				s_perm_d = dvector(0, max_nperm-1);
				minP_perm = dvector(0, max_nperm-1);
				for(l=0; l<max_nperm; l++){
					minP_perm[l] = 1;
				}

				for(d=0; d<ndist; d++){
					for(l=0; l<max_nperm; l++){
						s_perm_d[l] = s_perm[l][d];
					}

					qRank_noTie(max_nperm, s_perm_d);
					for(l=0; l<max_nperm; l++){
						if(minP_perm[l] > -s_perm_d[l]){
							minP_perm[l] = -s_perm_d[l];
						}
					}
				}

				count_min  = 0;
				for(l=0; l<max_nperm; l++){
					if( minP > (max_nperm + minP_perm[l])/(max_nperm + 1) ){
						count_min += 1;
					}
				}
				pval_min = (count_min + 1)/(max_nperm + 1);

				pvalue[ndist] = pval_min; 

				free_dvector(s_perm_d, 0, max_nperm-1);
				free_dvector(minP_perm, 0, max_nperm-1);

			}





		}
	}

	
	free_dmatrix(tmp_dist, 0, (ndist*n-1), 0, n-1);
	free_dmatrix(G_dist, 0, (ndist*n-1), 0, n-1);
	free_dmatrix(H, 0, n-1, 0, n-1);

	free_dvector(s_obs, 0, ndist-1);

	free_ivector(perm_index, 0, n-1);
	free_dmatrix(s_perm, 0, max_nperm-1, 0, ndist-1);
	free_dvector(count_dist, 0, ndist-1);

	free_dmatrix(xb, 0, p-1, 0, n-1);
	free_dmatrix(xb_tmp, 0, p-1, 0, n-1);
	free_dmatrix(xb_res, 0, p-1, 0, n-1);
	free_dmatrix(xc, 0, p-1, 0, n-1);
	free_dmatrix(xc_est, 0, p-1, 0, n-1);
	free_dmatrix(xc_res, 0, p-1, 0, n-1);
	free_dmatrix(xb_par_xc, 0, p-1, 0, p-1);
	free_dmatrix(x_res, 0, p-1, 0, n-1);
}


void permute_work_wCov_naive_v1(int n, int pb, double **xb_est, int pc, double **xc_est, double **xc_res, int q, double **z, int ndist, double **G_dist, double *s_obs, double **s_perm, long start_nperm, long end_nperm, double *count_dist, int *flag, long *next_end_nperm){

	long l;
	int i, j, k, d, p = pb+pc, *perm_index;
	double *sample_unif, **x_perm, *x_tmp, **H_perm, tmp, *tmp_v;

	sample_unif = dvector(0, n-1);
	perm_index = ivector(0, n-1);
	x_perm = dmatrix(0, p-1, 0, n-1);
	x_tmp = dvector(0, n-1);
	tmp_v = dvector(0, n-1);
	H_perm = dmatrix(0, n-1, 0, n-1);
	
	for(l=start_nperm; l<=end_nperm; l++){

		
		if(pb>0){  // binary: parametric bootstrap

			for(i=0;i<n;i++){
				sample_unif[i] = runifC3P();
			}

			for(j=0; j<pb; j++){
				
				for(i=0;i<n;i++){
					if(sample_unif[i] < xb_est[j][i]){
						x_tmp[i] = 1;
					}else{
						x_tmp[i] = 0;
					}
					
				}
				Res(n, 1, x_tmp, q, z, tmp_v, x_perm[j]);			
			}

		}
		
		if(pc>0){ // continous: Freeman-Lane permutation

			getPermute(perm_index, n);

			for(j=0; j<pc; j++){
				
				for(i=0; i<n; i++){
					x_tmp[i] = xc_res[j][perm_index[i]] + xc_est[j][i];
				}
				Res(n, 0, x_tmp, q, z, tmp_v, x_perm[j+pb]);				
			}
		
		}


		//if(l==0)	print_dm(x_perm, 0, 0, 0, 10, "first 10 obs in x_perm at the first round of permutation");
		//get permuted test stat
		Hat(n, p, x_perm, H_perm);
		trGH(n, ndist, H_perm, G_dist, s_perm[l]);

		tmp = 0;
		for(d=0; d<ndist; d++){
			if(s_perm[l][d] > s_obs[d]){
				count_dist[d] +=1;
			}
			if(s_perm[l][d] > tmp){
				tmp = s_perm[l][d];
			}		
		}

	}

	(*flag) = 0;
	tmp = end_nperm + 1;
	for(d=0; d<ndist; d++){
		if(tmp > count_dist[d]){
			tmp = count_dist[d];
		}
	}

	if(tmp<1){
		(*next_end_nperm) = ( end_nperm + 1) * 100 - 1;
		(*flag) = 1;

	}else if(tmp<10){
		(*next_end_nperm) = ( end_nperm + 1) * 10 - 1;
		(*flag) = 1;

	}else if(tmp<20){
		(*next_end_nperm) = ( end_nperm + 1) * 5 - 1;
		(*flag) = 1;

	}else{
		(*next_end_nperm) = ( end_nperm + 1) - 1;
		(*flag) = 0;	
	}
	
	//if(tmp<10){
	//	(*next_end_nperm) = ( end_nperm + 1) * 100 - 1;
	//	(*flag) = 1;

	//}else if(tmp<20){
	//	(*next_end_nperm) = ( end_nperm + 1) * 50 - 1;
	//	(*flag) = 1;

	//}else if(tmp<50){
	//	(*next_end_nperm) = ( end_nperm + 1) * 20 - 1;
	//	(*flag) = 1;

	//}else{
	//	(*next_end_nperm) = ( end_nperm + 1) - 1;
	//	(*flag) = 0;	
	//}

	
	free_dvector(sample_unif, 0, n-1);
	free_ivector(perm_index, 0, n-1);
	free_dmatrix(x_perm, 0, p-1, 0, n-1);
	free_dvector(x_tmp, 0, n-1);
	free_dvector(tmp_v, 0, n-1);
	free_dmatrix(H_perm, 0, n-1, 0, n-1);
}

void Permanova_wCov_naive_v1(int n, int ndist, long max_nperm, double **dist, int p, int *xBIN, double **x, int q, double **z, double *pvalue){

	long l, start_nperm=0, end_nperm=0, next_end_nperm=0;
	int flag, pb, pc, i, j, k, d, indexD, stage1_nperm=1000, *perm_index;  // pb and pc are numbers of binary and continous traits
	double tmp, **tmp_dist, **G_dist, **H, *s_obs, **s_perm, *s_perm_d, count_min, *count_dist, minP=0, *minP_perm, pval_min=0;
	// x_est contains the predicted x baed on z
	// x_res contains the residual of x
	double **xb, **xb_est, **xb_res, **xc, **xc_est, **xc_res, **x_res;
	double *est;
	
	x_res = dmatrix(0, p-1, 0, n-1);

	xb = dmatrix(0, p-1, 0, n-1);
	xb_est = dmatrix(0, p-1, 0, n-1);
	xb_res = dmatrix(0, p-1, 0, n-1);
	xc = dmatrix(0, p-1, 0, n-1);
	xc_est = dmatrix(0, p-1, 0, n-1);
	xc_res = dmatrix(0, p-1, 0, n-1);
	tmp_dist = dmatrix(0, (ndist*n-1), 0, n-1);
	G_dist = dmatrix(0, (ndist*n-1), 0, n-1);
	H = dmatrix(0,n-1,0,n-1);
	s_obs = dvector(0, ndist-1);
	perm_index = ivector(0, n-1);
	s_perm = dmatrix(0, max_nperm-1, 0, ndist-1);
	
	count_dist = dvector(0, ndist-1);


	//transform the distance matrix
	for(d=0; d<ndist; d++){

		indexD = d*n;

		G_dist[indexD][0] = 0.;

		for(i=1; i<n; i++){
			G_dist[indexD+i][i] = 0.;
			for(j=0; j<i; j++){
				G_dist[indexD+i][j] = - (dist[indexD+i][j] * dist[indexD+i][j])/2;	
				G_dist[indexD+j][i] = G_dist[indexD+i][j];
			}
		}


		for(i=0; i<n; i++){
			tmp = 0.;
			for(j=0; j<n; j++){
				tmp += G_dist[indexD+j][i];
			}
			tmp /= n;

			for(j=0; j<n; j++){
				tmp_dist[indexD+j][i] = G_dist[indexD+j][i] - tmp;
			}
		}

		for(i=0; i<n; i++){
			tmp = 0.;
			for(j=0; j<n; j++){
				tmp += tmp_dist[indexD+i][j];
			}
			tmp /= n;
			for(j=0; j<n; j++){
				G_dist[indexD+i][j] = tmp_dist[indexD+i][j] - tmp;
			}

		}


	}

	//print_dm(G_dist, 0, 10, 0, 10, "G_d_0.5");

	//print_dm(G_dist, n, n+10, 0, 10, "G_d_1");

	//print_dm(G_dist, (2*n), (2*n)+10, 0, 10, "G_d_uw");

	//print_dm(G_dist, (3*n), (3*n)+10, 0, 10, "G_d_bc");

	// split x as binary and continous parts
	pb = 0; pc = 0;
	for(j=0; j<p; j++){

		if(xBIN[j]){

			for(i=0; i<n; i++){
				xb[pb][i] = x[j][i];
			}
			pb++;
		}else{

			for(i=0; i<n; i++){
				xc[pc][i] = x[j][i];
			}
			pc++;
		}
		
	
	}
	//printf("pb=%d, pc=%d\n", pb, pc);
	
	// adjust for covariates
	if(pb>0){  // binary part

		for(j=0; j<pb; j++){

			Res(n, 1, xb[j], q, z, xb_est[j], xb_res[j]);

			for(i=0; i<n; i++){
				x_res[j][i] = xb_res[j][i];
			}

		}	
		//print_dm(xb_est, 0, 0, 0, 10, "first 10 xb_est");
		//print_dm(xb_res, 0, 0, 0, 10, "first 10 xb_res");

	}
	
	if(pc>0){   // continous part
		
		for(j=0; j<pc; j++){

			Res(n, 0, xc[j], q, z, xc_est[j], xc_res[j]);

			for(i=0; i<n; i++){
				x_res[j+pb][i] = xc_res[j][i];
			}
		}
		//print_dm(xc_est, 0, 0, 0, 10, "first 10 xc_est[0,]");
		//print_dm(xc_res, 0, 0, 0, 10, "first 10 xc_res[0,]");
	}


	// Calculate hat matrix H based on x_res
	Hat(n, p, x_res, H);
	
	// Calculate observed test statistics
	trGH(n, ndist, H, G_dist, s_obs);
	
	//print_dv(s_obs, 0, ndist-1, "s_obs");

	// Do permutation
	for(d=0; d<ndist; d++){
		count_dist[d] = 0;
	}


	start_nperm = 0;
	end_nperm = 999;
	flag = 1;
	while( flag && end_nperm < max_nperm){

		
		permute_work_wCov_naive_v1(n, pb, xb_est, pc, xc_est, xc_res, q, z, ndist, G_dist, s_obs, s_perm, start_nperm, end_nperm, count_dist, &flag, &next_end_nperm);

		//printf("start_nperm=%ld, end_nperm=%ld, flag=%d, next_end_nperm=%ld\n", start_nperm, end_nperm, flag, next_end_nperm);
		if(flag){

			start_nperm = end_nperm + 1;
			end_nperm = next_end_nperm;

		}else{
			//printf("Pvalue accuracy achieved with the %d th permutation.\n", end_nperm+1);
			// the last step
			minP = 1;
			for(d=0; d<ndist; d++){
				pvalue[d] = (count_dist[d] + 1)/(end_nperm + 2);
				if(minP > pvalue[d]){
					minP = pvalue[d];
				}
			}
			
			if(ndist>1){

				s_perm_d = dvector(0, end_nperm);
				minP_perm = dvector(0, end_nperm);
				for(l=0; l<=end_nperm; l++){
					minP_perm[l] = 1;
				}

				for(d=0; d<ndist; d++){
					for(l=0; l<=end_nperm; l++){
						s_perm_d[l] = s_perm[l][d];
					}

					qRank_noTie((end_nperm+1), s_perm_d);
					for(l=0; l<=end_nperm; l++){
						if(minP_perm[l] > -s_perm_d[l]){
							minP_perm[l] = -s_perm_d[l];
						}
					}
				}

				count_min  = 0;
				for(l=0; l<=end_nperm; l++){
					if( minP > (end_nperm + 1 + minP_perm[l])/(end_nperm + 2) ){
						count_min += 1;
					}
				}
				pval_min = (count_min + 1)/(end_nperm + 2);

				pvalue[ndist] = pval_min;

				free_dvector(s_perm_d, 0, end_nperm);
				free_dvector(minP_perm, 0, end_nperm);				
			}

		}


		if(end_nperm >= max_nperm){
			printf("Warning: Inaccurate pvalue with %d permutation.\n", max_nperm);
			// the last step
			permute_work_wCov_naive_v1(n, pb, xb_est, pc, xc_est, xc_res, q, z, ndist, G_dist, s_obs, s_perm, start_nperm, max_nperm-1, count_dist, &flag, &next_end_nperm);

			minP = 1;
			for(d=0; d<ndist; d++){
				pvalue[d] = (count_dist[d] + 1)/(max_nperm + 1);
				if(minP > pvalue[d]){
					minP = pvalue[d];
				}
			}
			
			if(ndist>1){

				s_perm_d = dvector(0, max_nperm-1);
				minP_perm = dvector(0, max_nperm-1);
				for(l=0; l<max_nperm; l++){
					minP_perm[l] = 1;
				}

				for(d=0; d<ndist; d++){
					for(l=0; l<max_nperm; l++){
						s_perm_d[l] = s_perm[l][d];
					}

					qRank_noTie(max_nperm, s_perm_d);
					for(l=0; l<max_nperm; l++){
						if(minP_perm[l] > -s_perm_d[l]){
							minP_perm[l] = -s_perm_d[l];
						}
					}
				}

				count_min  = 0;
				for(l=0; l<max_nperm; l++){
					if( minP > (max_nperm + minP_perm[l])/(max_nperm + 1) ){
						count_min += 1;
					}
				}
				pval_min = (count_min + 1)/(max_nperm + 1);

				pvalue[ndist] = pval_min; 

				free_dvector(s_perm_d, 0, max_nperm-1);
				free_dvector(minP_perm, 0, max_nperm-1);

			}





		}
	}

	
	free_dmatrix(tmp_dist, 0, (ndist*n-1), 0, n-1);
	free_dmatrix(G_dist, 0, (ndist*n-1), 0, n-1);
	free_dmatrix(H, 0, n-1, 0, n-1);

	free_dvector(s_obs, 0, ndist-1);

	free_ivector(perm_index, 0, n-1);
	free_dmatrix(s_perm, 0, max_nperm-1, 0, ndist-1);
	free_dvector(count_dist, 0, ndist-1);

	free_dmatrix(xb, 0, p-1, 0, n-1);
	free_dmatrix(xb_est, 0, p-1, 0, n-1);
	free_dmatrix(xb_res, 0, p-1, 0, n-1);
	free_dmatrix(xc, 0, p-1, 0, n-1);
	free_dmatrix(xc_est, 0, p-1, 0, n-1);
	free_dmatrix(xc_res, 0, p-1, 0, n-1);
	free_dmatrix(x_res, 0, p-1, 0, n-1);
}
