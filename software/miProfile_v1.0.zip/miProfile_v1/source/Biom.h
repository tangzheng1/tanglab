#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define CHARMAX 2000
#define PTR_SETBACK -10


//struct cell is for each cell location and value data
struct report{
    int rowCount;
    int colCount;
    char** rowName;
    char** colName;

    float** data;
};

typedef struct report report; 

//export dataset in csv format
void exportCSV(report* rpt, char* fileName){
    int i, j;
    FILE *outFilePtr;

    if((outFilePtr = fopen(fileName, "w")) != NULL){
        for(j = 0; j < rpt-> colCount; j++){
            fprintf(outFilePtr, ",%s", rpt->colName[j]);
        }
        fprintf(outFilePtr, "\n");

        for(i = 0; i < rpt-> rowCount; i++){
            fprintf(outFilePtr, "%s", rpt->rowName[i]);
            for(j = 0; j < rpt-> colCount; j++){
                fprintf(outFilePtr, ",%f", rpt->data[i][j]);
            }
            fprintf(outFilePtr, "\n");
        }        
        close(outFilePtr);
    } else{
        printf("%s file open failed exit\n", fileName);
    }
    return;
}

//transpose a matrix
report* transpose(report* rpt){
    int i, c;
    char** row;
    int rown;

    char** col;
    int coln;

    float** data;

    report* trpt = calloc(1, sizeof(report));

    rown = rpt->colCount; 
    coln = rpt->rowCount;

    row = calloc(rown, sizeof(char*));
    for(i = 0; i < rown; i++){
        row[i] = calloc(strlen(rpt->colName[i]), sizeof(char));
        memcpy(row[i], rpt->colName[i], strlen(rpt->colName[i]));
    }

    col = calloc(coln, sizeof(char*));
    for(i = 0; i < coln; i++){
        col[i] = calloc(strlen(rpt->rowName[i]), sizeof(char));
        memcpy(col[i], rpt->rowName[i], strlen(rpt->rowName[i]));
    }

    trpt->rowCount = rown;
    trpt->colCount = coln;

    trpt->rowName = row;
    trpt->colName = col;

    data  = (float **)malloc(sizeof(float *) * trpt->rowCount);
    data[0] = (float *)malloc(sizeof(float) * trpt->rowCount * trpt->colCount);

    for(i = 0; i < rown; i++){
        data[i] = (*data + coln * i);
        for(c =0; c < coln; c++){
            data[i][c] = rpt->data[c][i];
        }
    }
    trpt->data = data;

    return trpt;
}

//return a char* string of version number, if not find, return NULL
char* getVersion(char* formatStr, FILE* infPtr){
    char* bucket;
    char* buffer = calloc(CHARMAX, sizeof(char));
    char* version;

    rewind(infPtr); //reset file pointer
    //get version
    while(!feof(infPtr)){
        fgets(buffer,CHARMAX, infPtr);

        bucket = strstr(buffer, formatStr);
        if(bucket != NULL){                         
            version = strtok(bucket, "\"");
            version = version + strlen(formatStr) + 1;
            break;
        }
        fseek(infPtr, PTR_SETBACK, SEEK_CUR); //step back to avoid truncation     
    }
    free(buffer);
//    printf("%s\n", version);
    return version;
} 

//extract shape
//return NULL if not found.  otherwise return int* in a format of row x col.  
int* getShape(FILE* infPtr){
    char* bucket;
    char* buffer = calloc(CHARMAX, sizeof(char));
    char* shapeStr =  "\"shape\":";
    char* shape;
    int* dim = NULL;
    rewind(infPtr); //reset file pointer

    while(!feof(infPtr)){
        fgets(buffer,CHARMAX, infPtr);
        bucket = strstr(buffer, shapeStr);
        if(bucket != NULL){
            dim = calloc(2, sizeof(int));
            shape = strtok(bucket, "]");
            shape = shape + strcspn(shape, "[")+1;
            dim[0] = atoi(strtok(shape, ","));
            dim[1] = atoi( shape + strcspn(shape, ",")+1);
//            printf("SHAPE:: %d X %d\n", dim[0],dim[1]);
            break;
        }
        fseek(infPtr, PTR_SETBACK, SEEK_CUR); //step back to avoid truncation
    }
    free(buffer);
    return dim;
}

//return NULL if not found, otherwise return a char* string array
char** getRowList(FILE* infPtr, int rowNum){
    char* bucket;
    char* buffer = calloc(CHARMAX, sizeof(char));
    char* rowStr =  "rows\":";
    char** rowList = NULL;  //put the row name strings
    char* holder;
    char* content;
    char* token;
    char* token2;
    char* holder2;
    char* holder3;
    int flag,c;

    rewind(infPtr); //reset file pointer

    while(!feof(infPtr)){
        fgets(buffer,CHARMAX, infPtr);

        bucket = strstr(buffer, rowStr);
        if(bucket != NULL){
            fseek(infPtr, -1*CHARMAX + strlen(strtok(buffer, rowStr))+1, SEEK_CUR); //set ptr to the beginning of rows   

            flag = 0;
            holder = calloc(0, sizeof(char));  //initialize holder

            while(flag != 1){
                fgets(buffer,CHARMAX, infPtr);

                content = calloc(CHARMAX + strlen(holder) , sizeof(char));
                memcpy(content, holder, strlen(holder));
                strcat(content, buffer);
                free(holder);
                holder = calloc(strlen(content), sizeof(char));
                memcpy(holder, content, strlen(content));
                free(content);

                if(strstr(buffer,"}]") != NULL){
                    flag = 1;
                }                              
            };//end while/flag

            content = calloc(strlen(holder), sizeof(char));
            content  = strstr(holder, "\"columns\":"); //remove trailing strings of other elements

            holder = strpbrk(holder, "{");  //remove beginning strings: "rows":
            buffer = calloc(strlen(holder), sizeof(char));
            memcpy(buffer, holder, strlen(holder) - strlen(content));

            holder = buffer;
            c = 0;
            content = strtok(strdup(holder), ",");

            rowList = calloc(rowNum, sizeof(char*));

            while(content != NULL){
                token = calloc(strlen(content), sizeof(char));
                memcpy(token, content, strlen(content));

                if(strstr(token, "\"id\"") != NULL ){
                    token2 = strstr(strstr(token, ":"), "\"")+1; //removing "row": " to the first char of string
                    holder2 = calloc(strlen(token2), sizeof(char));
                    memcpy(holder2, token2, strlen(token2));
                    holder3 = strstr(holder2, "\"");
                    rowList[c] = calloc(strlen(token2), sizeof(char));
                    memcpy(rowList[c], token2, strlen(token2) - strlen(holder3));
                    free(holder2);
                    c++;
                }

                content = strtok(NULL,",");
                free(token);
            };   //end while/content

            break;

        } else {
            fseek(infPtr, PTR_SETBACK, SEEK_CUR); //step back to avoid truncation
        };//end of if/else/bucket
    };  //end of while loop

    free(buffer);
    return rowList;
}

char** getColList(FILE* infPtr, int colNum){
    char* bucket;
    char* buffer = calloc(CHARMAX, sizeof(char));
    char* colStr =  "columns\":";
    char** colList = NULL;  //put the row name strings
    char* holder;
    char* content;
    char* token;
    char* token2;
    char* holder2;
    char* holder3;
    int flag,c;

    rewind(infPtr); //reset file pointer

    while(!feof(infPtr)){
        fgets(buffer,CHARMAX, infPtr);

        bucket = strstr(buffer, colStr);
        if(bucket != NULL){
            fseek(infPtr, -1*strlen(bucket), SEEK_CUR);

            flag = 0;
            holder = calloc(0, sizeof(char));  //initialize holder

            while(flag != 1){
                fgets(buffer,CHARMAX, infPtr);
                content = calloc(CHARMAX + strlen(holder) , sizeof(char));
                memcpy(content, holder, strlen(holder));
                strcat(content, buffer);
                free(holder);
                holder = calloc(strlen(content), sizeof(char));
                memcpy(holder, content, strlen(content));
                free(content);

                if(strstr(buffer,"}]") != NULL){
                    flag = 1;
                }
            };  //end while/flag

            content = calloc(strlen(holder), sizeof(char));
            content  = strstr(holder, "}]"); //remove trailing strings of other elements

            holder2 = holder + 11;  //remove beginning strings: "columns": 
            buffer = calloc(strlen(holder2), sizeof(char));
            memcpy(buffer, holder2, strlen(holder2) - strlen(content));
            free(holder);
            holder = buffer;
            c = 0;
            content = strtok(strdup(holder), ",");

            colList = calloc(colNum, sizeof(char*));

            while(content != NULL){
                token = calloc(strlen(content), sizeof(char));
                memcpy(token, content, strlen(content));

                if(strstr(token, "\"id\"") != NULL ){
                    token2 = strstr(strstr(token, ":"), "\"")+1;
                    holder2 = calloc(strlen(token2), sizeof(char));
                    memcpy(holder2, token2, strlen(token2));
                    holder3 = strstr(holder2, "\"");

                    colList[c] = calloc(strlen(token2), sizeof(char));
                    memcpy(colList[c], token2, strlen(token2) - strlen(holder3));
                    free(holder2);
                    c++;
                }

                content = strtok(NULL,",");
                free(token);
            };//end while/content

            break;
        } else {
            fseek(infPtr, PTR_SETBACK, SEEK_CUR); //step back to avoid truncation
        };//end of if/else/bucket
    }
    free(buffer);
    return colList;
}

float** getData(FILE* infPtr, int rowNum, int colNum){
    char* dataStr = "data";
    float**  dataSet = NULL;  //this is a 2D array to put the matrix data 

    char* bucket;
    char* buffer = calloc(CHARMAX, sizeof(char));
    char* holder;
    char* content;
    char* token;
    char* token2;
    char* holder2;
    char* holder3;
    int flag,c, i, rowLoc, colLoc;
    float cellLoc;

    rewind(infPtr); //reset file pointer

    while(!feof(infPtr)){
        fgets(buffer,CHARMAX, infPtr);

        bucket = strstr(buffer, dataStr);
 
        if(bucket != NULL){
             fseek(infPtr, -1*strlen(bucket), SEEK_CUR);
             flag = 0;
             holder = calloc(0, sizeof(char));  //initialize holder
 
             while(flag != 1){
                 fgets(buffer,CHARMAX, infPtr);
                 content = calloc(CHARMAX + strlen(holder) , sizeof(char));
                 memcpy(content, holder, strlen(holder));
                 strcat(content, buffer);
                 free(holder);
                 holder = calloc(strlen(content), sizeof(char));
                 memcpy(holder, content, strlen(content));
                 free(content);
 
                 if(strstr(buffer,"]],") != NULL){
                     flag = 1;
                 }
             };  //end while/flag

             content = calloc(strlen(holder), sizeof(char));
             content  = strstr(holder, "]],"); //remove trailing strings of other elements

             holder2 = holder + 8;  //remove beginning strings: ""data":": 
             buffer = calloc(strlen(holder2), sizeof(char));
             memcpy(buffer, holder2, strlen(holder) - strlen(content)+1);
 

             //initialize dataSet
             dataSet  = (float **)malloc(sizeof(float *) * rowNum);
             dataSet[0] = (float *)malloc(sizeof(float) * colNum * rowNum);

             for(i = 0; i < rowNum; i++){
                 dataSet[i] = (*dataSet + colNum * i);
                 for(c =0; c < colNum; c++){
                     dataSet[i][c] = 0;
                 }
             }
 
             c= 0;  //reset c as a counter
             holder2 = strstr(buffer, "[");  //get the first beginning
             holder3 = strstr(buffer, "]");   //get the first ending

             while(holder2 != NULL){            

                 token = calloc(strlen(holder2)-strlen(holder3), sizeof(char));
                 memcpy(token, holder2+1, strlen(holder2)-strlen(holder3)-1);

                 holder2 = strstr(holder3+1, "[");  //get the next beginning
                 if(holder2 != NULL){
                     holder3 = strstr(holder2, "]");   //get the next ending
                 }
     
                 content = strtok(token,",");
                 c = 0;
                 while(content != NULL){
                     if(c == 0){
                         rowLoc = atoi(content);
                     }
 
                     if(c == 1){
                         colLoc = atoi(content);
                     }
 
                     if(c == 2){
                         cellLoc = atof(content);
                     }
                     c++;
                     content = strtok(NULL,",");
                 }
                 dataSet[rowLoc][colLoc]=cellLoc;

                 free(token);

             };//end while/content

             break;
        } else {
            fseek(infPtr, PTR_SETBACK, SEEK_CUR); //step back to avoid truncation
        };           //end of if/else/bucket
    }
    free(buffer);
    return dataSet;    
}


report* readBiom(FILE* infPtr){    
    int rowNum = -1, colNum = -1;
    char* formatStr = "Biological Observation Matrix";
    char* version;  //put version number gained from format

    float**  dataSet;  //this is a 2D array to put the matrix data 
    char** rowList;  //put the row name strings
    char** colList;  //put the col name strings
    int* dim;
    report* myRpt = calloc(1,sizeof(report));

    //get version
    version = getVersion(formatStr,infPtr);

    //get shape
    dim = getShape(infPtr);
    rowNum = dim[0];
    colNum = dim[1];
    rowList = getRowList(infPtr, rowNum);
    colList = getColList(infPtr, colNum);

    //get data
    dataSet = getData(infPtr, rowNum, colNum);
    if(dim != NULL && version != NULL && rowList != NULL && colList != NULL){
        //write result to a reporting struct
        myRpt-> rowCount = rowNum;
        myRpt-> colCount = colNum;
        myRpt-> rowName = rowList;
        myRpt-> colName = colList;
        myRpt-> data = dataSet;

    } else {
        printf("INPUT DATA FILE IS NOT VALID!\n");
    }

    return myRpt;
}


//print the content of an string array
void printString(char** s, int c){
    int i ;

    for(i = 0; i< c; i++){
        printf("%s\n", s[i]);
    }

    return;
}

//d:  2d array
//r:  row number
//c:  column number
void printData(float** d, int r, int c){
    int i,j;

    for(i = 0; i< r; i++){
        for(j= 0; j< c; j++){
            printf("%d %d %f \n",i,j,d[i][j]); 
        }
    }
}

float* accuPct(int* s, int num){
    float* rst = calloc(num, sizeof(float));
    int i, sum = 0;

    for(i =0; i< num; i++){
        sum = sum+ s[i];
    }

    for(i =0; i< num; i++){
        rst[i]  = (float) s[i] / (float) sum;
    }

    for(i =1; i< num; i++){
        rst[i]  = rst[i] + rst[i-1];
    }

    //reset to resolve 0 issue
    for(i =0; i< num; i++){
        if(s[i] == 0){
            rst[i] = 0;
        }
    }
    return rst;
}


int getRarefyRowCt(float** m, int row, int col,int* depth){
    int i,j,holder, min, cutoff;
    int* rsum = calloc(row, sizeof(int));
    int rnum2 = 0;

    for(i = 0; i<row; i++){
        holder = 0;
        for(j = 0; j<col; j++){
            holder = holder + (int)m[i][j];
        }
        rsum[i] = holder;

        if(i == 0){
            min = rsum[i];  //assign the first one
        } else {
            if(min >  rsum[i]){
                min = rsum[i];
            }
        }
    }

    if(depth == NULL){
        cutoff = min;
    } else {
        cutoff = *depth;
    }

    for(i = 0; i<row; i++){
        if(rsum[i] >= cutoff){
            rnum2++;
        }
    }

    return rnum2;
}

int* getRarefyRowSum(float** m, int row, int col){
    int i,j,holder;
    int* rsum = calloc(row, sizeof(int));

    for(i = 0; i<row; i++){
        holder = 0;
        for(j = 0; j<col; j++){
            holder = holder + (int)m[i][j];
        }
        rsum[i] = holder;
    }
    return rsum;
}


//depth = NULL:  use default which is the smallest of row sum; 
//otherwise, use value defined by depth
int** Rarefy( float** m, int row, int col,int* depth, float* seed){
    int i,j,k, p,q,s;
    int cutoff;
    
    int** rst;
    int* rsum = getRarefyRowSum(m, row, col);
    int* copy = calloc(col, sizeof(int));
    float* ruler;
    float rVal;

    int rnum2 = getRarefyRowCt(m, row, col, depth);

    if(seed ==NULL){
        srand(time(NULL));  //if no seed provided use system time as seed
    } else {
        srand( *seed);
    }

    //allocate memory and initialize to 0
    rst  = calloc(rnum2, sizeof(int *));
    for(i = 0; i<rnum2; i++){
        rst[i] = calloc(col, sizeof(int));
    }

    for(i = 0; i<rnum2; i++){
        for(j = 0; j<col; j++){
            rst[i][j] = 0;
        }
    }

    //processing
    j = 0;
    for(i = 0; i< row; i++){
        if(rsum[i] >= cutoff){
            for(k = 0; k< col; k++){
                copy[k] = (int) m[i][k];
            }

            ruler = accuPct(copy,col);

            for(q = 0; q<cutoff; q++){
                rVal = (float)rand()/(float)RAND_MAX;

                for(s = 0; s< col; s++){
                    if(rVal <= ruler[s]){
                        rst[j][s] = rst[j][s] + 1;
                        break;
                    }
                }
            }
            free(ruler);
            j++;
        }
    }

    
    free(rsum);
    free(copy);
    return rst;
}




