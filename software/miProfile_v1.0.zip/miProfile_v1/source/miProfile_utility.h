

#define MVN_MAXSTEPS 2  // don't exceed INT_MAX
#define MVN_MAXINT 1000000000  // INT_MAX is 2147483647 on the server
#define THRESHOLD_MAX 10
#define SAMPLE_STAGE1 1000
#define SAMPLE_STAGE2 100000
#define SAMPLE_STAGE3 1000000
#define SAMPLE_STAGE4 5000000
//#define PERMUTATION_SEED1  7335
//#define PERMUTATION_SEED2  4623
//#define PERMUTATION_SEED3  8097

void kill_miProfile();
void rarefy(int m, double *x, int depth);

void treeDist_v3(int n, int m, int nbr, int Dg, double *Dg_type, int *Dg_norm_type, int Dpg, double *Dpg_type, int *Dpg_norm_type, int Duw, int Duw_norm, double *tree_brLen, int *tree_upNode, int *tree_downNode, double **otu, double **otu_r, double **dist);
void treeDist_v4(int n, int m, int nbr, int Dg, double *Dg_type, int *Dg_norm_type, int Dpg, double *Dpg_type, int *Dpg_norm_type, int Duw, int Duw_norm, int *tree_tipLabel_ID, double *tree_brLen, int *tree_upNode, int *tree_downNode, double **otu, double **otu_r, double **dist);
void Dist_v3(int n, int m, int Dbc, int Dbc_norm, int Dj, int Dj_norm, double **otu, double **otu_r, double **dist);

void Hat(int n, int p, double **x, double **H);
//void trF(int n, int ndist, double **H, double **G_dist, double *s_obs);
void trGH(int n, int ndist, double **H, double **G_dist, double *s_obs);
void permute_work_woCov_v1(int n, int p, double **x, int ndist, double **G_dist, double *s_obs, double **s_perm, long start_nperm, long end_nperm, double *count_dist, int *flag, long *next_end_nperm);
void permutePair_work_woCov_v1(int n, int p, double **x, int ndist, double **G_dist, double *s_obs, double **s_perm, long start_nperm, long end_nperm, double *count_dist, int *flag, long *next_end_nperm);

void Permanova_woCov_v1(int n, int ndist, long max_nperm, double **tree_dist, int p, double **x, double *pvalue);
void PermanovaPair_woCov_v1(int n, int ndist, long max_nperm, double **tree_dist, int p, double **x, double *pvalue);

void permute_work_wCov_v1(int n, int pb, double **xb_tmp, double **xb_par_xc, int pc, double **xc_est, double **xc_res, int q, double **z, int ndist, double **G_dist, double *s_obs, double **s_perm, long start_nperm, long end_nperm, double *count_dist, int *flag, long *next_end_nperm);
void Permanova_wCov_v1(int n, int ndist, long max_nperm, double **tree_dist, int p, int *xBIN, double **x, int q, double **z, double *pvalue);

void permute_work_wCov_naive_v1(int n, int pb, double **xb_est, int pc, double **xc_est, double **xc_res, int q, double **z, int ndist, double **G_dist, double *s_obs, double **s_perm, long start_nperm, long end_nperm, double *count_dist, int *flag, long *next_end_nperm);
void Permanova_wCov_naive_v1(int n, int ndist, long max_nperm, double **tree_dist, int p, int *xBIN, double **x, int q, double **z, double *pvalue);
void PermanovaStrata_woCov_v1(int *strata, int n, int ndist, long max_nperm, double **dist, int p, double **x, double *pvalue);
void permuteStrata_work_woCov_v1(int nstrata, int *n_subj_strata, int n, int p, double **x, int ndist, double **G_dist, double *s_obs, double **s_perm, long start_nperm, long end_nperm, double *count_dist, int *flag, long *next_end_nperm);
