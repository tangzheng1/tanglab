## maxF test
setwd("C:\\_Research\\ZT0012\\software\\v1_current\\example_Psoriasis")
library(GUniFrac)


    
    #========= Covariate
    tmp = as.matrix((read.table(file="./input/status_normal_meta.txt", header=TRUE)))
    X = as.numeric(tmp[,2])
    strata = as.factor(as.numeric(tmp[,3]))
    n = length(X)
    #========= distances
    Dist.name <- c("Dw", "Dpw1", "Dpw0", "Duw", "Dbc", "Dj")
    Dist.list <- array(NA, c(n, n, length(Dist.name)), dimnames = list(1:n, 1:n, Dist.name))
    Dist.list[ , ,1] = as.matrix(read.table(file="./output/Dbc.dist", header=FALSE))
    Dist.list[ , ,2] = as.matrix(read.table(file="./output/Dj.dist", header=FALSE))
    Dist.list[ , ,3] = as.matrix(read.table(file="./output/Duw.dist", header=FALSE))
    Dist.list[ , ,4] = as.matrix(read.table(file="./output/Dw.dist", header=FALSE))
    Dist.list[ , ,5] = as.matrix(read.table(file="./output/Dpw_0.dist", header=FALSE))
    Dist.list[ , ,6] = as.matrix(read.table(file="./output/Dpw_1.dist", header=FALSE))
    
    #========= maxF test
    
    set.seed(216)
    result.maxF = PermanovaG(Dist.list ~ X, strata=strata, perm=100000)
    result.maxF$aov.tab$p.value
    
    